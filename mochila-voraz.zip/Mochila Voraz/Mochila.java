import java.util.ArrayList;

/**
 * Clase mochila
 * Incluye los métodos necesarios para:
 * 1. La creación de los objetos de partida necesarios a partir de un fichero.
 * 2. La selección, por montículo en este caso, con el cálculo del beneficio total.
 * 3. La creación de un String para devolver los datos de la selección realizada y del beneficio total.
  * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public class Mochila
{
    /**
     * Clase privada Pareja
     * Es una extensión de la clase abstracta Nodo para tratar los arrays de la dupla peso-beneficio dentro del montículo.
     */
    private class Pareja extends Nodo
    {
        /**
         * El único campo es el array de la dupla peso-beneficio.
         */
        private Integer[] pareja;
        
        /**
         * Constructor.
         */
        private Pareja(Integer[] pareja){this.pareja = pareja;}
        
        /**
         * Devuelve el peso.
         */
        private int devPeso(){return this.pareja[0];}
        
        /**
         * Devuelve el beneficio.
         */
        private int devBenef(){return this.pareja[1];}
        
        /**
         * Devuelve el array.
         */
        private Integer[] devPareja(){return this.pareja;}
        
        /**
         * Devuelve el cociente entre el beneficio y el peso.
         */
        public float devValor(){return new Float(new Float(this.devBenef())) / new Float(new Float(this.devPeso()));}
    }
    
    /**
     * Los campos son:
     * -Un entero para la capacidad de la mochila.
     * -Un flotante para el beneficio total de la mochila.
     * -Un ArrayList de arrays de Nodos de arrays de enteros para el peso y beneficio de los objetos inicialmente disponibles.
     * -Un ArrayList de arrays de enteros para el peso y beneficio de los objetos seleccionados dentro de la mochila.
     * -Un flotante para la fracción tomada del último objeto introducido en la mochila.
     * -Una Traza para mostrar la traza del algoritmo.
     */
    private int capacidad;
    private float beneficio;
    private ArrayList<Pareja> objetos;
    private ArrayList<Integer[]> seleccion;
    private float ultFracc;
    private Traza traza;

    /**
     * El contructor toma el texto leído del fichero y toma los datos necesarios para el algoritmo.
     */
    public Mochila(String fichero, Traza traza)
    {
        this.traza = traza;
        this.traza.traza("Empieza la lectura del fichero.\nSe empieza por la construcción del vector de objetos iniciales.");
        this.objetos = new ArrayList<Pareja>();
        this.traza.traza("Se divide el texto obtenido del fichero por líneas.");
        String[] lineas = fichero.split("\n");
        this.traza.traza("Se lee el número de objetos iniciales.");
        int numObj = new Integer(lineas[0]);
        int numLineas = lineas.length;
        for (int i = 0; i < numObj; i++)
        {
            String linea = lineas[i + 1];
            if (linea == null){continue;}
            String[] linDatos = linea.split(" ");
            if (linDatos.length < 2){continue;}
            this.traza.traza("Se han leído dos valores entero, por lo que se añade un nuevo objeto.");
            Integer[] valores = new Integer[]{new Integer(linDatos[0]), new Integer(linDatos[1])};
            this.objetos.add(new Pareja(valores));
        }
        //Si el archivo estuviera mas configurado justo aquí, le daríamos un valor por defecto.
        this.traza.traza("Se lee la capacidad de la mochila.");
        this.capacidad = new Integer(lineas[numLineas - 1]);
        this.traza.traza("Se inicializan los campos restantes.");
        this.beneficio = 0;
        this.seleccion = new ArrayList<Integer[]>();
        this.ultFracc = 0;
    }
    
    /**
     * Comprueba si la mochila está llena, es decir, si su capacidad es igual o menor que cero.
     */
    private boolean estaLlena(){return this.capacidad <= 0;}
    
    /**
     * Realiza la selección de objetos de beneficio máximo mediante un montículo.
     */
    public void selecciMontic()
    {
        this.traza.traza("Empieza la selección.");
        this.seleccion.clear();
        MonticuloGeneral<Pareja> montic = new MonticuloGeneral<Pareja>(this.objetos, true);
        //Puede darse el caso de que se introduzca una colección de objetos que no rebase la capacidad
        while (!montic.estaVacio() && !this.estaLlena())
        {
            this.traza.traza("Se selecciona un nuevo objeto del montículo.");
            Pareja valores = montic.obtenCima();
            int peso = valores.devPeso();
            int benef = valores.devBenef();
            float fracc = 1;
            if (this.capacidad < peso){
                fracc = new Float(this.capacidad) / new Float(peso);
                this.ultFracc = fracc;
                this.traza.traza("La mochila ya está llena.");
            }
            this.seleccion.add(valores.devPareja());
            this.traza.traza("Se actualiza el beneficio.");
            this.beneficio += fracc * benef;
            this.traza.traza("Se actualiza el peso.");
            this.capacidad -= peso;
        }
    }
    
    /**
     * Devuelve un texto para el fichero de salida con:
     * -La selección de objetos con sus pesos totales, las fracciones tomadas y sus beneficios parciales.
     * -El beneficio total de la mochila.
     */
    public String toString()
    {
        this.traza.traza("La selección de los objetos dentro de la Mochila se pasa a texto.");
        String fichero = "";
        int tamSelec = this.seleccion.size();
        for (int i = 0; i < tamSelec; i++)
        {
            this.traza.traza("Se convierten los datos de un objeto de la selección.");
            Integer[] pareja = this.seleccion.get(i);
            fichero = fichero.concat(pareja[0].toString());
            //Sólo el último objeto puede tener una fracción menor que 1
            if (i < tamSelec - 1){fichero = fichero.concat(" 1 " + pareja[1] + "\n");}
            else {fichero = fichero.concat(" " + this.ultFracc + " " + this.ultFracc * pareja[1] + "\n");}
        }
        this.traza.traza("Ahora se convierte el beneficio total.");
        fichero = fichero.concat(this.beneficio + "");
        return fichero;
    }
}
