
/**
 * Clase abstracta Individuo
 * 
 * Esta clase abstracta es la base de todas las clases del sistema que se referirán a personas
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Individuo
{
    /**
     * Campos que tendrán todos los individuos registrados en el sistema: identificador numérico y nombre
     */
    protected int identificador;
    protected String nombre;
    
    /**
     * Constructor más simple
     */
    public Individuo(String nombre, int identificador)
    {
        this.nombre = nombre;
        this.identificador = identificador;
    }
    
    /**
     * Modifica el nombre
     */
    public void modificaNombre(String nombre)
    {
        this.nombre = nombre;
    }
    
    public int devuelveIdentificador()
    {
        return this.identificador;
    }
}
