
/**
 * La clase Administrador es la más importante dentro de los Empleados.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Administrador extends Empleado
{
    /**
     * Constructor
     */
    public Administrador(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    public TipoUsuario devuelveUsuario()
    {
        return TipoUsuario.ADMINISTRADOR;
    }
}
