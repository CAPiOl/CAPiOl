
/**
 * La clase Arquitecto define otro de los Empleados
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Arquitecto extends Empleado
{
    /**
     * Constructor
     */
    public Arquitecto(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    public TipoUsuario devuelveUsuario()
    {
        return TipoUsuario.ARQUITECTO;
    }
}
