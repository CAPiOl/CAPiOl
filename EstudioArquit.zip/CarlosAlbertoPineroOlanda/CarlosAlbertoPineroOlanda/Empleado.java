
/**
 * Clase abstracta Empleado
 * 
 * Esta clase abstracta es la base de los cuatro tipos de empleados:
 * administradores, arquitectos, aparejadores y contables
 * 
 * Hereda de Individuo
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Empleado extends Individuo
{
    /**
     * Enumeración TipoUsuario
     */
    protected enum TipoUsuario{ADMINISTRADOR, ARQUITECTO, APAREJADOR, CONTABLE};
    
    /**
     * Constructor más simple
     */
    public Empleado(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    /**
     * Método que devuelve el tipo de usuario
     * 
     * @return TipoUsuario tipoUsuario
     */
    public abstract TipoUsuario devuelveUsuario();
    
    /**
     * Devuelve el Empleado como String
     */
    public String toString()
    {
        String datos1 = "\n    " + this.nombre + " Puesto " + this.devuelveUsuario();
        return datos1;
    }
}
