
/**
 * Clase que representa los certificados de inspección para edificios comunitarios
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Inspeccion extends Certificado
{
    /**
     * Constructor
     */
    public Inspeccion(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve Inspeccion como String
     */
    public String toString()
    {
        String datos = "\n    Certificado de inspección";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosCertificado());
        return datos;
    }
}
