
/**
 * Clase ContruccionRes. Define las construcciones de NoResidenciales
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class ConstruccionNoRes extends Proyecto
{
    /**
     * Constructor
     */
    public ConstruccionNoRes(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la ConstruccionNoRes como String
     */
    public String toString()
    {
        String datos = "\n    Proyecto de construcción no residencial";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosProyecto());
        return datos;
    }
}
