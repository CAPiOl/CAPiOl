import java.time.LocalDate;

/**
 * Clase abstracta Certificado. Define todos los certificados
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Certificado extends Tarea
{
    /**
     * Campo específico de todos los Certificados:
     * La fecha de emisión.
     */
    protected LocalDate fechaEmision;
    
    /**
     * Constructor
     */
    public Certificado(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la fecha de emisión
     */
    public LocalDate devuelveFechaEmision()
    {
        return this.fechaEmision;
    }
    
    /**
     * Modifica la fecha de emisión
     */
    public void modificaFechaEmision(LocalDate fechaEmision)
    {
        this.fechaEmision = fechaEmision;
    }
    
    /**
     * Devuelve los datos básicos del Certificado como String,
     * es parte de los métodos toString de las subclases
     */
    protected String devuelveDatosCertificado()
    {
        String datos = "\n    Fecha de emisión " + this.fechaEmision;
        return datos;
    }
}
