import java.time.LocalDate;

/**
 * La clase Unifamiliar describe cualquier residencia que no sea comunitaria.
 * Es decir, chalés, casas de una planta, torres...
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Unifamiliar extends Residencial
{
    /**
     * Constructor
     */
    public Unifamiliar(int identificador)
    {
        super(identificador);
    }

    /**
     * Devuelve el valor UNIFAMILIAR
     */
    public TipoResidencial devuelveTipoResidencial()
    {
        return TipoResidencial.UNIFAMILIAR;
    }
    
    /**
     * Devuelve el Unifamiliar como String
     */
    public String toString()
    {
        return this.devuelveDatos() + "\n    " + this.devuelveTipoResidencial() + this.devuelveDatosVivienda();
    }
}
