import java.time.LocalDate;

/**
 * Clase abstracta Tarea. Todos los encargos del estudio arquitectónico son instancias de esta.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Tarea
{
    /**
     * Campos que tendrán todas las tareas del estudio
     * El identificador, la fecha de solicitud, la fecha de entrega,
     * los identificadores de los responsables de llevarla a cabo: arquitecto, aparejador y contable,
     * y el del cliente que la solicita
     */
    protected int identificador;
    protected LocalDate fechaSolicitud;
    protected LocalDate fechaEntrega;
    protected int identArq;
    protected int identApar;
    protected int identCont;
    protected int tipoEdif;
    protected int identEdif;
    protected int identClien;
    
    /**
     * Campo que es responsabilidad del contable:
     * El presupuesto en euros.
     */
    protected int presupuesto;
    
    /**
     * Constructor
     */
    public Tarea(int identificador)
    {
        this.fechaEntrega = null;
        this.fechaSolicitud = null;
        this.identificador = identificador;
        this.identArq = -1;
        this.identApar = -1;
        this.identCont = -1;
        this.tipoEdif = -1;
        this.identEdif = -1;
        this.presupuesto = 0;
    }
    
    /**
     * Devuelve el identificador
     */
    public int devuelveIdentificador()
    {
        return this.identificador;
    }
    
    /**
     * Devuelve la fecha de solicitud
     */
    public LocalDate devuelveFechaSolicitud()
    {
        return fechaSolicitud;
    }
    
    /**
     * Modifica la fecha de solicitud
     */
    public void modificaFechaSolicitud(LocalDate fechaSolicitud)
    {
        this.fechaSolicitud = fechaSolicitud;
    }
    
    /**
     * Devuelve la fecha de entrega
     */
    public LocalDate devuelveFechaEntrega()
    {
        return fechaEntrega;
    }
    
    /**
     * Modifica la fecha de entrega
     */
    public void modificaFechaEntrega(LocalDate fechaEntrega)
    {
        this.fechaEntrega = fechaEntrega;
    }
    
    /**
     * Devuelve el identificador del Arquitecto
     */
    public int devuelveIdentArq()
    {
        return this.identArq;
    }
    
    /**
     * Modifica el identificador del Arquitecto
     */
    public void modificaIdentArq(int identArq)
    {
        this.identArq = identArq;
    }
    
    /**
     * Devuelve el identificador del Aparejador
     */
    public int devuelveIdentApar()
    {
        return this.identApar;
    }
    
    /**
     * Modifica el identificador del Aparejador
     */
    public void modificaIdentApar(int identApar)
    {
        this.identApar = identApar;
    }
    
    /**
     * Devuelve el identificador del Contable
     */
    public int devuelveIdentCont()
    {
        return this.identCont;
    }
    
    /**
     * Modifica el identificador del Contable
     */
    public void modificaIdentCont(int identCont)
    {
        this.identCont = identCont;
    }
    
    /**
     * Devuelve el tipo de la Edificacion
     */
    public int devuelveTipoEdif()
    {
        return this.tipoEdif;
    }
    
    /**
     * Modifica el tipo de la Edificacion
     */
    public void modificaTipoEdif(int tipoEdif)
    {
        this.tipoEdif = tipoEdif;
    }
    
    /**
     * Devuelve el identificador de la Edificacion
     */
    public int devuelveIdentEdif()
    {
        return this.identEdif;
    }
    
    /**
     * Modifica el identificador del Edificacion
     */
    public void modificaIdentEdif(int identEdif)
    {
        this.identEdif = identEdif;
    }
    
    /**
     * Devuelve el identificador del cliente
     */
    public int devuelveIdentClien()
    {
        return this.identClien;
    }
    
    /**
     * Modifica el identificador del cliente
     */
    public void modificaIdentClien(int identClien)
    {
        this.identClien = identClien;
    }
    
    /**
     * Devuelve el presupuesto
     */
    public int devuelvePresupuesto()
    {
        return this.presupuesto;
    }
    
    /**
     * Modifica el presupuesto
     */
    public void modificaPresupuesto(int presupuesto)
    {
        this.presupuesto = presupuesto;
    }
    
    /**
     * Devuelve los datos básicos de la Tarea como String,
     * es parte de los métodos toString de las subclases.
     */
    protected String devuelveDatosTarea()
    {
        String datos = "\n    Fecha de solicitud " + this.fechaSolicitud;
        datos = datos.concat("\n    Fecha de entrega " + this.fechaEntrega + ".");
        datos = datos.concat("\n    Presupuesto ");
        if (this.presupuesto > 0) {
            datos = datos.concat(this.presupuesto + " €.");
        } else {
            datos = datos.concat("aún por determinar.");
        }
        return datos;
    }
}
