
/**
 * Clase Rehabilitacion. Es aplicable a los tres tipos de Edificaciones
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Rehabilitacion extends Proyecto
{
    /**
     * Campo específico de la clase Rehabilitacion:
     * La superficie que se reformará.
     */
    String superficieReformar;
    
    /**
     * Constructor
     */
    public Rehabilitacion(int identificador)
    {
        super(identificador);
        this.superficieReformar = "";
    }
    
    /**
     * Modifica la superficie a reformar
     */
    public void modificaSuperficieReformar(int superficieReformar)
    {
        String[] superficies = {"Edificio", "Exterior"};
        this.superficieReformar = superficies[superficieReformar];
    }

    /**
     * Devuelve la Rehabilitacion como String
     */
    public String toString()
    {
        String datos = "\n    Proyecto de rehabilitación";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosProyecto());
        datos = datos.concat("\n    Superficie a reformar: " + this.superficieReformar);
        return datos;
    }
}
