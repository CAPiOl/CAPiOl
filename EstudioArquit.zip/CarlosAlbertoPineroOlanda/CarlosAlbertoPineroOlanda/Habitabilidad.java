import java.time.LocalDate;

/**
 * Clase que representa los certificados de habitabilidad para edificios residenciales
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Habitabilidad extends Certificado
{
    /**
     * Campos específicos del Certificado de Habitabilidad:
     * La validez del certificado, siempre 15 años, y la fecha de visita del aparejador.
     */
    private final int validez = 15;
    private LocalDate fechaVisita;
    /**
     * El valor de este campo se actualiza automáticamente:
     * La fecha de caducidad.
     */
    private LocalDate fechaCaducidad;
    
    /**
     * Constructor
     */
    public Habitabilidad(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la fecha de visita del aparejador
     */
    public LocalDate devuelveFechaVisita()
    {
        return this.fechaVisita;
    }
    
    /**
     * Modifica la fecha de visita del aparejador
     */
    public void modificaFechaVisita(LocalDate fechaVisita)
    {
        this.fechaVisita = fechaVisita;
    }
    
    /**
     * Actualiza la fecha de caducidad
     */
    private void actualizaFechaCaduc()
    {
        if (this.fechaEmision != null){
            this.fechaCaducidad = this.fechaEmision.plusYears(this.validez);
        }
    }
    
    /**
     * Devuelve la fecha de caducidad. Primero la actualiza
     */
    public LocalDate devuelveFechaCaduc()
    {
        this.actualizaFechaCaduc();
        return this.fechaCaducidad;
    }
    
    /**
     * Devuelve datos de Habitabilidad como String
     */
    public String devuelveDatosCertificado()
    {
        String datos = "\n    Fecha de visita del aparejador " + this.fechaVisita + " Fecha de emisión " + this.fechaEmision;
        return datos;
    }
    
    /**
     * Devuelve Habitabilidad como String
     */
    public String toString()
    {
        this.actualizaFechaCaduc();
        String datos = "\n    Certificado de habitabilidad";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosCertificado() + " Fecha de caducidad " + this.fechaCaducidad);
        return datos;
    }
}
