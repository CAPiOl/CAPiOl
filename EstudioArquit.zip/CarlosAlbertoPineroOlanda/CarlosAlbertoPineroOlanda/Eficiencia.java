import java.time.LocalDate;

/**
 * Clase que representa los certificados de eficiencia energética
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Eficiencia extends Certificado
{
    /**
     * El tipo de Certificado para facilitar la identificación
     */
    private enum Categoria{A, B, C, D, E, F, G};
    
    /**
     * Campos específicos del Certificado de Eficiencia:
     * La fecha de visita del aparejador y la categoría
     */
    private LocalDate fechaVisita;
    private Categoria categoria;
    
    /**
     * Constructor
     */
    public Eficiencia(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la fecha de visita del aparejador
     */
    public LocalDate devuelveFechaVisita()
    {
        return this.fechaVisita;
    }
    
    /**
     * Modifica la fecha de visita del aparejador
     */
    public void modificaFechaVisita(LocalDate fechaVisita)
    {
        this.fechaVisita = fechaVisita;
    }
    
    /**
     * Devuelve la categoría
     */
    public Categoria devuelveCategoria()
    {
        return this.categoria;
    }
    
    /**
     * Modifica la categoría
     */
    public void modificaCategoria(int categoria)
    {
        Categoria[] categorias = {
            Categoria.A, Categoria.B, Categoria.C, Categoria.D, Categoria.E, Categoria.F, Categoria.G};
        this.categoria = categorias[categoria];
    }
    
    /**
     * Devuelve datos de Eficiencia como String
     */
    public String devuelveDatosCertificado()
    {
        String datos = "\n    Fecha de visita del aparejador " + this.fechaVisita + " Fecha de emisión " + this.fechaEmision;
        return datos;
    }
    
    /**
     * Devuelve Eficiencia como String
     */
    public String toString()
    {
        String datos = "\n    Certificado de eficiencia energética";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosCertificado() + " Categoría " + this.categoria);
        return datos;
    }
}
