
/**
 * La clase Contable define al Empleado que asignará los presupuestos
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Contable extends Empleado
{
    /**
     * Constructor
     */
    public Contable(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    public TipoUsuario devuelveUsuario()
    {
        return TipoUsuario.CONTABLE;
    }
}
