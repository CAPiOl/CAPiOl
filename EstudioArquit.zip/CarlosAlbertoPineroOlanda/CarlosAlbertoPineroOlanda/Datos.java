import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.io.DataInputStream;
import java.io.IOException;

/**
 * La clase Datos define todas las operaciones necesarias para registrar todos los objetos que se crearán.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Datos
{
    /**
     * Campos de la clase Datos.
     */
    private ArrayList<Administrador> administradores;
    private ArrayList<Arquitecto> arquitectos;
    private ArrayList<Aparejador> aparejadores;
    private ArrayList<Contable> contables;
    private ArrayList<Cliente> clientes;
    
    private ArrayList<Unifamiliar> unifamiliares;
    private ArrayList<Comunitario> comunitarios;
    private ArrayList<NoResidencial> noResidenciales;
    
    private ArrayList<ConstruccionRes> construccionesRes;
    private ArrayList<ConstruccionNoRes> construccionesNoRes;
    private ArrayList<Rehabilitacion> rehabilitaciones;
    
    private ArrayList<Proyecto> proyectos1;
    private ArrayList<Proyecto> proyectos2;
    private ArrayList<Proyecto> proyectos3;
    
    private ArrayList<Habitabilidad> habitabilidades;
    private ArrayList<Inspeccion> inspecciones;
    private ArrayList<Eficiencia> eficiencias;
    private ArrayList<Pericial> periciales;
    
    private int contEmpl;
    private int contClien;
    private int contEdif;
    private int contProy;
    private int contCert;
    
    /**
     * Constructor
     */
    public Datos()
    {
        this.administradores = new ArrayList();
        this.arquitectos = new ArrayList();
        this.aparejadores = new ArrayList();
        this.contables = new ArrayList();
        this.clientes = new ArrayList();
        
        this.unifamiliares = new ArrayList();
        this.comunitarios = new ArrayList();
        this.noResidenciales = new ArrayList();
        
        this.construccionesRes = new ArrayList();
        this.construccionesNoRes = new ArrayList();
        this.rehabilitaciones = new ArrayList();
        
        this.proyectos1 = new ArrayList();
        this.proyectos2 = new ArrayList();
        this.proyectos3 = new ArrayList();
        
        this.habitabilidades = new ArrayList();
        this.inspecciones = new ArrayList();
        this.eficiencias = new ArrayList();
        this.periciales = new ArrayList();
        
        this.contEmpl = 0;
        this.contClien = 0;
        this.contEdif = 0;
        this.contProy = 0;
        this.contCert = 0;
    }

    /**
     * Introduce a un nuevo Empleado dentro del sistema
     */
    public void insertaEmpleado(int tipoEmpleado, String nombre)
    {
        switch (tipoEmpleado)
        {
            case 1:
                Administrador administrador = new Administrador(nombre, this.contEmpl);
                this.administradores.add(administrador);
                this.contEmpl++;
                break;
            case 2:
                Arquitecto arquitecto = new Arquitecto(nombre, this.contEmpl);
                this.arquitectos.add(arquitecto);
                this.contEmpl++;
                break;
            case 3:
                Aparejador aparejador = new Aparejador(nombre, this.contEmpl);
                this.aparejadores.add(aparejador);
                this.contEmpl++;
                break;
            case 4:
                Contable contable = new Contable(nombre, this.contEmpl);
                this.contables.add(contable);
                this.contEmpl++;
                break;
        }
    }
    
    /**
     * Cambia el nombre de un Empleado
     */
    public void nombraEmpleado(int tipoEmpleado, int posicion, String nombre)
    {
        switch (tipoEmpleado)
        {
            case 1:
                Administrador administrador = this.administradores.get(posicion);
                administrador.modificaNombre(nombre);
                break;
            case 2:
                Arquitecto arquitecto = this.arquitectos.get(posicion);
                arquitecto.modificaNombre(nombre);
                break;
            case 3:
                Aparejador aparejador = this.aparejadores.get(posicion);
                aparejador.modificaNombre(nombre);
                break;
            case 4:
                Contable contable = this.contables.get(posicion);
                contable.modificaNombre(nombre);
                break;
        }
    }
    
    /**
     * Elimina a un Empleado si no hay tareas asociadas al mismo
     */
    public void eliminaEmpleado(int tipoEmpleado, int posicion)
    {
        boolean excedente = true;
        switch (tipoEmpleado)
        {
            case 1:
                this.administradores.remove(posicion);
                break;
            case 2:
                for (ConstruccionRes consRes : this.construccionesRes)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == consRes.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == consNoRes.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == rehab.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (Habitabilidad habitab : this.habitabilidades)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == habitab.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (Inspeccion inspec : this.inspecciones)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == inspec.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == efic.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                for (Pericial peric : this.periciales)
                {
                    if (!excedente){
                        break;
                    } else if (this.arquitectos.get(posicion).devuelveIdentificador() == peric.devuelveIdentArq()){
                        excedente = false;
                    }
                }
                if (excedente){
                    this.arquitectos.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
            case 3:
                for (ConstruccionRes consRes : this.construccionesRes)
                {
                    if (!excedente){
                        break;
                    } else if (this.aparejadores.get(posicion).devuelveIdentificador() == consRes.devuelveIdentApar()){
                        excedente = false;
                    }
                }
                    for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
                    {
                    if (!excedente){
                        break;
                    } else if (this.aparejadores.get(posicion).devuelveIdentificador() == consNoRes.devuelveIdentApar()){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    if (!excedente){
                        break;
                    } else if (this.aparejadores.get(posicion).devuelveIdentificador() == rehab.devuelveIdentApar()){
                        excedente = false;
                    }
                }
                for (Habitabilidad habitab : this.habitabilidades)
                {
                    if (!excedente){
                        break;
                    } else if (this.aparejadores.get(posicion).devuelveIdentificador() == habitab.devuelveIdentApar()){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    if (!excedente){
                        break;
                    } else if (this.aparejadores.get(posicion).devuelveIdentificador() == efic.devuelveIdentApar()){
                        excedente = false;
                    }
                }
                if (excedente){
                    this.aparejadores.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
            case 4:
                for (ConstruccionRes consRes : this.construccionesRes)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == consRes.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == consNoRes.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == rehab.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (Habitabilidad habitab : this.habitabilidades)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == habitab.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (Inspeccion inspec : this.inspecciones)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == inspec.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == efic.devuelveIdentCont()){
                        excedente = false;
                    }
                }
                for (Pericial peric : this.periciales)
                {
                    if (!excedente){
                        break;
                    } else if (this.contables.get(posicion).devuelveIdentificador() == peric.devuelveIdentCont()){
                        excedente = false;
                        }
                }
                if (excedente){
                    this.contables.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
        }
    }
    
    /**
     * Devuelve el número de Empleados de un tipo determinado
     */
    public int devuelveNumEmpleado(int tipoEmpleado)
    {
        int num = -1;
        switch (tipoEmpleado)
        {
            case 1:
                num = this.administradores.size();
                break;
            case 2:
                num = this.arquitectos.size();
                break;
            case 3:
                num = this.aparejadores.size();
                break;
            case 4:
                num = this.contables.size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza una lista de Empleados
     */
    public void visualizaEmpleados(int tipoEmpleado)
    {
        switch (tipoEmpleado)
        {
            case 1:
                System.out.println("\n    Listado de administradores.");
                for (Administrador administrador : this.administradores)
                {
                    int id = this.administradores.indexOf(administrador) + 1;
                    System.out.println("    " + id + " " + administrador);
                }
                break;
            case 2:
                System.out.println("\n    Listado de arquitectos.");
                for (Arquitecto arquitecto : this.arquitectos)
                {
                    int id = this.arquitectos.indexOf(arquitecto) + 1;
                    System.out.println("    " + id + " " + arquitecto);
                }
                break;
            case 3:
                System.out.println("\n    Listado de aparejadores.");
                for (Aparejador aparejador : this.aparejadores)
                {
                    int id = this.aparejadores.indexOf(aparejador) + 1;
                    System.out.println("    " + id + " " + aparejador);
                }
                break;
            case 4:
                System.out.println("\n    Listado de contables");
                for (Contable contable : this.contables)
                {
                    int id = this.contables.indexOf(contable) + 1;
                    System.out.println("    " + id + " " + contable);
                }
                break;
        }
    }
    
    /**
     * Devuelve el identificador de un Empleado
     */
    public int devuelveIdentEmpleado(int tipoEmpleado, int posic)
    {
        int identif = -1;
        switch (tipoEmpleado)
        {
            case 1:
                identif = this.administradores.get(posic).devuelveIdentificador();
                break;
            case 2:
                identif = this.arquitectos.get(posic).devuelveIdentificador();
                break;
            case 3:
                identif = this.aparejadores.get(posic).devuelveIdentificador();
                break;
            case 4:
                identif = this.contables.get(posic).devuelveIdentificador();
                break;
        }
        return identif;
    }
    
    /**
     * Encuentra un Arquitecto según su identificador
     */
    private Arquitecto encuentraArq(int identArq)
    {
        for (Arquitecto arquitecto : this.arquitectos)
        {
            if (arquitecto.devuelveIdentificador() == identArq)
            {
                return arquitecto;
            }
        }
        return null;
    }
    
    /**
     * Encuentra un Aparejador según su identificador
     */
    private Aparejador encuentraApar(int identApar)
    {
        for (Aparejador aparejador : this.aparejadores)
        {
            if (aparejador.devuelveIdentificador() == identApar)
            {
                return aparejador;
            }
        }
        return null;
    }
    
    /**
     * Encuentra un Contable según su identificador
     */
    private Contable encuentraCont(int identCont)
    {
        for (Contable contable : this.contables)
        {
            if (contable.devuelveIdentificador() == identCont)
            {
                return contable;
            }
        }
        return null;
    }
    
    /**
     * Introduce a un nuevo Cliente dentro del sistema
     */
    public void insertaCliente(String nombre)
    {
        Cliente cliente = new Cliente(nombre, this.contClien);
        this.clientes.add(cliente);
        this.contClien++;
    }
    
    /**
     * Cambia el nombre de un Cliente del sistema
     */
    public void nombraCliente(int posicion, String nombre)
    {
        Cliente cliente = this.clientes.get(posicion);
        cliente.modificaNombre(nombre);
    }
    
    /**
     * Modifica los datos de contacto de un Cliente del sistema
     */
    public void contactaCliente(int posicion, String direccion, String telefonoFijo, String telefonoMovil, String email)
    {
        Cliente cliente = this.clientes.get(posicion);
        cliente.modificaContacto(direccion, telefonoFijo, telefonoMovil, email);
    }
    
    /**
     * Elimina a un Cliente del sistema si no tiene Edificaciones asociadas
     */
    public void eliminaCliente(int posicion)
    {
        boolean excedente = true;
        for (Unifamiliar unif : this.unifamiliares)
        {
            if (!excedente){
                break;
            } else if (this.clientes.get(posicion).devuelveIdentificador() == unif.devuelveIdentCliente()){
                excedente = false;
            }
        }
        for (Comunitario comun : this.comunitarios)
        {
            if (!excedente){
                break;
            } else if (this.clientes.get(posicion).devuelveIdentificador() == comun.devuelveIdentCliente()){
                excedente = false;
            }
        }
        for (NoResidencial noRes : this.noResidenciales)
        {
            if (!excedente){
                break;
            } else if (this.clientes.get(posicion).devuelveIdentificador() == noRes.devuelveIdentCliente()){
                excedente = false;
            }
        }
        if (excedente){
           this.clientes.remove(posicion);
        } else {
            System.out.println("    Encargó alguna tarea, no se puede eliminar.");
        }
    }
    
    /**
     * Devuelve el número de Clientes
     */
    public int devuelveNumClien()
    {
        return this.clientes.size();
    }
    
    /**
     * Visualiza una lista de Clientes
     */
    private void visualizaListaClientes(ArrayList<Cliente> listaClientes)
    {
        for (Cliente cliente : listaClientes)
        {
            int id = listaClientes.indexOf(cliente) + 1;
            System.out.println("    " + id + " " + cliente);
        }
    }
    
    /**
     * Visualiza el listado completo de todos los clientes del sistema
     */
    public void visualizaClientes()
    {
        System.out.println("\n    Listado de clientes");
        this.visualizaListaClientes(this.clientes);
    }
    
    /**
     * Encuentra un Cliente según su identificador
     */
    private Cliente encuentraClien(int identClien)
    {
        for (Cliente cliente : this.clientes)
        {
            if (cliente.devuelveIdentificador() == identClien)
            {
                return cliente;
            }
        }
        return null;
    }
    
    /**
     * Devuelve la lista de Clientes para las que ha trabajado un Arquitecto
     */
    private ArrayList<Cliente> devuelveListaClientesPorArq(int identArq)
    {
        ArrayList<Cliente> clientesArq = new ArrayList<Cliente>();
        for (ConstruccionRes consRes : this.construccionesRes)
        {
            int nuevaIdentArq = consRes.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = consRes.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
        {
            int nuevaIdentArq = consNoRes.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = consNoRes.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (Rehabilitacion rehab : this.rehabilitaciones)
        {
            int nuevaIdentArq = rehab.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = rehab.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (Habitabilidad habit : this.habitabilidades)
        {
            int nuevaIdentArq = habit.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = habit.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (Inspeccion inspec : this.inspecciones)
        {
            int nuevaIdentArq = inspec.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = inspec.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (Eficiencia efic : this.eficiencias)
        {
            int nuevaIdentArq = efic.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = efic.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        for (Pericial peric : this.periciales)
        {
            int nuevaIdentArq = peric.devuelveIdentArq();
            boolean incluido = false;
            if (identArq == nuevaIdentArq){
                int identClien = peric.devuelveIdentClien();
                for (Cliente cliente : clientesArq)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesArq.add(nuevoClien);
                }
            }
        }
        return clientesArq;
    }
    
    /**
     * Devuelve la lista de Clientes para las que ha trabajado un Aparejador
     */
    private ArrayList<Cliente> devuelveListaClientesPorApar(int identApar)
    {
        ArrayList<Cliente> clientesApar = new ArrayList<Cliente>();
        for (ConstruccionRes consRes : this.construccionesRes)
        {
            int nuevaIdentApar = consRes.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = consRes.devuelveIdentClien();
                for (Cliente cliente : clientesApar)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesApar.add(nuevoClien);
                }
            }
        }
        for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
        {
            int nuevaIdentApar = consNoRes.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = consNoRes.devuelveIdentClien();
                for (Cliente cliente : clientesApar)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesApar.add(nuevoClien);
                }
            }
        }
        for (Rehabilitacion rehab : this.rehabilitaciones)
        {
            int nuevaIdentApar = rehab.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = rehab.devuelveIdentClien();
                for (Cliente cliente : clientesApar)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesApar.add(nuevoClien);
                }
            }
        }
        for (Habitabilidad habit : this.habitabilidades)
        {
            int nuevaIdentApar = habit.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = habit.devuelveIdentClien();
                for (Cliente cliente : clientesApar)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesApar.add(nuevoClien);
                }
            }
        }
        for (Eficiencia efic : this.eficiencias)
        {
            int nuevaIdentApar = efic.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = efic.devuelveIdentClien();
                for (Cliente cliente : clientesApar)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesApar.add(nuevoClien);
                }
            }
        }
        return clientesApar;
    }
    
    /**
     * Devuelve la lista de Clientes para los que un Aparejador tiene visitas pendientes
     */
    private ArrayList<Cliente> devuelveListaClientesPendPorApar(int identApar)
    {
        ArrayList<Cliente> clientesApar = new ArrayList<Cliente>();
        for (Habitabilidad habit : this.habitabilidades)
        {
            int nuevaIdentApar = habit.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = habit.devuelveIdentClien();
                if (habit.devuelveFechaVisita().isAfter(LocalDate.now())){
                    for (Cliente cliente : clientesApar)
                    {
                        if (cliente.devuelveIdentificador() == identClien){
                            incluido = true;
                            break;
                        }
                    }
                    if (!incluido){
                        Cliente nuevoClien = this.encuentraClien(identClien);
                        clientesApar.add(nuevoClien);
                    }
                }
            }
        }
        for (Eficiencia efic : this.eficiencias)
        {
            int nuevaIdentApar = efic.devuelveIdentApar();
            boolean incluido = false;
            if (identApar == nuevaIdentApar){
                int identClien = efic.devuelveIdentClien();
                if (efic.devuelveFechaVisita().isAfter(LocalDate.now())){
                    for (Cliente cliente : clientesApar)
                    {
                        if (cliente.devuelveIdentificador() == identClien){
                            incluido = true;
                            break;
                        }
                    }
                    if (!incluido){
                        Cliente nuevoClien = this.encuentraClien(identClien);
                        clientesApar.add(nuevoClien);
                    }
                }
            }
        }
        return clientesApar;
    }
    
    /**
     * Devuelve la lista de Clientes para las que ha trabajado un Contable
     */
    private ArrayList<Cliente> devuelveListaClientesPorCont(int identCont)
    {
        ArrayList<Cliente> clientesCont = new ArrayList<Cliente>();
        for (ConstruccionRes consRes : this.construccionesRes)
        {
            int nuevaIdentCont = consRes.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = consRes.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
        {
            int nuevaIdentCont = consNoRes.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = consNoRes.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (Rehabilitacion rehab : this.rehabilitaciones)
        {
            int nuevaIdentCont = rehab.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = rehab.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (Habitabilidad habit : this.habitabilidades)
        {
            int nuevaIdentCont = habit.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = habit.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (Inspeccion inspec : this.inspecciones)
        {
            int nuevaIdentCont = inspec.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = inspec.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (Eficiencia efic : this.eficiencias)
        {
            int nuevaIdentCont = efic.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = efic.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        for (Pericial peric : this.periciales)
        {
            int nuevaIdentCont = peric.devuelveIdentCont();
            boolean incluido = false;
            if (identCont == nuevaIdentCont){
                int identClien = peric.devuelveIdentClien();
                for (Cliente cliente : clientesCont)
                {
                    if (cliente.devuelveIdentificador() == identClien){
                        incluido = true;
                        break;
                    }
                }
                if (!incluido){
                    Cliente nuevoClien = this.encuentraClien(identClien);
                    clientesCont.add(nuevoClien);
                }
            }
        }
        return clientesCont;
    }
    
    /**
     * Devuelve el número de Clientes para los que ha trabajado un Empleado
     */
    public int devuelveNumClientesPorEmpl(int tipoEmpl, int posicion)
    {
        int num = -1;
        switch (tipoEmpl)
        {
            case 2:
                num = this.devuelveListaClientesPorArq(this.arquitectos.get(posicion).devuelveIdentificador()).size();
                break;
            case 3:
                num = this.devuelveListaClientesPorApar(this.aparejadores.get(posicion).devuelveIdentificador()).size();
                break;
            case 4:
                num = this.devuelveListaClientesPorCont(this.contables.get(posicion).devuelveIdentificador()).size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza el listado completo de los clientes de un Arquitecto
     */
    public void visualizaClientesPorArquitecto(int identArq)
    {
        ArrayList<Cliente> clientesArq = this.devuelveListaClientesPorArq(identArq);
        System.out.println("\n    Listado de clientes del arquitecto.");
        this.visualizaListaClientes(clientesArq);
    }
    
    /**
     * Visualiza el listado completo de los clientes de un Aparejador
     */
    public void visualizaClientesPorAparejador(int identApar)
    {
        ArrayList<Cliente> clientesApar = this.devuelveListaClientesPorApar(identApar);
        System.out.println("\n    Listado de clientes del aparejador.");
        this.visualizaListaClientes(clientesApar);
    }
    
    /**
     * Visualiza el listado completo de los clientes pendientes de una visita de un Aparejador
     */
    public void visualizaClientesPendApar(int identApar)
    {
        ArrayList<Cliente> clientesApar = this.devuelveListaClientesPendPorApar(identApar);
        System.out.println("\n    Listado de clientes del aparejador.");
        this.visualizaListaClientes(clientesApar);
    }
    
    /**
     * Visualiza el listado completo de los clientes de un Contable
     */
    public void visualizaClientesPorContable(int identCont)
    {
        ArrayList<Cliente> clientesCont = this.devuelveListaClientesPorCont(identCont);
        System.out.println("\n    Listado de clientes del contable.");
        this.visualizaListaClientes(clientesCont);
    }
    
    /**
     * Visualiza el listado completo de los clientes de un Empleado
     */
    public void visualizaClientesPorEmpleado(int tipoEmpl, int posicion)
    {
        switch (tipoEmpl)
        {
            case 2:
                this.visualizaClientesPorArquitecto(this.arquitectos.get(posicion).devuelveIdentificador());
                break;
            case 3:
                this.visualizaClientesPorAparejador(this.aparejadores.get(posicion).devuelveIdentificador());
                break;
            case 4:
                this.visualizaClientesPorContable(this.contables.get(posicion).devuelveIdentificador());
                break;
        }
    }
    
    /**
     * Introduce una nueva Edificacion dentro del sistema
     */
    public void insertaEdificacion(int tipoEdificacion)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = new Unifamiliar(this.contEdif);
                this.unifamiliares.add(unifamiliar);
                this.contEdif++;
                break;
            case 2:
                Comunitario comunitario = new Comunitario(this.contEdif);
                this.comunitarios.add(comunitario);
                this.contEdif++;
                break;
            case 3:
                NoResidencial noResidencial = new NoResidencial(this.contEdif);
                this.noResidenciales.add(noResidencial);
                this.contEdif++;
                break;
        }
    }
    
    /**
     * Cambia el Cliente asociado a una Edificacion
     */
    public void cambiaClienteEdificacion(int tipoEdificacion, int posicion, int cliente)
    {
        int identificadorClien = this.clientes.get(cliente).devuelveIdentificador();
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaIdentCliente(identificadorClien);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaIdentCliente(identificadorClien);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaIdentCliente(identificadorClien);
                break;
        }
    }
    
    /**
     * Cambia el nombre de una Edificacion
     */
    public void nombraEdificacion(int tipoEdificacion, int posicion, String nombre)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaNombre(nombre);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaNombre(nombre);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaNombre(nombre);
                break;
        }
    }
    
    /**
     * Cambia la dirección de una Edificacion
     */
    public void cambiaDireccionEdificacion(int tipoEdificacion, int posicion, String direccion)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaDireccion(direccion);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaDireccion(direccion);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaDireccion(direccion);
                break;
        }
    }
    
    /**
     * Cambia la fecha de construcción de una Edificacion
     */
    public void cambiaFCreacEdificacion(int tipoEdificacion, int posicion, LocalDate fechaEdificacion)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaFechaConstr(fechaEdificacion);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaFechaConstr(fechaEdificacion);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaFechaConstr(fechaEdificacion);
                break;
        }
    }
    
    /**
     * Cambia la superficie de terreno de una Edificacion
     */
    public void cambiaTerrenoEdificacion(int tipoEdificacion, int posicion, int superficieTerreno)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaSuperficieTerreno(superficieTerreno);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaSuperficieTerreno(superficieTerreno);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaSuperficieTerreno(superficieTerreno);
                break;
        }
    }
    
    /**
     * Cambia la superficie de edificio de una Edificacion
     */
    public void cambiaSuperficieEdificioEdificacion(int tipoEdificacion, int posicion, int superficieEdificio)
    {
        switch (tipoEdificacion)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaSuperficieEdificio(superficieEdificio);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaSuperficieEdificio(superficieEdificio);
                break;
            case 3:
                NoResidencial noResidencial = this.noResidenciales.get(posicion);
                noResidencial.modificaSuperficieEdificio(superficieEdificio);
                break;
        }
    }
    
    /**
     * Cambia las características de la Vivienda de una Edificacion
     */
    public void cambiaViviendaResidencial(int tipoResidencial, int posicion, int plantas, int habitaciones, int aseos)
    {
        switch (tipoResidencial)
        {
            case 1:
                Unifamiliar unifamiliar = this.unifamiliares.get(posicion);
                unifamiliar.modificaViviendas(plantas, habitaciones, aseos);
                break;
            case 2:
                Comunitario comunitario = this.comunitarios.get(posicion);
                comunitario.modificaViviendas(habitaciones, aseos);
                break;
        }
    }
    
    /**
     * Elimina a un Edificacion si no hay tareas asociadas a esta
     */
    public void eliminaEdificacion(int tipoEdificacion, int posicion)
    {
        boolean excedente = true;
        switch (tipoEdificacion)
        {
            case 1:
                for (ConstruccionRes consRes : this.construccionesRes)
                {
                    int ident = this.unifamiliares.get(posicion).devuelveIdentificador();
                    int tipoEdif = consRes.devuelveTipoEdif();
                    int identEdif = consRes.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 1 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    int ident = this.unifamiliares.get(posicion).devuelveIdentificador();
                    int tipoEdif = rehab.devuelveTipoEdif();
                    int identEdif = rehab.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 1 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Habitabilidad habitab : this.habitabilidades)
                {
                    int ident = this.unifamiliares.get(posicion).devuelveIdentificador();
                    int tipoEdif = habitab.devuelveTipoEdif();
                    int identEdif = habitab.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 1 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    int ident = this.unifamiliares.get(posicion).devuelveIdentificador();
                    int tipoEdif = efic.devuelveTipoEdif();
                    int identEdif = efic.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 1 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Pericial peric : this.periciales)
                {
                    int ident = this.unifamiliares.get(posicion).devuelveIdentificador();
                    int tipoEdif = peric.devuelveTipoEdif();
                    int identEdif = peric.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 1 && ident == identEdif){
                        excedente = false;
                    }
                }
                if (excedente){
                    this.unifamiliares.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
            case 2:
                for (ConstruccionRes consRes : this.construccionesRes)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int tipoEdif = consRes.devuelveTipoEdif();
                    int identEdif = consRes.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 2 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int tipoEdif = rehab.devuelveTipoEdif();
                    int identEdif = rehab.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 2 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Habitabilidad habitab : this.habitabilidades)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int tipoEdif = habitab.devuelveTipoEdif();
                    int identEdif = habitab.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 2 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Inspeccion inspec : this.inspecciones)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int identEdif = inspec.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (ident == ident){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int tipoEdif = efic.devuelveTipoEdif();
                    int identEdif = efic.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 2 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Pericial peric : this.periciales)
                {
                    int ident = this.comunitarios.get(posicion).devuelveIdentificador();
                    int tipoEdif = peric.devuelveTipoEdif();
                    int identEdif = peric.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 2 && ident == identEdif){
                        excedente = false;
                    }
                }
                if (excedente){
                    this.comunitarios.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
            case 3:
                for (ConstruccionNoRes consNoRes : this.construccionesNoRes)
                {
                    int ident = this.noResidenciales.get(posicion).devuelveIdentificador();
                    int identEdif = consNoRes.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (ident == ident){
                        excedente = false;
                    }
                }
                for (Rehabilitacion rehab : this.rehabilitaciones)
                {
                    int ident = this.noResidenciales.get(posicion).devuelveIdentificador();
                    int tipoEdif = rehab.devuelveTipoEdif();
                    int identEdif = rehab.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 3 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Eficiencia efic : this.eficiencias)
                {
                    int ident = this.noResidenciales.get(posicion).devuelveIdentificador();
                    int tipoEdif = efic.devuelveTipoEdif();
                    int identEdif = efic.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 3 && ident == identEdif){
                        excedente = false;
                    }
                }
                for (Pericial peric : this.periciales)
                {
                    int identComun = this.noResidenciales.get(posicion).devuelveIdentificador();
                    int tipoEdif = peric.devuelveTipoEdif();
                    int identEdif = peric.devuelveIdentEdif();
                    if (!excedente){
                        break;
                    } else if (tipoEdif == 3 && identComun == identEdif){
                        excedente = false;
                    }
                }
                if (excedente){
                    this.noResidenciales.remove(posicion);
                } else {
                    System.out.println("    Está presente en alguna tarea, no se puede eliminar.");
                }
                break;
        }
    }
    
    /**
     * Devuelve la lista de Unifamiliares asociados a un Cliente
     */
    private ArrayList<Unifamiliar> devuelveUnifPorClien(int idenClien)
    {
        ArrayList<Unifamiliar> unifs = new ArrayList();
        for (Unifamiliar unifamiliar : this.unifamiliares)
        {
            if (idenClien == unifamiliar.devuelveIdentCliente()) {
                unifs.add(unifamiliar);
            }
        }
        return unifs;
    }
    
    /**
     * Devuelve la lista de Comunitarios asociados a un Cliente
     */
    private ArrayList<Comunitario> devuelveComunPorClien(int idenClien)
    {
        ArrayList<Comunitario> comuns = new ArrayList();
        for (Comunitario comunitario : this.comunitarios)
        {
            if (idenClien == comunitario.devuelveIdentCliente()) {
                comuns.add(comunitario);
            }
        }
        return comuns;
    }
    
    /**
     * Devuelve la lista de NoResidenciales asociados a un Cliente
     */
    private ArrayList<NoResidencial> devuelveNoResPorClien(int idenClien)
    {
        ArrayList<NoResidencial> noResids = new ArrayList();
        for (NoResidencial noResidencial : this.noResidenciales)
        {
            if (idenClien == noResidencial.devuelveIdentCliente()) {
                noResids.add(noResidencial);
            }
        }
        return noResids;
    }
    
    /**
     * Devuelve el número de Edificaciones de un tipo asociadas a un Cliente
     */
    public int devuelveNumEdifPorClien(int tipoEdificacion, int posicion)
    {
        int num = -1;
        switch (tipoEdificacion)
        {
            case 1:
                num = this.devuelveUnifPorClien(this.clientes.get(posicion).devuelveIdentificador()).size();
                break;
            case 2:
                num = this.devuelveComunPorClien(this.clientes.get(posicion).devuelveIdentificador()).size();
                break;
            case 3:
                num = this.devuelveNoResPorClien(this.clientes.get(posicion).devuelveIdentificador()).size();
                break;
        }
        return num;
    }
    
    /**
     * Devuelve el número de Edificaciones totales de un tipo
     */
    public int devuelveNumEdificacion(int tipoEdificacion)
    {
        int num = -1;
        switch (tipoEdificacion)
        {
            case 1:
                num = this.unifamiliares.size();
                break;
            case 2:
                num = this.comunitarios.size();
                break;
            case 3:
                num = this.noResidenciales.size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza un listado completo de Unifamiliares
     */
    private void visualizaListaUnif(ArrayList<Unifamiliar> listaUnifamiliar)
    {
        for (Unifamiliar unifamiliar : listaUnifamiliar)
        {
            int id = listaUnifamiliar.indexOf(unifamiliar) + 1;
            System.out.println("    " + id + " " + unifamiliar.devuelveNombre());
        }
    }
    
    /**
     * Visualiza un listado completo de Comunitarios
     */
    private void visualizaListaComun(ArrayList<Comunitario> listaComunitario)
    {
        for (Comunitario comunitario : listaComunitario)
        {
            int id = listaComunitario.indexOf(comunitario) + 1;
            System.out.println("    " + id + " " + comunitario.devuelveNombre());
        }
    }
    
    /**
     * Visualiza un listado completo de NoResidenciales
     */
    private void visualizaListaNoRes(ArrayList<NoResidencial> listaNoRes)
    {
        for (NoResidencial noResidencial : listaNoRes)
        {
            int id = listaNoRes.indexOf(noResidencial) + 1;
            System.out.println("    " + id + " " + noResidencial.devuelveNombre());
        }
    }
    
    /**
     * Visualiza el listado completo de Edificaciones asociadas a un Cliente
     */
    public void visualizaEdifPorClien(int tipoEdificacion, int posicion)
    {
        switch (tipoEdificacion)
        {
            case 1:
                this.visualizaListaUnif(this.devuelveUnifPorClien(this.clientes.get(posicion).devuelveIdentificador()));
                break;
            case 2:
                this.visualizaListaComun(this.devuelveComunPorClien(this.clientes.get(posicion).devuelveIdentificador()));
                break;
            case 3:
                this.visualizaListaNoRes(this.devuelveNoResPorClien(this.clientes.get(posicion).devuelveIdentificador()));
                break;
        }
    }
    
    /**
     * Visualiza el listado completo de un tipo de Edificaciones
     */
    public void visualizaEdificaciones(int tipoEdificacion)
    {
        switch (tipoEdificacion)
        {
            case 1:
                System.out.println("\n    Listado de edificios residenciales unifamiliares");
                this.visualizaListaUnif(this.unifamiliares);
                break;
            case 2:
                System.out.println("\n    Listado de edificios residenciales comunitarios");
                this.visualizaListaComun(this.comunitarios);
                break;
            case 3:
                System.out.println("\n    Listado de edificios no residenciales");
                this.visualizaListaNoRes(this.noResidenciales);
                break;
        }
    }
    
    /**
     * Encuentra un Unifamiliar según su identificador
     */
    private Unifamiliar encuentraUnif(int identUnif)
    {
        for (Unifamiliar unifamiliar : this.unifamiliares)
        {
            if (unifamiliar.devuelveIdentificador() == identUnif)
            {
                return unifamiliar;
            }
        }
        return null;
    }
    
    /**
     * Encuentra un Comunitario según su identificador
     */
    private Comunitario encuentraComun(int identComun)
    {
        for (Comunitario comunitario : this.comunitarios)
        {
            if (comunitario.devuelveIdentificador() == identComun)
            {
                return comunitario;
            }
        }
        return null;
    }
    
    /**
     * Encuentra un NoResidencial según su identificador
     */
    private NoResidencial encuentraNoResid(int NoResid)
    {
        for (NoResidencial noResidencial : this.noResidenciales)
        {
            if (noResidencial.devuelveIdentificador() == NoResid)
            {
                return noResidencial;
            }
        }
        return null;
    }
    
    /**
     * Cambia el número de plantas con pisos de un Comunitario
     */
    public void cambiaPlantasComunitario(int posicion, int plantasPisos)
    {
        Comunitario comunitario = this.comunitarios.get(posicion);
        comunitario.modificaPlantasPisos(plantasPisos);
    }
    
    /**
     * Cambia el número de pisos por planta de un Comunitario
     */
    public void cambiaPisosPorPlantaComunitario(int posicion, int pisosPorPlanta)
    {
        Comunitario comunitario = this.comunitarios.get(posicion);
        comunitario.modificaPisosPorPlanta(pisosPorPlanta);
    }
    
    /**
     * Cambia la finalidad de un NoResidencial
     */
    public void cambiaFinalidadNoResidencial(int posicion, int finalidad)
    {
        NoResidencial noResidencial = this.noResidenciales.get(posicion);
        noResidencial.modificaFinalidad(finalidad);
    }
    
    /**
     * Visualiza para el listado de Unifamiliares su necesidad de un certificado de Habitabilidad
     */
    private void visualizaUnifamHabitab()
    {
        System.out.println("\n    Listado de edificios residenciales unifamiliares");
        for (Unifamiliar unifamiliar : this.unifamiliares)
        {
            int id = this.unifamiliares.indexOf(unifamiliar) + 1;
            LocalDate fechaCaduc = unifamiliar.devuelveFechaCaduc();
            int identUnif = unifamiliar.devuelveIdentificador();
            for (Habitabilidad habitabilidad : this.habitabilidades)
            {
                if (habitabilidad.devuelveTipoEdif() == 1) {
                    int identEdif = habitabilidad.devuelveIdentEdif();
                    if (identUnif == identEdif) {
                        LocalDate fechaCaducCert = habitabilidad.devuelveFechaCaduc();
                        if (habitabilidad.devuelveFechaCaduc() != null && fechaCaducCert.isAfter(fechaCaduc)) {
                            fechaCaduc = fechaCaducCert;
                        }
                    }
                }
            }
            System.out.println("    " + id + " " + unifamiliar.devuelveNombre() + " Última fecha de habitabilidad " + fechaCaduc);
            if (fechaCaduc.isBefore(LocalDate.now()))
            {
                System.out.println("    Ha cumplido su certificado de habitabilidad. Contacta con el cliente.");
            }
            else
            {
                System.out.println("    Todo en orden.");
            }
        }
    }
    
    /**
     * Visualiza para el listado de Comunitarios su necesidad de un certificado de Habitabilidad
     */
    private void visualizaComunHabitab()
    {
        System.out.println("\n    Listado de edificios residenciales comunitarios");
        for (Comunitario comunitario : this.comunitarios)
        {
            int id = this.comunitarios.indexOf(comunitario) + 1;
            LocalDate fechaCaduc = comunitario.devuelveFechaCaduc();
            int identComun = comunitario.devuelveIdentificador();
            for (Habitabilidad habitabilidad : this.habitabilidades)
            {
                if (habitabilidad.devuelveTipoEdif() == 2) {
                    int identEdif = habitabilidad.devuelveIdentEdif();
                    if (identComun == identEdif) {
                        LocalDate fechaCaducCert = habitabilidad.devuelveFechaCaduc();
                        if (habitabilidad.devuelveFechaCaduc() != null && fechaCaducCert.isAfter(fechaCaduc)) {
                            fechaCaduc = fechaCaducCert;
                        }
                    }
                }
            }
            System.out.println("    " + id + " " + comunitario.devuelveNombre() + " Última fecha de habitabilidad " + fechaCaduc);
            if (fechaCaduc.isBefore(LocalDate.now()))
            {
                System.out.println("    Ha cumplido su certificado de habitabilidad. Contacta con el cliente.");
            }
            else
            {
                System.out.println("    Todo en orden.");
            }
        }
    }
    
    /**
     * Visualiza para el listado de todos los Residenciales su necesidad de un certificado de Habitabilidad
     */
    public void visualizaResidencialesHabitabilidad()
    {
        this.visualizaUnifamHabitab();
        this.visualizaComunHabitab();
    }
    
    /**
     * Visualiza para el listado de todos los Comunitarios su necesidad de un certificado de Inspeccion
     */
    public void visualizaComunSinInspecc()
    {
        int id = 0;
        for (Comunitario comunitario : this.comunitarios)
        {
            boolean tieneCert = false;
            int identComun = comunitario.devuelveIdentificador();
            for (Inspeccion inspeccion : this.inspecciones)
            {
                if (inspeccion.devuelveFechaEmision() != null && inspeccion.devuelveIdentEdif() == identComun) {
                    tieneCert = true;
                    break;
                }
            }
            if (comunitario.devuelveFechaInspeccion().isBefore(LocalDate.now()) && !tieneCert)
            {
                id++;
                LocalDate feInsp = comunitario.devuelveFechaInspeccion();
                System.out.println("    " + id + " " + comunitario.devuelveNombre() + " Fecha de inspección " + feInsp);
            }
        }
    }
    
    /**
     * Introduce un nuevo Proyecto dentro del sistema
     */
    public void insertaProyecto(int tipoProyecto)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = new ConstruccionRes(this.contProy);
                this.construccionesRes.add(construccionRes);
                this.contProy++;
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = new ConstruccionNoRes(this.contProy);
                this.construccionesNoRes.add(construccionNoRes);
                this.contProy++;
                break;
            case 3:
                Rehabilitacion rehabilitacion = new Rehabilitacion(this.contProy);
                this.rehabilitaciones.add(rehabilitacion);
                this.contProy++;
                break;
        }
    }
    
    /**
     * Cambia la fecha de solicitud de un Proyecto
     */
    public void cambiaSolicProyecto(int tipoProyecto, int posicion, LocalDate fechaSolicitud)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaFechaSolicitud(fechaSolicitud);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaFechaSolicitud(fechaSolicitud);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaFechaSolicitud(fechaSolicitud);
                break;
        }
    }
    
    /**
     * Cambia la fecha de entrega de un Proyecto
     */
    public void cambiaEntregaProyecto(int tipoProyecto, int posicion, LocalDate fechaEntrega)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaFechaEntrega(fechaEntrega);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaFechaEntrega(fechaEntrega);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaFechaEntrega(fechaEntrega);
                break;
        }
    }
    
    /**
     * Cambia el Arquitecto de un Proyecto
     */
    public void cambiaArquitectoProyecto(int tipoProyecto, int posicion, int identArq)
    {
        identArq = this.arquitectos.get(identArq).devuelveIdentificador();
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaIdentArq(identArq);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaIdentArq(identArq);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaIdentArq(identArq);
                break;
        }
    }
    
    /**
     * Cambia el Aparejador de un Proyecto
     */
    public void cambiaAparejadorProyecto(int tipoProyecto, int posicion, int identApar)
    {
        identApar = this.aparejadores.get(identApar).devuelveIdentificador();
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaIdentApar(identApar);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaIdentApar(identApar);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaIdentApar(identApar);
                break;
        }
    }
    
    /**
     * Cambia el Contable de un Proyecto
     */
    public void cambiaContableProyecto(int tipoProyecto, int posicion, int identCont)
    {
        identCont = this.contables.get(identCont).devuelveIdentificador();
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaIdentCont(identCont);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaIdentCont(identCont);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaIdentCont(identCont);
                break;
        }
    }
    
    /**
     * Cambia el Cliente de un Proyecto
     */
    private void cambiaClienteProyecto(int tipoProyecto, int posicion, int identClien)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaIdentClien(identClien);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaIdentClien(identClien);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaIdentClien(identClien);
                break;
        }
    }
    
    /**
     * Cambia la Edificacion de un Proyecto
     */
    public void cambiaEdifProyecto(int tipoProyecto, int posicion, int tipoEdif, int identEdif)
    {
        int identClien = 0;
        switch (tipoEdif)
        {
            case 1:
                identClien = this.unifamiliares.get(identEdif).devuelveIdentCliente();
                identEdif = this.unifamiliares.get(identEdif).devuelveIdentificador();
                break;
            case 2:
                identClien = this.comunitarios.get(identEdif).devuelveIdentCliente();
                identEdif = this.comunitarios.get(identEdif).devuelveIdentificador();
                break;
            case 3:
                identClien = this.noResidenciales.get(identEdif).devuelveIdentCliente();
                identEdif = this.noResidenciales.get(identEdif).devuelveIdentificador();
                break;
        }
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.construccionesRes.get(posicion);
                construccionRes.modificaTipoEdif(tipoEdif);
                construccionRes.modificaIdentEdif(identEdif);
                construccionRes.modificaIdentClien(identClien);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.construccionesNoRes.get(posicion);
                construccionNoRes.modificaTipoEdif(tipoEdif);
                construccionNoRes.modificaIdentEdif(identEdif);
                construccionNoRes.modificaIdentClien(identClien);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
                rehabilitacion.modificaTipoEdif(tipoEdif);
                rehabilitacion.modificaIdentEdif(identEdif);
                rehabilitacion.modificaIdentClien(identClien);
                break;
        }
    }
    
    /**
     * Cambia la duración prevista de un Proyecto
     */
    public void cambiaDuracionPrevProyecto(int tipoProyecto, int posicion,
    int annos, int meses, int dias, int identEmp)
    {
        Period duracionPrev = Period.of(annos, meses, dias);
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.devuelveConstrResPorEmpl(2, identEmp).get(posicion);
                if (construccionRes.devuelveDuracionPrev() == null){
                    construccionRes.modificaDuracionPrev(duracionPrev);
                }
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.devuelveConstrNoResPorEmpl(2, identEmp).get(posicion);
                if (construccionNoRes.devuelveDuracionPrev() == null){
                    construccionNoRes.modificaDuracionPrev(duracionPrev);
                }
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.devuelveRehabPorEmpl(2, identEmp).get(posicion);
                if (rehabilitacion.devuelveDuracionPrev() == null){
                    rehabilitacion.modificaDuracionPrev(duracionPrev);
                }
                break;
        }
    }
    
    /**
     * Cambia la fecha de fin de obras de un Proyecto
     */
    public void cambiaFechaFinObrasProyecto(int tipoProyecto, int posicion, LocalDate fechaFinObras, int identEmp)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.devuelveConstrResPorEmpl(2, identEmp).get(posicion);
                construccionRes.modificaFechaInicObras(fechaFinObras);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.devuelveConstrNoResPorEmpl(2, identEmp).get(posicion);
                construccionNoRes.modificaFechaInicObras(fechaFinObras);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.devuelveRehabPorEmpl(2, identEmp).get(posicion);
                rehabilitacion.modificaFechaInicObras(fechaFinObras);
                break;
        }
    }
    
    /**
     * Cambia el presupuesto de un Proyecto
     */
    public void cambiaPresupuestoProyecto(int tipoProyecto, int posicion, int presupuesto, int identEmp)
    {
        switch (tipoProyecto)
        {
            case 1:
                ConstruccionRes construccionRes = this.devuelveConstrResPorEmpl(4, identEmp).get(posicion);
                construccionRes.modificaPresupuesto(presupuesto);
                break;
            case 2:
                ConstruccionNoRes construccionNoRes = this.devuelveConstrNoResPorEmpl(4, identEmp).get(posicion);
                construccionNoRes.modificaPresupuesto(presupuesto);
                break;
            case 3:
                Rehabilitacion rehabilitacion = this.devuelveRehabPorEmpl(4, identEmp).get(posicion);
                rehabilitacion.modificaPresupuesto(presupuesto);
                break;
        }
    }
    
    /**
     * Cambia la superficie a reformar de una Rehabilitacion
     */
    public void cambiaSupReforRehabilitacion(int posicion, int superficieReformar)
    {
        Rehabilitacion rehabilitacion = this.rehabilitaciones.get(posicion);
        rehabilitacion.modificaSuperficieReformar(superficieReformar);
    }
    
    /**
     * Elimina un Proyecto si no está incluido en la Planificación
     */
    public void eliminaProyecto(int tipoProyecto, int posicion)
    {
        boolean enLinea1 = false;
        boolean enLinea2 = false;
        boolean enLinea3 = false;
        switch (tipoProyecto)
        {
            case 1:
                enLinea1 = this.proyectos1.contains(construccionesRes.get(posicion));
                enLinea2 = this.proyectos2.contains(construccionesRes.get(posicion));
                enLinea3 = this.proyectos1.contains(construccionesRes.get(posicion));
                if (!(enLinea1 || enLinea2 || enLinea3)) {
                    this.construccionesRes.remove(posicion);
                }
                break;
            case 2:
                enLinea1 = this.proyectos1.contains(construccionesNoRes.get(posicion));
                enLinea2 = this.proyectos2.contains(construccionesNoRes.get(posicion));
                enLinea3 = this.proyectos1.contains(construccionesNoRes.get(posicion));
                if (!(enLinea1 || enLinea2 || enLinea3)) {
                    this.construccionesNoRes.remove(posicion);
                }
                break;
            case 3:
                enLinea1 = this.proyectos1.contains(rehabilitaciones.get(posicion));
                enLinea2 = this.proyectos2.contains(rehabilitaciones.get(posicion));
                enLinea3 = this.proyectos1.contains(rehabilitaciones.get(posicion));
                if (!(enLinea1 || enLinea2 || enLinea3)) {
                    this.rehabilitaciones.remove(posicion);
                }
                break;
        }
    }
    
    /**
     * Devuelve la lista de ConstruccionRes asociadas a un Residencial
     */
    private ArrayList<ConstruccionRes> devuelveConsResPorRes(int identRes)
    {
        ArrayList<ConstruccionRes> consRes = new ArrayList();
        for (ConstruccionRes construccionRes : this.construccionesRes)
        {
            if (construccionRes.devuelveIdentEdif() == identRes) {
                consRes.add(construccionRes);
            }
        }
        return consRes;
    }
    
    /**
     * Devuelve la lista de ConstruccionNoRes asociadas a un NoResidencial
     */
    private ArrayList<ConstruccionNoRes> devuelveConsNoResPorNoRes(int identNoRes)
    {
        ArrayList<ConstruccionNoRes> consNoRes = new ArrayList();
        for (ConstruccionNoRes construccionNoRes : this.construccionesNoRes)
        {
            if (construccionNoRes.devuelveIdentEdif() == identNoRes) {
                consNoRes.add(construccionNoRes);
            }
        }
        return consNoRes;
    }
    
    /**
     * Devuelve la lista de Rehabilitaciones asociadas a una Edificacion
     */
    private ArrayList<Rehabilitacion> devuelveRehabPorEdif(int identRehab)
    {
        ArrayList<Rehabilitacion> rehab = new ArrayList();
        for (Rehabilitacion rehabilitacion : this.rehabilitaciones)
        {
            if (rehabilitacion.devuelveIdentEdif() == identRehab) {
                rehab.add(rehabilitacion);
            }
        }
        return rehab;
    }
    
    /**
     * Devuelve el número de Proyectos asociados a una Edificacion
     */
    public int devuelveNumProyPorEdif(int tipoProy, int tipoEdif, int posicion)
    {
        int num = -1;
        switch (tipoProy)
        {
            case 1:
                if (tipoEdif == 1) {
                    num = this.devuelveConsResPorRes(this.unifamiliares.get(posicion).devuelveIdentificador()).size();
                } else {
                    num = this.devuelveConsResPorRes(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                }
                break;
            case 2:
                num = this.devuelveConsNoResPorNoRes(this.noResidenciales.get(posicion).devuelveIdentificador()).size();
                break;
            case 3:
                if (tipoEdif == 1) {
                    num = this.devuelveRehabPorEdif(this.unifamiliares.get(posicion).devuelveIdentificador()).size();
                } else if (tipoEdif == 2) {
                    num = this.devuelveRehabPorEdif(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                } else {
                    num = this.devuelveRehabPorEdif(this.noResidenciales.get(posicion).devuelveIdentificador()).size();
                }
                break;
        }
        return num;
    }
    
    /**
     * Devuelve el número de Proyectos de un tipo
     */
    public int devuelveNumProyectos(int tipoProyecto)
    {
        int num = 0;
        switch (tipoProyecto)
        {
            case 1:
                num = this.construccionesRes.size();
                break;
            case 2:
                num = this.construccionesNoRes.size();
                break;
            case 3:
                num = this.rehabilitaciones.size();
                break;
        }
        return num;
    }
    
    /**
     * Devuelve el número total de Proyectos
     */
    public int devuelveNumTodosProyectos()
    {
        return this.devuelveNumProyectos(1) + this.devuelveNumProyectos(2) + this.devuelveNumProyectos(3);
    }
    
    /**
     * Devuelve la lista de ConstruccionRes asociadas a un Empleado
     */
    private ArrayList<ConstruccionRes> devuelveConstrResPorEmpl(int tipoEmpleado, int identEmp)
    {
        ArrayList<ConstruccionRes> consRes = new ArrayList();
        for (ConstruccionRes construccionRes : this.construccionesRes)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = construccionRes.devuelveIdentArq();
                    break;
                case 3:
                    empl = construccionRes.devuelveIdentApar();
                    break;
                case 4:
                    empl = construccionRes.devuelveIdentCont();
                    break;
            }
            if (empl == identEmp){
                consRes.add(construccionRes);
            }
        }
        return consRes;
    }
    
    /**
     * Devuelve la lista de ConstruccionNoRes asociadas a un Empleado
     */
    private ArrayList<ConstruccionNoRes> devuelveConstrNoResPorEmpl(int tipoEmpleado, int identEmp)
    {
        ArrayList<ConstruccionNoRes> consNoRes = new ArrayList();
        for (ConstruccionNoRes construccionNoRes : this.construccionesNoRes)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = construccionNoRes.devuelveIdentArq();
                    break;
                case 3:
                    empl = construccionNoRes.devuelveIdentApar();
                    break;
                case 4:
                    empl = construccionNoRes.devuelveIdentCont();
                    break;
            }
            if (empl == identEmp){
                consNoRes.add(construccionNoRes);
            }
        }
        return consNoRes;
    }
    
    /**
     * Devuelve la lista de Rehabilitaciones asociadas a un Empleado
     */
    private ArrayList<Rehabilitacion> devuelveRehabPorEmpl(int tipoEmpleado, int identEmp)
    {
        ArrayList<Rehabilitacion> rehab = new ArrayList();
        for (Rehabilitacion rehabilitacion : this.rehabilitaciones)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = rehabilitacion.devuelveIdentArq();
                    break;
                case 3:
                    empl = rehabilitacion.devuelveIdentApar();
                    break;
                case 4:
                    empl = rehabilitacion.devuelveIdentCont();
                    break;
            }
            if (empl == identEmp){
                rehab.add(rehabilitacion);
            }
        }
        return rehab;
    }
    
    /**
     * Devuelve la lista de ConstruccionRes asociadas a un Cliente
     */
    private ArrayList<ConstruccionRes> devuelveConstrResPorCl(int identCl)
    {
        ArrayList<ConstruccionRes> consRes = new ArrayList();
        for (ConstruccionRes construccionRes : this.construccionesRes)
        {
            int tipoEdif = construccionRes.devuelveTipoEdif();
            int idEd = construccionRes.devuelveIdentEdif();
            int cl = -1;
            switch (tipoEdif)
            {
                case 1:
                    cl = this.encuentraUnif(idEd).devuelveIdentCliente();
                    break;
                case 2:
                    cl = this.encuentraComun(idEd).devuelveIdentCliente();;
                    break;
            }
            if (cl == identCl){
                consRes.add(construccionRes);
            }
        }
        return consRes;
    }
    
    /**
     * Devuelve la lista de ConstruccionNoRes asociadas a un Cliente
     */
    private ArrayList<ConstruccionNoRes> devuelveConstrNoResPorCl(int identCl)
    {
        ArrayList<ConstruccionNoRes> consNoRes = new ArrayList();
        for (ConstruccionNoRes construccionNoRes : this.construccionesNoRes)
        {
            int idEd = construccionNoRes.devuelveIdentEdif();
            int cl = this.encuentraNoResid(idEd).devuelveIdentCliente();
            if (cl == identCl){
                consNoRes.add(construccionNoRes);
            }
        }
        return consNoRes;
    }
    
    /**
     * Devuelve la lista de Rehabilitaciones asociadas a un Cliente
     */
    private ArrayList<Rehabilitacion> devuelveRehabPorCl(int identCl)
    {
        ArrayList<Rehabilitacion> rehab = new ArrayList();
        for (Rehabilitacion rehabilitacion : this.rehabilitaciones)
        {
            int tipoEdif = rehabilitacion.devuelveTipoEdif();
            int idEd = rehabilitacion.devuelveIdentEdif();
            int cl = -1;
            switch (tipoEdif)
            {
                case 1:
                    cl = this.encuentraUnif(idEd).devuelveIdentCliente();
                    break;
                case 2:
                    cl = this.encuentraComun(idEd).devuelveIdentCliente();
                    break;
                case 3:
                    cl = this.encuentraNoResid(idEd).devuelveIdentCliente();
                    break;
            }
            if (cl == identCl){
                rehab.add(rehabilitacion);
            }
        }
        return rehab;
    }
    
    /**
     * Devuelve el número de Proyectos de un tipo asociados a un Empleado
     */
    public int devuelveNumProyectosPorEmpleado(int tipoProyecto, int tipoEmpleado, int identEmpl)
    {
        int num = 0;
        switch (tipoProyecto)
        {
            case 1:
                num = this.devuelveConstrResPorEmpl(tipoEmpleado, identEmpl).size();
                break;
            case 2:
                num = this.devuelveConstrNoResPorEmpl(tipoEmpleado, identEmpl).size();
                break;
            case 3:
                num = this.devuelveRehabPorEmpl(tipoEmpleado, identEmpl).size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza una lista de un tipo de Proyectos
     */
    private void visualizaListaProyectos(int tipoProyecto,
    ArrayList<ConstruccionRes> consRes, ArrayList<ConstruccionNoRes> consNoRes, ArrayList<Rehabilitacion> rehab)
    {
        Arquitecto arq;
        Aparejador apar;
        Contable cont;
        Cliente clien = null;
        Unifamiliar unif;
        Comunitario comun;
        Edificacion edif = null;
        switch (tipoProyecto)
        {
            case 1:
                System.out.println("\n    Listado de construcciones residenciales.");
                for (ConstruccionRes construccionRes : consRes)
                {
                    int id = this.construccionesRes.indexOf(construccionRes) + 1;
                    System.out.println("    " + id + construccionRes);
                    arq = this.encuentraArq(construccionRes.devuelveIdentArq());
                    apar = this.encuentraApar(construccionRes.devuelveIdentApar());
                    cont = this.encuentraCont(construccionRes.devuelveIdentCont());
                    if (construccionRes.devuelveTipoEdif() == 1){
                        edif = this.encuentraUnif(construccionRes.devuelveIdentEdif());
                    } else {
                        edif = this.encuentraComun(construccionRes.devuelveIdentEdif());
                    }
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(apar);
                    System.out.println(cont);
                }
                break;
            case 2:
                System.out.println("\n    Listado de construcciones no residenciales.");
                for (ConstruccionNoRes construccionNoRes : consNoRes)
                {
                    int id = this.construccionesNoRes.indexOf(construccionNoRes) + 1;
                    System.out.println("    " + id + construccionNoRes);
                    arq = this.encuentraArq(construccionNoRes.devuelveIdentArq());
                    apar = this.encuentraApar(construccionNoRes.devuelveIdentApar());
                    cont = this.encuentraCont(construccionNoRes.devuelveIdentCont());
                    edif = this.encuentraNoResid(construccionNoRes.devuelveIdentEdif());
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(apar);
                    System.out.println(cont);
                }
                break;
            case 3:
                System.out.println("\n    Listado de rehabilitaciones.");
                for (Rehabilitacion rehabilitacion : rehab)
                {
                    int id = this.rehabilitaciones.indexOf(rehabilitacion) + 1;
                    System.out.println("    " + id + rehabilitacion);
                    arq = this.encuentraArq(rehabilitacion.devuelveIdentArq());
                    apar = this.encuentraApar(rehabilitacion.devuelveIdentApar());
                    cont = this.encuentraCont(rehabilitacion.devuelveIdentCont());
                    if (rehabilitacion.devuelveTipoEdif() == 1){
                        edif = this.encuentraUnif(rehabilitacion.devuelveIdentEdif());
                    } else if (rehabilitacion.devuelveTipoEdif() == 2){
                        edif = this.encuentraComun(rehabilitacion.devuelveIdentEdif());
                    } else {
                        edif = this.encuentraNoResid(rehabilitacion.devuelveIdentEdif());
                    }
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(apar);
                    System.out.println(cont);
                }
                break;
        }
    }
    
    /**
     * Visualiza todos los Proyectos asociados a un Cliente
     */
    public void visualizaTodosProyPorCl(int identCl)
    {
        identCl = this.clientes.get(identCl).devuelveIdentificador();
        this.visualizaListaProyectos(1, this.devuelveConstrResPorCl(identCl), null, null);
        this.visualizaListaProyectos(2, null, this.devuelveConstrNoResPorCl(identCl), null);
        this.visualizaListaProyectos(3, null, null, this.devuelveRehabPorCl(identCl));
    }
    
    /**
     * Visualiza todos los Proyectos de un tipo asociados a un Empleado
     */
    public void visualizaProyectosPorEmpleado(int tipoProyecto, int tipoEmpleado, int identEmpl)
    {
        switch (tipoProyecto)
        {
            case 1:
                visualizaListaProyectos(tipoProyecto, this.devuelveConstrResPorEmpl(tipoEmpleado, identEmpl), null, null);
                break;
            case 2:
                visualizaListaProyectos(tipoProyecto, null, this.devuelveConstrNoResPorEmpl(tipoEmpleado, identEmpl), null);
                break;
            case 3:
                visualizaListaProyectos(tipoProyecto, null, null, this.devuelveRehabPorEmpl(tipoEmpleado, identEmpl));
                break;
        }
    }
    
    /**
     * Visualiza todos los Proyectos de un tipo asociados a una Edificacion
     */
    public void visualizaProyectosPorEdif(int tipoProyecto, int tipoEdif, int identEdif)
    {
        switch (tipoEdif)
        {
            case 1:
                identEdif = this.unifamiliares.get(identEdif).devuelveIdentificador();
                break;
            case 2:
                identEdif = this.comunitarios.get(identEdif).devuelveIdentificador();
                break;
            case 3:
                identEdif = this.noResidenciales.get(identEdif).devuelveIdentificador();
                break;
        }
        switch (tipoProyecto)
        {
            case 1:
                this.visualizaListaProyectos(tipoProyecto, this.devuelveConsResPorRes(identEdif), null, null);
                break;
            case 2:
                this.visualizaListaProyectos(tipoProyecto, null, this.devuelveConsNoResPorNoRes(identEdif), null);
                break;
            case 3:
                this.visualizaListaProyectos(tipoProyecto, null, null, this.devuelveRehabPorEdif(identEdif));
                break;
        }
    }
    
    /**
     * Visualiza la lista completa de un tipo de Proyectos
     */
    public void visualizaProyectos(int tipoProyecto)
    {
        Arquitecto arq;
        Aparejador apar;
        Contable cont;
        Cliente clien = null;
        Unifamiliar unif;
        Comunitario comun;
        Edificacion edif = null;
        this.visualizaListaProyectos(tipoProyecto, this.construccionesRes, this.construccionesNoRes, this.rehabilitaciones);
    }
    
    /**
     * Devuelve la lista de ConstruccionRes pendientes de planificación
     */
    private ArrayList<ConstruccionRes> devuelveConstrResPlanif()
    {
        ArrayList<ConstruccionRes> consRes = new ArrayList();
        for (ConstruccionRes construccionRes : this.construccionesRes)
        {
            Period duracionPrev = construccionRes.devuelveDuracionPrev();
            int presupuesto = construccionRes.devuelvePresupuesto();
            LocalDate fechaInicio = construccionRes.devuelveFechaInicObras();
            if (duracionPrev != null && presupuesto > -1 && fechaInicio == null) {
                consRes.add(construccionRes);
            }
        }
        return consRes;
    }
    
    /**
     * Devuelve la lista de ConstruccionNoRes pendientes de planificación
     */
    private ArrayList<ConstruccionNoRes> devuelveConstrNoResPlanif()
    {
        ArrayList<ConstruccionNoRes> consNoRes = new ArrayList();
        for (ConstruccionNoRes ConstruccionNoRes : this.construccionesNoRes)
        {
            Period duracionPrev = ConstruccionNoRes.devuelveDuracionPrev();
            int presupuesto = ConstruccionNoRes.devuelvePresupuesto();
            LocalDate fechaInicio = ConstruccionNoRes.devuelveFechaInicObras();
            if (duracionPrev != null && presupuesto > -1 && fechaInicio == null) {
                consNoRes.add(ConstruccionNoRes);
            }
        }
        return consNoRes;
    }
    
    /**
     * Devuelve la lista de Rehabilitaciones pendientes de planificación
     */
    private ArrayList<Rehabilitacion> devuelveRehabPlanif()
    {
        ArrayList<Rehabilitacion> rehab = new ArrayList();
        for (Rehabilitacion rehabilitacion : this.rehabilitaciones)
        {
            Period duracionPrev = rehabilitacion.devuelveDuracionPrev();
            int presupuesto = rehabilitacion.devuelvePresupuesto();
            LocalDate fechaInicio = rehabilitacion.devuelveFechaInicObras();
            if (duracionPrev != null && presupuesto > -1 && fechaInicio == null) {
                rehab.add(rehabilitacion);
            }
        }
        return rehab;
    }
    
    /**
     * Devuelve el número de Proyectos de un tipo pendientes de planificación
     */
    public int devuelveNumProyPlanif(int tipoProyecto)
    {
        int num = 0;
        switch (tipoProyecto)
        {
            case 1:
                num = this.devuelveConstrResPlanif().size();
                break;
            case 2:
                num = this.devuelveConstrNoResPlanif().size();
                break;
            case 3:
                num = this.devuelveRehabPlanif().size();
                break;
        }
        return num;
    }
    
   /**
    * Visualiza el número de Proyectos de un tipo pendientes de planificación
    */
   public void visualizaProyPlanif()
   {
        ArrayList<ConstruccionRes> construcRes = this.devuelveConstrResPlanif();
        ArrayList<ConstruccionNoRes> construcNoRes = this.devuelveConstrNoResPlanif();
        ArrayList<Rehabilitacion> rehabilit = this.devuelveRehabPlanif();
        System.out.println("\n    Contrucciones residenciales\n");
        for (ConstruccionRes consRes : construcRes)
        {
            int id = construcRes.indexOf(consRes) + 1;
            LocalDate fechaInicio = consRes.devuelveFechaInicObras();
            LocalDate fechaFinPrev = consRes.devuelveFechaFinPrevObras();
            System.out.println("    " + id + " Inicio: " + fechaInicio + " Fin: " + fechaFinPrev);
        }
        System.out.println("\n    Contrucciones no residenciales\n");
        for (ConstruccionNoRes consNoRes : construcNoRes)
        {
            int id = construcNoRes.indexOf(consNoRes) + 1;
            LocalDate fechaInicio = consNoRes.devuelveFechaInicObras();
            LocalDate fechaFinPrev = consNoRes.devuelveFechaFinPrevObras();
            System.out.println(id + " Inicio: " + fechaInicio + " Fin: " + fechaFinPrev);
        }
        System.out.println("\n    Rehabilitaciones\n");
        for (Rehabilitacion rehab : rehabilit)
        {
            int id = rehabilit.indexOf(rehab) + 1;
            LocalDate fechaInicio = rehab.devuelveFechaInicObras();
            LocalDate fechaFinPrev = rehab.devuelveFechaFinPrevObras();
            System.out.println(id + " Inicio: " + fechaInicio + " Fin: " + fechaFinPrev);
        }
    }
    
    /**
     * Visualiza uno de los periodos de ejecución de proyectos
     */
    private void visualizaPeriodo(ArrayList<Proyecto> proyectos)
    {
        for (Proyecto proy : proyectos)
        {
            System.out.println("    Inicio: " + proy.devuelveFechaInicObras() + " Fin: " + proy.devuelveFechaFinPrevObras());
        }
    }
    
    /**
     * Visualiza la planificación de ejecución de obras
     * Es decir, muestra los tres periodos
     */
    public void visualizaCalendario()
    {
        System.out.println("\n    Planificación de ejecución de obras.");
        System.out.println("\n    Periodo 1.");
        this.visualizaPeriodo(this.proyectos1);
        System.out.println("\n    Periodo 2.");
        this.visualizaPeriodo(this.proyectos2);
        System.out.println("\n    Periodo 3.");
        this.visualizaPeriodo(this.proyectos3);
    }
    
    /**
     * Comprueba si un nuevo periodo se solapa con alguno existente en la lista de periodos
     */
    private boolean solapaPeriodo(LocalDate fechaInicio, Proyecto proyecto, ArrayList<Proyecto> proyectos)
    {
        LocalDate fechaFin = fechaInicio.plus(proyecto.devuelveDuracionPrev());
        for (Proyecto proy : proyectos)
        {
            LocalDate inic = proy.devuelveFechaInicObras();
            LocalDate fin = proy.devuelveFechaFinPrevObras();
            if (fechaInicio.isBefore(fin) && fechaFin.isAfter(inic))
            {
                return true;
            }
        }
        return false;
    }
    
    /**
     * Unserta un nuevo periodo en una de las listas, procurando que esté ordenado
     */
    private void insertaPeriodoOrdenado(Proyecto proyecto, ArrayList<Proyecto> proyectos)
    {
        boolean encontrado = false;
        int posicion = 0;
        while (!encontrado)
        {
            if (proyectos.size() == posicion){
                encontrado = true;
                break;
            }
            LocalDate fechaInicioPeriodo = proyectos.get(posicion).devuelveFechaInicObras();
            if (fechaInicioPeriodo.isAfter(proyecto.devuelveFechaFinPrevObras()))
            {
                encontrado = true;
            }
            if (!encontrado)
            {
                posicion++;
            }
        }
        proyectos.add(posicion, proyecto);
    }
    
    /**
     * Inserta un nuevo periodo en la planificación de ejecución de obras
     * siempre que no se solape con más de tres periodos ya existentes
     */
    public int insertaPeriodo(LocalDate fechaInicio, int tipoProyecto, int posicion)
    {
        Proyecto proyecto = null;
        switch (tipoProyecto)
        {
            case 1:
                proyecto = this.devuelveConstrResPlanif().get(posicion);
                break;
            case 2:
                proyecto = this.devuelveConstrNoResPlanif().get(posicion);
                break;
            case 3:
                proyecto = this.devuelveRehabPlanif().get(posicion);
                break;
        }
        boolean solapa1 = this.solapaPeriodo(fechaInicio, proyecto, this.proyectos1);
        boolean solapa2 = this.solapaPeriodo(fechaInicio, proyecto, this.proyectos2);
        boolean solapa3 = this.solapaPeriodo(fechaInicio, proyecto, this.proyectos3);
        int solapa = -1;
        if (!(solapa1 && solapa2 && solapa3))
        {
            proyecto.modificaFechaInicObras(fechaInicio);
            if (!solapa1)
            {
                this.insertaPeriodoOrdenado(proyecto, this.proyectos1);
                solapa = 1;
            }
            else if (!solapa2)
            {
                this.insertaPeriodoOrdenado(proyecto, this.proyectos2);
                solapa = 2;
            }
            else
            {
                this.insertaPeriodoOrdenado(proyecto, this.proyectos3);
                solapa = 3;
            }
        }
        return solapa;
    }
    
    /**
     * Elimina el número de Proyectos de una de las líneas de planificación
     */
    public int devuelveNumProyLinea(int linea)
    {
        int num = -1;
        switch(linea)
        {
            case 1:
                num = this.proyectos1.size();
                break;
            case 2:
                num = this.proyectos2.size();
                break;
            case 3:
                num = this.proyectos3.size();
                break;
        }
        return num;
    }
    
    /**
     * Elimina un Proyecto de una de las líneas de planificación
     */
    private void eliminaPeriodoLista(int posicion, ArrayList<Proyecto> proyectos)
    {
        Proyecto proyecto = proyectos.get(posicion);
        proyecto.modificaFechaInicObras(null);
        proyectos.remove(posicion);
    }
    
    /**
     * Elimina un Proyecto de una de la planificación
     */
    public void eliminaPeriodo(int posicion, int linea)
    {
        switch(linea)
        {
            case 1:
                this.eliminaPeriodoLista(posicion, this.proyectos1);
                break;
            case 2:
                this.eliminaPeriodoLista(posicion, this.proyectos2);
                break;
            case 3:
                this.eliminaPeriodoLista(posicion, this.proyectos3);
                break;
        }
    }
    
    /**
     * Introduce un nuevo Certificado dentro del sistema
     */
    public void insertaCertificado(int tipoCertificado)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = new Habitabilidad(this.contCert);
                this.habitabilidades.add(habitabilidad);
                this.contCert++;
                break;
            case 2:
                Inspeccion inspeccion = new Inspeccion(this.contCert);
                this.inspecciones.add(inspeccion);
                this.contCert++;
                break;
            case 3:
                Eficiencia eficiencia = new Eficiencia(this.contCert);
                this.eficiencias.add(eficiencia);
                this.contCert++;
                break;
            case 4:
                Pericial pericial = new Pericial(this.contCert);
                this.periciales.add(pericial);
                this.contCert++;
                break;
        }
    }
    
    /**
     * Cambia la fecha de solicitud de un Certificado
     */
    public void cambiaSolicCertificado(int tipoCertificado, int posicion, LocalDate fechaSolicitud)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaFechaSolicitud(fechaSolicitud);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaFechaSolicitud(fechaSolicitud);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaFechaSolicitud(fechaSolicitud);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaFechaSolicitud(fechaSolicitud);
                break;
        }
    }
    
    /**
     * Cambia la fecha de entrega de un Certificado
     */
    public void cambiaEntregaCertificado(int tipoCertificado, int posicion, LocalDate fechaEntrega)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaFechaEntrega(fechaEntrega);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaFechaEntrega(fechaEntrega);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaFechaEntrega(fechaEntrega);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaFechaEntrega(fechaEntrega);
                break;
        }
    }
    
    /**
     * Cambia el Arquitecto de un Certificado
     */
    public void cambiaArquitectoCertificado(int tipoCertificado, int posicion, int idenArq)
    {
        idenArq = this.arquitectos.get(idenArq).devuelveIdentificador();
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaIdentArq(idenArq);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaIdentArq(idenArq);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaIdentArq(idenArq);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaIdentArq(idenArq);
                break;
        }
    }
    
    /**
     * Cambia el Aparejador de un Certificado
     */
    public void cambiaAparejadorCertificado(int tipoCertificado, int posicion, int idenApar)
    {
        idenApar = this.aparejadores.get(idenApar).devuelveIdentificador();
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaIdentApar(idenApar);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaIdentApar(idenApar);
                break;
        }
    }
    
    /**
     * Cambia el Contable de un Certificado
     */
    public void cambiaContableCertificado(int tipoCertificado, int posicion, int idenCont)
    {
        idenCont = this.contables.get(idenCont).devuelveIdentificador();
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaIdentCont(idenCont);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaIdentCont(idenCont);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaIdentCont(idenCont);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaIdentCont(idenCont);
                break;
        }
    }
    
    /**
     * Cambia el Cliente de un Certificado
     */
    private void cambiaClienteCertificado(int tipoCertificado, int posicion, int idenClien)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaIdentClien(idenClien);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaIdentClien(idenClien);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaIdentClien(idenClien);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaIdentClien(idenClien);
                break;
        }
    }
    
    /**
     * Cambia la Edificacion de un Certificado
     */
    public void cambiaEdifCertificado(int tipoCertificado, int posicion, int tipoEdif, int identEdif)
    {
        int idenClien = 0;
        switch (tipoEdif)
        {
            case 1:
                idenClien = this.unifamiliares.get(identEdif).devuelveIdentCliente();
                identEdif = this.unifamiliares.get(identEdif).devuelveIdentificador();
                break;
            case 2:
                idenClien = this.comunitarios.get(identEdif).devuelveIdentCliente();
                identEdif = this.comunitarios.get(identEdif).devuelveIdentificador();
                break;
            case 3:
                idenClien = this.noResidenciales.get(identEdif).devuelveIdentCliente();
                identEdif = this.noResidenciales.get(identEdif).devuelveIdentificador();
                break;
        }
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaTipoEdif(tipoEdif);
                habitabilidad.modificaIdentEdif(identEdif);
                habitabilidad.modificaIdentClien(idenClien);
                break;
            case 2:
                Inspeccion inspeccion = this.inspecciones.get(posicion);
                inspeccion.modificaTipoEdif(tipoEdif);
                inspeccion.modificaIdentEdif(identEdif);
                inspeccion.modificaIdentClien(idenClien);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaTipoEdif(tipoEdif);
                eficiencia.modificaIdentEdif(identEdif);
                eficiencia.modificaIdentClien(idenClien);
                break;
            case 4:
                Pericial pericial = this.periciales.get(posicion);
                pericial.modificaTipoEdif(tipoEdif);
                pericial.modificaIdentEdif(identEdif);
                pericial.modificaIdentClien(idenClien);
                break;
        }
    }
    
    /**
     * Cambia la visita del Aparejador de un Certificado
     */
    public void cambiaVisitaCertificado(int tipoCertificado, int posicion, LocalDate fechaVisita)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.habitabilidades.get(posicion);
                habitabilidad.modificaFechaVisita(fechaVisita);
                break;
            case 3:
                Eficiencia eficiencia = this.eficiencias.get(posicion);
                eficiencia.modificaFechaVisita(fechaVisita);
                break;
        }
    }
    
    /**
     * Cambia el Presupuesto de un Certificado
     */
    public void cambiaPresupuestoCertificado(int tipoCertificado, int posicion, int presupuesto, int identEmp)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.devuelveHabitPorEmpl(4, identEmp).get(posicion);
                habitabilidad.modificaPresupuesto(presupuesto);
                break;
            case 2:
                Inspeccion inspeccion = this.devuelveInspecPorEmpl(4, identEmp).get(posicion);
                inspeccion.modificaPresupuesto(presupuesto);
                break;
            case 3:
                Eficiencia eficiencia = this.devuelveEficPorEmpl(4, identEmp).get(posicion);
                eficiencia.modificaPresupuesto(presupuesto);
                break;
            case 4:
                Pericial pericial = this.devuelvePericPorEmpl(4, identEmp).get(posicion);
                pericial.modificaPresupuesto(presupuesto);
        }
    }
    
    /**
     * Cambia la fecha de emisión de un Certificado
     */
    public void cambiaEmisionCertificado(int tipoCertificado, int posicion, LocalDate fechaEmision, int identEmp)
    {
        switch (tipoCertificado)
        {
            case 1:
                Habitabilidad habitabilidad = this.devuelveHabitPorEmpl(2, identEmp).get(posicion);
                habitabilidad.modificaFechaEmision(fechaEmision);
                break;
            case 2:
                Inspeccion inspeccion = this.devuelveInspecPorEmpl(2, identEmp).get(posicion);
                inspeccion.modificaFechaEmision(fechaEmision);
                break;
            case 3:
                Eficiencia eficiencia = this.devuelveEficPorEmpl(2, identEmp).get(posicion);
                eficiencia.modificaFechaEmision(fechaEmision);
                break;
            case 4:
                Pericial pericial = this.devuelvePericPorEmpl(2, identEmp).get(posicion);
                pericial.modificaFechaEmision(fechaEmision);
        }
    }
    
    /**
     * Cambia la categoría de un certificado de Eficiencia
     */
    public void cambiaCategoriaEfic(int posicion, int categoria, int identEmp)
    {
        Eficiencia eficiencia = this.devuelveEficPorEmpl(2, identEmp).get(posicion);
        eficiencia.modificaCategoria(categoria);
    }
    
    /**
     * Elimina un Certificado
     */
    public void eliminaCertificado(int tipoCertificado, int posicion)
    {
        switch (tipoCertificado)
        {
            case 1:
                this.habitabilidades.remove(posicion);
                break;
            case 2:
                this.inspecciones.remove(posicion);
                break;
            case 3:
                this.eficiencias.remove(posicion);
                break;
            case 4:
                this.periciales.remove(posicion);
                break;
        }
    }
    
    /**
     * Devuelve la lista de certificados de Habitabilidad asociados a un Residencial
     */
    private ArrayList<Habitabilidad> devuelveHabitPorRes(int identRes)
    {
        ArrayList<Habitabilidad> habit = new ArrayList();
        for (Habitabilidad habitabilidad : this.habitabilidades)
        {
            if (habitabilidad.devuelveIdentEdif() == identRes) {
                habit.add(habitabilidad);
            }
        }
        return habit;
    }
    
    /**
     * Devuelve la lista de certificados de Inspeccion asociados a un Comunitario
     */
    private ArrayList<Inspeccion> devuelveInspecPorComun(int identComun)
    {
        ArrayList<Inspeccion> inspec = new ArrayList();
        for (Inspeccion inspeccion : this.inspecciones)
        {
            if (inspeccion.devuelveIdentEdif() == identComun) {
                inspec.add(inspeccion);
            }
        }
        return inspec;
    }
    
    /**
     * Devuelve la lista de certificados de Eficiencia asociados a una Edificacion
     */
    private ArrayList<Eficiencia> devuelveEficPorEdif(int identEdif)
    {
        ArrayList<Eficiencia> efic = new ArrayList();
        for (Eficiencia eficiencia : this.eficiencias)
        {
            if (eficiencia.devuelveIdentEdif() == identEdif) {
                efic.add(eficiencia);
            }
        }
        return efic;
    }
    
    /**
     * Devuelve la lista de informes de Pericial asociados a una Edificacion
     */
    private ArrayList<Pericial> devuelvePericPorEdif(int identEdif)
    {
        ArrayList<Pericial> peric = new ArrayList();
        for (Pericial pericial : this.periciales)
        {
            if (pericial.devuelveIdentEdif() == identEdif) {
                peric.add(pericial);
            }
        }
        return peric;
    }
    
    /**
     * Devuelve el número de Certificados de un tipo asociados a una Edificacion
     */
    public int devuelveNumCertPorEdif(int tipoCert, int tipoEdif, int posicion)
    {
        int num = -1;
        switch (tipoCert)
        {
            case 1:
                if (tipoEdif == 1) {
                    num = this.devuelveHabitPorRes(this.unifamiliares.get(posicion).devuelveIdentificador()).size();
                } else {
                    num = this.devuelveHabitPorRes(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                }
                break;
            case 2:
                num = this.devuelveInspecPorComun(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                break;
            case 3:
                if (tipoEdif == 1) {
                    num = this.devuelveEficPorEdif(this.unifamiliares.get(posicion).devuelveIdentificador()).size();
                } else if (tipoEdif == 2) {
                    num = this.devuelveEficPorEdif(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                } else {
                    num = this.devuelveEficPorEdif(this.noResidenciales.get(posicion).devuelveIdentificador()).size();
                }
                break;
            case 4:
                if (tipoEdif == 1) {
                    num = this.devuelvePericPorEdif(this.unifamiliares.get(posicion).devuelveIdentificador()).size();
                } else if (tipoEdif == 2) {
                    num = this.devuelvePericPorEdif(this.comunitarios.get(posicion).devuelveIdentificador()).size();
                } else {
                    num = this.devuelvePericPorEdif(this.noResidenciales.get(posicion).devuelveIdentificador()).size();
                }
                break;
        }
        return num;
    }
    
    /**
     * Devuelve el número total de Certificados de un tipo
     */
    public int devuelveNumCertificados(int tipoCertificado)
    {
        int num = 0;
        switch (tipoCertificado)
        {
            case 1:
                num = this.habitabilidades.size();
                break;
            case 2:
                num = this.inspecciones.size();
                break;
            case 3:
                num = this.eficiencias.size();
                break;
            case 4:
                num = this.periciales.size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza una lista de Certificados
     */
    private void visualizaListaCertificados(int tipoCertificado,
    ArrayList<Habitabilidad> habit, ArrayList<Inspeccion> inspecc, ArrayList<Eficiencia> efic, ArrayList<Pericial> peric)
    {
        Arquitecto arq;
        Aparejador apar;
        Contable cont;
        Cliente clien = null;
        Unifamiliar unif;
        Comunitario comun;
        Edificacion edif = null;
        switch (tipoCertificado)
        {
            case 1:
                System.out.println("\n    Listado de certificados de habitabilidad.");
                for (Habitabilidad habitabilidad : habit)
                {
                    int id = this.habitabilidades.indexOf(habitabilidad) + 1;
                    System.out.println("\n    " + id + habitabilidad);
                    arq = this.encuentraArq(habitabilidad.devuelveIdentArq());
                    apar = this.encuentraApar(habitabilidad.devuelveIdentApar());
                    cont = this.encuentraCont(habitabilidad.devuelveIdentCont());
                    if (habitabilidad.devuelveTipoEdif() == 1){
                        edif = this.encuentraUnif(habitabilidad.devuelveIdentEdif());
                    } else {
                        edif = this.encuentraComun(habitabilidad.devuelveIdentEdif());
                    }
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(apar);
                    System.out.println(cont);
                }
                break;
            case 2:
                System.out.println("\n    Listado de certificados de inspección.");
                for (Inspeccion inspeccion : inspecc)
                {
                    int id = this.inspecciones.indexOf(inspeccion) + 1;
                    System.out.println("\n    " + id + inspeccion);
                    arq = this.encuentraArq(inspeccion.devuelveIdentArq());
                    cont = this.encuentraCont(inspeccion.devuelveIdentCont());
                    edif = this.encuentraComun(inspeccion.devuelveIdentEdif());
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(cont);
                }
                break;
            case 3:
                System.out.println("\n    Listado de certificados de eficiencia.");
                for (Eficiencia eficiencia : efic)
                {
                    int id = this.eficiencias.indexOf(eficiencia) + 1;
                    System.out.println("\n    " + id + eficiencia);
                    arq = this.encuentraArq(eficiencia.devuelveIdentArq());
                    apar = this.encuentraApar(eficiencia.devuelveIdentApar());
                    cont = this.encuentraCont(eficiencia.devuelveIdentCont());
                    if (eficiencia.devuelveTipoEdif() == 1){
                        edif = this.encuentraUnif(eficiencia.devuelveIdentEdif());
                    } else if (eficiencia.devuelveTipoEdif() == 2){
                        edif = this.encuentraComun(eficiencia.devuelveIdentEdif());
                    } else {
                        edif = this.encuentraNoResid(eficiencia.devuelveIdentEdif());
                    }
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(apar);
                    System.out.println(cont);
                }
                break;
            case 4:
                System.out.println("\n    Listado de informes periciales.");
                for (Pericial pericial : peric)
                {
                    int id = this.periciales.indexOf(pericial) + 1;
                    System.out.println("\n    " + id + pericial);
                    arq = this.encuentraArq(pericial.devuelveIdentArq());
                    apar = this.encuentraApar(pericial.devuelveIdentApar());
                    cont = this.encuentraCont(pericial.devuelveIdentCont());
                    if (pericial.devuelveTipoEdif() == 1){
                        edif = this.encuentraUnif(pericial.devuelveIdentEdif());
                    } else if (pericial.devuelveTipoEdif() == 2){
                        edif = this.encuentraComun(pericial.devuelveIdentEdif());
                    } else {
                        edif = this.encuentraNoResid(pericial.devuelveIdentEdif());
                    }
                    clien = this.encuentraClien(edif.devuelveIdentCliente());
                    System.out.println(clien);
                    System.out.println(edif);
                    System.out.println(arq);
                    System.out.println(cont);
                }
                break;
        }
    }
    
    /**
     * Visualiza una lista completa de Certificados de un tipo
     */
    public void visualizaCertificado(int tipoCertificado)
    {
        Arquitecto arq;
        Aparejador apar;
        Contable cont;
        Cliente clien = null;
        Unifamiliar unif;
        Comunitario comun;
        Edificacion edif = null;
        this.visualizaListaCertificados(tipoCertificado, this.habitabilidades, this.inspecciones, this.eficiencias, this.periciales);
    }
    
    /**
     * Devuelve la lista de certificados de Habitabilidad asociados a un Empleado
     */
    private ArrayList<Habitabilidad> devuelveHabitPorEmpl(int tipoEmpleado, int identEmpl)
    {
        ArrayList<Habitabilidad> habit = new ArrayList();
        for (Habitabilidad habitabilidad : this.habitabilidades)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = habitabilidad.devuelveIdentArq();
                    break;
                case 3:
                    empl = habitabilidad.devuelveIdentApar();
                    break;
                case 4:
                    empl = habitabilidad.devuelveIdentCont();
                    break;
            }
            if (empl == identEmpl){
                habit.add(habitabilidad);
            }
        }
        return habit;
    }
    
    /**
     * Devuelve la lista de certificados de Inspeccion asociados a un Empleado
     */
    private ArrayList<Inspeccion> devuelveInspecPorEmpl(int tipoEmpleado, int identEmpl)
    {
        ArrayList<Inspeccion> inspec = new ArrayList();
        for (Inspeccion inspeccion : this.inspecciones)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = inspeccion.devuelveIdentArq();
                    break;
                case 4:
                    empl = inspeccion.devuelveIdentCont();
                    break;
            }
            if (empl == identEmpl){
                inspec.add(inspeccion);
            }
        }
        return inspec;
    }
    
    /**
     * Devuelve la lista de certificados de Eficiencia asociados a un Empleado
     */
    private ArrayList<Eficiencia> devuelveEficPorEmpl(int tipoEmpleado, int identEmpl)
    {
        ArrayList<Eficiencia> efic = new ArrayList();
        for (Eficiencia eficiencia : this.eficiencias)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = eficiencia.devuelveIdentArq();
                    break;
                case 3:
                    empl = eficiencia.devuelveIdentApar();
                    break;
                case 4:
                    empl = eficiencia.devuelveIdentCont();
                    break;
            }
            if (empl == identEmpl){
                efic.add(eficiencia);
            }
        }
        return efic;
    }
    
    /**
     * Devuelve la lista de informes de Pericial asociados a un Empleado
     */
    private ArrayList<Pericial> devuelvePericPorEmpl(int tipoEmpleado, int identEmpl)
    {
        ArrayList<Pericial> peric = new ArrayList();
        for (Pericial pericial : this.periciales)
        {
            int empl = -1;
            switch (tipoEmpleado)
            {
                case 2:
                    empl = pericial.devuelveIdentArq();
                    break;
                case 4:
                    empl = pericial.devuelveIdentCont();
                    break;
            }
            if (empl == identEmpl){
                peric.add(pericial);
            }
        }
        return peric;
    }
    
    /**
     * Devuelve la lista de certificados de Habitabilidad asociados a un Cliente
     */
    private ArrayList<Habitabilidad> devuelveHabitPorCl(int identCl)
    {
        ArrayList<Habitabilidad> habit = new ArrayList();
        for (Habitabilidad habitabilidad : this.habitabilidades)
        {
            int tipoEdif = habitabilidad.devuelveTipoEdif();
            int idEd = habitabilidad.devuelveIdentEdif();
            int cl = -1;
            switch (tipoEdif)
            {
                case 1:
                    cl = this.encuentraUnif(idEd).devuelveIdentCliente();
                    break;
                case 2:
                    cl = this.encuentraComun(idEd).devuelveIdentCliente();;
                    break;
            }
            if (cl == identCl){
                habit.add(habitabilidad);
            }
        
        }
        return habit;
    }
    
    /**
     * Devuelve la lista de certificados de Inspeccion asociados a un Cliente
     */
    private ArrayList<Inspeccion> devuelveInspecPorCl(int identCl)
    {
        ArrayList<Inspeccion> inspec = new ArrayList();
        for (Inspeccion inspeccion : this.inspecciones)
        {
            int idEd = inspeccion.devuelveIdentEdif();
            int cl = this.encuentraComun(idEd).devuelveIdentCliente();
            if (cl == identCl){
                inspec.add(inspeccion);
            }
        }
        return inspec;
    }
    
    /**
     * Devuelve la lista de certificados de Eficiencia asociados a un Cliente
     */
    private ArrayList<Eficiencia> devuelveEficPorCl(int identCl)
    {
        ArrayList<Eficiencia> efic = new ArrayList();
        for (Eficiencia eficiencia : this.eficiencias)
        {
            int tipoEdif = eficiencia.devuelveTipoEdif();
            int idEd = eficiencia.devuelveIdentEdif();
            int cl = -1;
            switch (tipoEdif)
            {
                case 1:
                    cl = this.encuentraUnif(idEd).devuelveIdentCliente();
                    break;
                case 2:
                    cl = this.encuentraComun(idEd).devuelveIdentCliente();
                    break;
                case 3:
                    cl = this.encuentraNoResid(idEd).devuelveIdentCliente();
                    break;
            }
            if (cl == identCl){
                efic.add(eficiencia);
            }
        }
        return efic;
    }
    
    /**
     * Devuelve la lista de informes de Pericial asociados a un Cliente
     */
    private ArrayList<Pericial> devuelvePericPorCl(int identCl)
    {
        ArrayList<Pericial> peric = new ArrayList();
        for (Pericial pericial : this.periciales)
        {
            int tipoEdif = pericial.devuelveTipoEdif();
            int idEd = pericial.devuelveIdentEdif();
            int cl = -1;
            switch (tipoEdif)
            {
                case 1:
                    cl = this.encuentraUnif(idEd).devuelveIdentCliente();
                    break;
                case 2:
                    cl = this.encuentraComun(idEd).devuelveIdentCliente();
                    break;
                case 3:
                    cl = this.encuentraNoResid(idEd).devuelveIdentCliente();
                    break;
            }
            if (cl == identCl){
                peric.add(pericial);
            }
        }
        return peric;
    }
    
    /**
     * Devuelve la lista de Certificados de un tipo asociados a un Cliente
     */
    public void visualizaCertPorCl(int identCl)
    {
        identCl = this.clientes.get(identCl).devuelveIdentificador();
        visualizaListaCertificados(1, this.devuelveHabitPorCl(identCl), null, null, null);
        visualizaListaCertificados(2, null, this.devuelveInspecPorCl(identCl), null, null);
        visualizaListaCertificados(3, null, null, this.devuelveEficPorCl(identCl), null);
        visualizaListaCertificados(4, null, null, null, this.devuelvePericPorCl(identCl));
    }
    
    /**
     * Devuelve el número de Certificados de un tipo asociados a un Empleado
     */
    public int devuelveNumCertificadosPorEmpleado(int tipoCertificado, int tipoEmpleado, int identEmpl)
    {
        int num = 0;
        switch (tipoCertificado)
        {
            case 1:
                num = this.devuelveHabitPorEmpl(tipoEmpleado, identEmpl).size();
                break;
            case 2:
                num = this.devuelveInspecPorEmpl(tipoEmpleado, identEmpl).size();
                break;
            case 3:
                num = this.devuelveEficPorEmpl(tipoEmpleado, identEmpl).size();
                break;
            case 4:
                num = this.devuelvePericPorEmpl(tipoEmpleado, identEmpl).size();
                break;
        }
        return num;
    }
    
    /**
     * Visualiza la lista de Certificados de un tipo asociados a un Empleado
     */
    public void visualizaCertificadosPorEmpleado(int tipoCertificado, int tipoEmpleado, int identEmpl)
    {
        switch (tipoCertificado)
        {
            case 1:
                visualizaListaCertificados(tipoCertificado, this.devuelveHabitPorEmpl(tipoEmpleado, identEmpl), null, null, null);
                break;
            case 2:
                visualizaListaCertificados(tipoCertificado, null, this.devuelveInspecPorEmpl(tipoEmpleado, identEmpl), null, null);
                break;
            case 3:
                visualizaListaCertificados(tipoCertificado, null, null, this.devuelveEficPorEmpl(tipoEmpleado, identEmpl), null);
                break;
            case 4:
                visualizaListaCertificados(tipoCertificado, null, null, null, this.devuelvePericPorEmpl(tipoEmpleado, identEmpl));
                break;
        }
    }
    
    /**
     * Visualiza la lista de Certificados de un tipo asociados a una Edificacion
     */
    public void visualizaCertificadosPorEdif(int tipoCertificado, int tipoEdif, int identEdif)
    {
        switch (tipoEdif)
        {
            case 1:
                identEdif = this.unifamiliares.get(identEdif).devuelveIdentificador();
                break;
            case 2:
                identEdif = this.comunitarios.get(identEdif).devuelveIdentificador();
                break;
            case 3:
                identEdif = this.noResidenciales.get(identEdif).devuelveIdentificador();
                break;
        }
        switch (tipoCertificado)
        {
            case 1:
                this.visualizaListaCertificados(tipoCertificado, this.devuelveHabitPorRes(identEdif), null, null, null);
                break;
            case 2:
                this.visualizaListaCertificados(tipoCertificado, null, this.devuelveInspecPorComun(identEdif), null, null);
                break;
            case 3:
                this.visualizaListaCertificados(tipoCertificado, null, null, this.devuelveEficPorEdif(identEdif), null);
                break;
            case 4:
                this.visualizaListaCertificados(tipoCertificado, null, null, null, this.devuelvePericPorEdif(identEdif));
                break;
        }
    }
    
    /**
     * Carga una lista de Empleados preconfigurados
     */
    private void cargaEmpleados()
    {
        this.insertaEmpleado(1, "José Ramírez");
        this.insertaEmpleado(2, "Martín Pérez");
        this.insertaEmpleado(2, "Alicia Villanueva");
        this.insertaEmpleado(3, "Gonzalo Fuentes");
        this.insertaEmpleado(3, "Marisa Seisdedos");
        this.insertaEmpleado(3, "Juana Costa");
        this.insertaEmpleado(3, "Matías Gallardo");
        this.insertaEmpleado(4, "Santiago Bravo");
        this.insertaEmpleado(4, "Sandra Sánchez");
        this.insertaEmpleado(4, "Franciso Pisandro");
        this.insertaEmpleado(4, "Berta García");
    }
    
    /**
     * Carga una lista de Empleados preconfigurados
     */
    private void cargaClientes()
    {
        this.insertaCliente("César Rojo");
        this.contactaCliente(0, "Calle del Palomar, 16", "900621548", "654154589", "cesarrojo@email.com");
        this.insertaCliente("Clementina Jiménez");
        this.contactaCliente(1, "Calle de la Paz, 19, 4º C", "900168146", "654789215", "clementinajimenez@email.com");
        this.insertaCliente("Renato Suárez");
        this.contactaCliente(2, "Calle Nueva, 25, Bajo Izq", "900515647", "654344671", "renatosuarez@email.com");
        this.insertaCliente("Ana Ferrán");
        this.contactaCliente(3, "Avenida de la Alegría, 8", "900684348", "654568168", "anaferran@email.com");
        this.insertaCliente("Gloria Rubio");
        this.contactaCliente(4, "Plaza Mayor, 2, 5º A", "900058605", "654057458", "gloriarubio@email.com");
        this.insertaCliente("Mario Martín");
        this.contactaCliente(5, "Calle Dátiles, 7", "900580054", "654268105", "mariomartin@email.com");
    }
    
    /**
     * Carga una lista de Edificaciones preconfigurados
     */
    private void cargaEdificaciones()
    {
        this.insertaEdificacion(1);
        this.cambiaClienteEdificacion(1, 0, 0);
        this.nombraEdificacion(1, 0, "Residencia de César Rojo");
        this.cambiaDireccionEdificacion(1, 0, "Calle del Palomar, 16");
        this.cambiaFCreacEdificacion(1, 0, LocalDate.of(2004, 6, 24));
        this.cambiaTerrenoEdificacion(1, 0, 300);
        this.cambiaSuperficieEdificioEdificacion(1, 0, 275);
        this.cambiaViviendaResidencial(1, 0, 3, 16, 4);
        
        this.insertaEdificacion(1);
        this.cambiaClienteEdificacion(1, 1, 3);
        this.nombraEdificacion(1, 1, "Chalé de recreo");
        this.cambiaDireccionEdificacion(1, 1, "Calle de las Nubes, 19");
        this.cambiaFCreacEdificacion(1, 1, LocalDate.of(2011, 4, 6));
        this.cambiaTerrenoEdificacion(1, 1, 400);
        this.cambiaSuperficieEdificioEdificacion(1, 1, 335);
        this.cambiaViviendaResidencial(1, 1, 2, 16, 3);
        
        this.insertaEdificacion(2);
        this.cambiaClienteEdificacion(2, 0, 1);
        this.nombraEdificacion(2, 0, "Residencia de la tercera edad");
        this.cambiaDireccionEdificacion(2, 0, "Plaza de los Abedules");
        this.cambiaFCreacEdificacion(2, 0, LocalDate.of(1980, 5, 25));
        this.cambiaTerrenoEdificacion(2, 0, 1000);
        this.cambiaSuperficieEdificioEdificacion(2, 0, 2000);
        this.cambiaViviendaResidencial(2, 0, 1, 1, 1);
        this.cambiaPlantasComunitario(0, 3);
        this.cambiaPisosPorPlantaComunitario(0, 20);
        
        this.insertaEdificacion(2);
        this.cambiaClienteEdificacion(2, 1, 2);
        this.nombraEdificacion(2, 1, "Vecindad de los Rosales");
        this.cambiaFCreacEdificacion(2, 1, LocalDate.of(1970, 8, 12));
        this.cambiaTerrenoEdificacion(2, 1, 500);
        this.cambiaSuperficieEdificioEdificacion(2, 1, 450);
        this.cambiaViviendaResidencial(2, 1, 1, 16, 4);
        this.cambiaPlantasComunitario(1, 5);
        this.cambiaPisosPorPlantaComunitario(1, 4);
        
        this.insertaEdificacion(3);
        this.cambiaClienteEdificacion(3, 0, 4);
        this.nombraEdificacion(3, 0, "Mercado de abastos");
        this.cambiaDireccionEdificacion(3, 0, "Avenida de las Flores, 26, Bajo");
        this.cambiaFCreacEdificacion(3, 0, LocalDate.of(1945, 11, 4));
        this.cambiaTerrenoEdificacion(3, 0, 1350);
        this.cambiaSuperficieEdificioEdificacion(3, 0, 1225);
        this.cambiaFinalidadNoResidencial(0, 5);
        
        this.insertaEdificacion(3);
        this.cambiaClienteEdificacion(3, 1, 2);
        this.nombraEdificacion(3, 1, "Teatro Eurípides");
        this.cambiaDireccionEdificacion(3, 1, "Calle de la Estación de Trenes");
        this.cambiaFCreacEdificacion(3, 1, LocalDate.of(2023, 2, 15));
        this.cambiaTerrenoEdificacion(3, 1, 2500);
        this.cambiaSuperficieEdificioEdificacion(3, 1, 2200);
        this.cambiaFinalidadNoResidencial(1, 3);
        
        this.insertaEdificacion(3);
        this.cambiaClienteEdificacion(3, 2, 5);
        this.nombraEdificacion(3, 2, "Museo de Ciencias Naturales");
        this.cambiaDireccionEdificacion(3, 2, "Calle Mayor, 2");
        this.cambiaFCreacEdificacion(3, 2, LocalDate.of(1995, 5, 4));
        this.cambiaTerrenoEdificacion(3, 2, 2000);
        this.cambiaSuperficieEdificioEdificacion(3, 2, 1500);
        this.cambiaFinalidadNoResidencial(2, 1);
    }
    
    /**
     * Carga una lista de Proyectos preconfigurados
     */
    private void cargaProyectos()
    {
        this.insertaProyecto(1);
        this.cambiaSolicProyecto(1, 0, LocalDate.of(2007, 5, 6));
        this.cambiaEntregaProyecto(1, 0, LocalDate.of(2010, 8, 1));
        this.cambiaArquitectoProyecto(1, 0, 0);
        this.cambiaAparejadorProyecto(1, 0, 2);
        this.cambiaContableProyecto(1, 0, 0);
        this.cambiaEdifProyecto(1, 0, 1, 1);
        
        this.insertaProyecto(2);
        this.cambiaSolicProyecto(2, 0, LocalDate.of(2018, 7, 11));
        this.cambiaEntregaProyecto(2, 0, LocalDate.of(2023, 11, 5));
        this.cambiaArquitectoProyecto(2, 0, 1);
        this.cambiaAparejadorProyecto(2, 0, 3);
        this.cambiaContableProyecto(2, 0, 1);
        this.cambiaEdifProyecto(2, 0, 3, 1);
        
        this.insertaProyecto(3);
        this.cambiaSolicProyecto(3, 0, LocalDate.of(2020, 3, 21));
        this.cambiaEntregaProyecto(3, 0, LocalDate.of(2023, 4, 8));
        this.cambiaArquitectoProyecto(3, 0, 0);
        this.cambiaAparejadorProyecto(3, 0, 0);
        this.cambiaContableProyecto(3, 0, 2);
        this.cambiaEdifProyecto(3, 0, 3, 2);
        this.cambiaSupReforRehabilitacion(0, 1);
    }
    
    /**
     * Carga una lista de Certificados preconfigurados
     */
    private void cargaCertificados()
    {
        this.insertaCertificado(1);
        this.cambiaSolicCertificado(1, 0, LocalDate.of(2022, 4, 26));
        this.cambiaEntregaCertificado(1, 0, LocalDate.of(2022, 5, 31));
        this.cambiaArquitectoCertificado(1, 0, 0);
        this.cambiaAparejadorCertificado(1, 0, 0);
        this.cambiaContableCertificado(1, 0, 0);
        this.cambiaEdifCertificado(1, 0, 1, 0);
        this.cambiaVisitaCertificado(1, 0, LocalDate.of(2022, 5, 5));
        
        this.insertaCertificado(2);
        this.cambiaSolicCertificado(2, 0, LocalDate.of(2022, 5, 8));
        this.cambiaEntregaCertificado(2, 0, LocalDate.of(2022, 8, 14));
        this.cambiaArquitectoCertificado(2, 0, 1);
        this.cambiaContableCertificado(2, 0, 1);
        this.cambiaEdifCertificado(2, 0, 2, 1);
        
        this.insertaCertificado(3);
        this.cambiaSolicCertificado(3, 0, LocalDate.of(2022, 3, 26));
        this.cambiaEntregaCertificado(3, 0, LocalDate.of(2022, 5, 20));
        this.cambiaArquitectoCertificado(3, 0, 0);
        this.cambiaAparejadorCertificado(3, 0, 1);
        this.cambiaContableCertificado(3, 0, 2);
        this.cambiaEdifCertificado(3, 0, 3, 0);
        this.cambiaVisitaCertificado(3, 0, LocalDate.of(2022, 4, 25));
        
        this.insertaCertificado(4);
        this.cambiaSolicCertificado(4, 0, LocalDate.of(2022, 5, 8));
        this.cambiaEntregaCertificado(4, 0, LocalDate.of(2022, 8, 14));
        this.cambiaArquitectoCertificado(4, 0, 1);
        this.cambiaContableCertificado(4, 0, 3);
        this.cambiaEdifCertificado(4, 0, 3, 2);
    }
    
    /**
     * Carga una lista de datos preconfigurados
     */
    public void cargaPreconfiguracion()
    {
        this.cargaEmpleados();
        this.cargaClientes();
        this.cargaEdificaciones();
        this.cargaProyectos();
        this.cargaCertificados();
    }
}
