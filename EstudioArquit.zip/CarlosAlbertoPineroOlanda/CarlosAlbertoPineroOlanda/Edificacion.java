import java.time.LocalDate;
import java.time.Period;

/**
 * Clase abstracta Edificacion. Será la base de todas los edificios registrados en el sistema
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Edificacion
{
    /**
     * Campos que tendrán todos las construcciones registradas en el sistema:
     * identificador numérico único, nombre, dirección, la fecha de edificación,
     * la superficie de terreno y la superficie de edificio, ambas en metros cuadrados,
     * el identificador del cliente asociado y la edad del edificio
     */
    protected int identificador;
    protected String nombre;
    protected String direccion;
    protected LocalDate fechaEdificacion;
    protected int superficieTerreno;
    protected int superficieEdificio;
    protected int idCl;
    protected int edad;
    
    /**
     * Constructor
     */
    public Edificacion(int identificador)
    {
        this.identificador = identificador;
        this.direccion = "Desconocida";
        this.superficieTerreno = 0;
        this.superficieEdificio = 0;
        this.idCl = 0;
    }
    
    /**
     * Devuelve el identificador
     */
    public int devuelveIdentificador()
    {
        return this.identificador;
    }
    
    /**
     * Devuelve el nombre
     */
    public String devuelveNombre()
    {
        return this.nombre;
    }
    
    /**
     * Modifica el nombre
     */
    public void modificaNombre(String nombre)
    {
        this.nombre = nombre;
    }
    
    /**
     * Modifica la dirección
     */
    public void modificaDireccion(String direccion)
    {
        this.direccion = direccion;
    }
    
    /**
     * Modifica la fecha de edificación
     */
    public void modificaFechaConstr(LocalDate fechaEdificacion)
    {
        this.fechaEdificacion = fechaEdificacion;
    }
    
    /**
     * Modifica la superficie del terreno
     */
    public void modificaSuperficieTerreno(int superficieTerreno)
    {
        this.superficieTerreno = superficieTerreno;
    }
    
    /**
     * Modifica la superficie del edificio
     */
    public void modificaSuperficieEdificio(int superficieEdificio)
    {
        this.superficieEdificio = superficieEdificio;
    }
    
    /**
     * Actualiza la edad del edificio
     */
    private void actualizaEdad()
    {
        Period periodo = this.fechaEdificacion.until(LocalDate.now());
        this.edad = periodo.getYears();
    }
    
    /**
     * Devuelve el identificador del cliente
     */
    public int devuelveIdentCliente()
    {
        return this.idCl;
    }
    
    /**
     * Modifica el identificador del cliente
     */
    public void modificaIdentCliente(int idCl)
    {
        this.idCl = idCl;
    }
    
    /**
     * Devuelve los datos básicos de la Edificacion como String,
     * es parte de los métodos toString de las subclases.
     */
    protected String devuelveDatos()
    {
        this.actualizaEdad();
        String datos = "\n    Nombre: " + this.nombre + " Fecha de edificación: " + this.fechaEdificacion + " Edad: " + this.edad;
        datos = datos + "\n    Dirección: " + this.direccion + "\n    Superficie del terreno " + this.superficieTerreno;
        datos = datos + " m2, Superficie del edificio " + this.superficieEdificio + " m2 ";
        return datos;
    }
}
