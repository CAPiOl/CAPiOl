
/**
 * La clase Cliente define a los que encargan Tareas al estudio
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Cliente extends Individuo
{
    /**
     * Campos propios de los clientes: dirección, teléfono fijo, teléfono móvil y correo electrónico
     */
    private String direccion;
    private String telefonoFijo;
    private String telefonoMovil;
    private String email;

    /**
     * Constructor
     */
    
    public Cliente(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    /**
     * Modifica la dirección
     */
    private void modificaDireccion(String direccion)
    {
        this.direccion = direccion;
    }
    
    /**
     * Modifica el teléfono fijo
     */
    private void modificaTelefonoFijo(String telefonoFijo)
    {
        this.telefonoFijo = telefonoFijo;
    }
    
    /**
     * Modifica el telefono móvil
     */
    private void modificaTelefonoMovil(String telefonoMovil)
    {
        this.telefonoMovil = telefonoMovil;
    }
    
    /**
     * Modifica el e-mail
     */
    private void modificaEmail(String email)
    {
        this.email = email;
    }
    
    /**
     * Modifica todos los datos de contacto
     */
    public void modificaContacto(String direccion, String telefonoFijo, String telefonoMovil, String email)
    {
        this.modificaDireccion(direccion);
        this.modificaTelefonoFijo(telefonoFijo);
        this.modificaTelefonoMovil(telefonoMovil);
        this.modificaEmail(email);
    }
    
    /**
     * Devuelve los datos personales como String
     */
    private String devuelveDatos()
    {
        String datos = " Nombre: " + this.nombre + "\n    Dirección " + this.direccion + "\n    Teléfono fijo ";
        datos = datos + this.telefonoFijo + " Teléfono Móvil " + this.telefonoMovil + " E-mail: " + this.email;
        return datos;
    }
    
    /**
     * Devuelve el Cliente como String
     */
    public String toString()
    {
        String datos1 = "\n    Cliente" + this.devuelveDatos();
        return datos1;
    }
}
