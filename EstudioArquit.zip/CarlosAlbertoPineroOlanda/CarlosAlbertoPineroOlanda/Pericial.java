
/**
 * Clase que representa los informes periciales
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Pericial extends Certificado
{
    /**
     * Constructor
     */
    public Pericial(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve Pericial como String
     */
    public String toString()
    {
        String datos = "\n    Informe pericial";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosCertificado());
        return datos;
    }
}
