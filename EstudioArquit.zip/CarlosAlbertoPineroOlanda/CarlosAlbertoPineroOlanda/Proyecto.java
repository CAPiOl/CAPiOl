import java.time.LocalDate;
import java.time.Period;

/**
 * Clase abstracta Proyecto. Se dividirá en tres subclases
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Proyecto extends Tarea
{
    /**
     * Campos responsabilidad del arquitecto responsable asignará mediante un método:
     * Duración prevista
     */
    protected Period duracionPrev;
    protected LocalDate fechaFinObras;
    /**
     * Campo responsabilidad del administrador:
     * La fecha de inicio de obras, se asignará en la planificación
     */
    protected LocalDate fechaInicObras;
    /**
     * Campo que se actualizará a partir de campos anteriores:
     * La fecha prevista de fin de obras
     */
    protected LocalDate fechaFinPrevObras;
    
    /**
     * Constructor
     */
    public Proyecto(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la duración prevista
     */
    public Period devuelveDuracionPrev()
    {
        return this.duracionPrev;
    }
    
    /**
     * Modifica la duración prevista
     */
    public void modificaDuracionPrev(Period duracionPrev)
    {
        this.duracionPrev = duracionPrev;
    }
    
    /**
     * Devuelve la fecha de inicio de obras
     */
    public LocalDate devuelveFechaInicObras()
    {
        return this.fechaInicObras;
    }
    
    /**
     * Modifica la fecha de inicio de obras
     */
    public void modificaFechaInicObras(LocalDate fechaInicObras)
    {
        this.fechaInicObras = fechaInicObras;
    }
    
    /**
     * Devuelve la fecha de fin de obras
     */
    public LocalDate devuelveFechaFinObras()
    {
        return this.fechaFinObras;
    }
    
    /**
     * Modifica la fecha de fin de obras
     */
    public void modificaFechaFinObras(LocalDate fechaFinObras)
    {
        this.fechaFinObras = fechaFinObras;
    }
    
    /**
     * Actualiza la fecha prevista de fin de obras
     */
    protected void actualizaFechaFinPrevObras()
    {
        if (fechaInicObras != null){
            this.fechaFinPrevObras = this.fechaInicObras.plus(this.duracionPrev);
        } else {
            this.fechaFinPrevObras = null;
        }
    }
    
    /**
     * Devuelve la fecha prevista de fin de obras. Primero la actualiza
     */
    public LocalDate devuelveFechaFinPrevObras()
    {
        this.actualizaFechaFinPrevObras();
        return this.fechaFinPrevObras;
    }
    
    /**
     * Devuelve los datos básicos del Proyecto como String,
     * es parte de los métodos toString de las subclases
     */
    protected String devuelveDatosProyecto()
    {
        String datos = "\n    Fecha de inicio de obras ";
        if (this.fechaInicObras != null){
            datos = datos.concat(this.fechaInicObras + ".");
        } else {
            datos = datos.concat("aún por determinar.");
        }
        datos = datos.concat("\n    Fecha de fin de obras ");
        if (this.fechaFinObras != null){
            datos = datos.concat(this.fechaInicObras + ".");
        } else {
            datos = datos.concat("aún por determinar.");
        }
        datos = datos.concat("\n    Duración prevista ");
        if (this.duracionPrev != null){
            int annos = this.duracionPrev.getYears();
            Period sinAnnos = this.duracionPrev.withYears(0);
            int meses = sinAnnos.getMonths();
            Period sinMeses = sinAnnos.withMonths(0);
            int dias = sinMeses.getDays();
            datos = datos.concat(annos + " años, " + meses + " meses y " + dias + " días.");
        } else {
            datos = datos.concat("aún por determinar.");
        }
        return datos;
    }
}
