
/**
 * La clase Aparejador define a otro de los Empleados.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Aparejador extends Empleado
{
    /**
     * Constructor
     */
    public Aparejador(String nombre, int identificador)
    {
        super(nombre, identificador);
    }
    
    public TipoUsuario devuelveUsuario()
    {
        return TipoUsuario.APAREJADOR;
    }
}
