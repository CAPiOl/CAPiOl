
/**
 * Clase principal, donde está el método main que abre el sistema de gestión del estudio de arquitectura
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class estudio
{
    public static void main(String[] args){
        Visual visual = new Visual();
        visual.gestionaAplicacion();
    }
}
