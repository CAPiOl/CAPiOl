
/**
 * Clase ConstruccionRes. Define las construcciones de Residenciales
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class ConstruccionRes extends Proyecto
{
    /**
     * Constructor
     */
    public ConstruccionRes(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Devuelve la ConstruccionRes como String
     */
    public String toString()
    {
        String datos = "\n    Proyecto de construcción residencial";
        datos = datos.concat(this.devuelveDatosTarea());
        datos = datos.concat(this.devuelveDatosProyecto());
        return datos;
    }
}
