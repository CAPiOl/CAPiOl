import java.util.Scanner;
import java.time.LocalDate;

/**
 * La clase Visual define la interfaz gráfica que interaccionará con los usuarios de la aplicación.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Visual
{
    /**
     * Enumeración Modo (describe el funcionamiento de la aplicación)
     * INICIAL es el modo en que la aplicación inicializa
     * ENTRADA es el modo en que hay al menos un Administrador y se espera a que entre un usuario
     * ADMIN, ARQUIT, APAR Y CONT son los prefijos de los modos cuando el empleado se identifica
     * como Administrador, Arquitecto, Aparejador o Contable.
     * ENT es el sufijo que denota el modo de entrada para un empleado concreto.
     * INDIV se refiere al menú de gestión de los datos personales de los registrados en el sistema
     * CLIENGEST es el modo de gestión de los Clientes
     * TAREAS se refiere al modo de gestión de las Tareas
     * PROYECTOS se refiere al modo de gestión de los Proyectos
     * CERTIFICADOS se refiere al modo de gestión de los Certificados
     * EDIFIC se refiere al modo de entrada de las Edificaciones
     * EDIFICGEST se refiere al modo de gestión de las Edificaciones
     * PLAN se refiere a la planificación de obras
     * CERRAR es el modo en que la aplicación finaliza
     */
    private enum Modo{INICIAL, ENTRADA, ADMINENT, ARQUITENT, APARENT, CONTENT,
        INDIV, CLIENGEST, TAREAS, PROYECTOS, CERTIFICADOS, EDIFIC, EDIFICGEST, PLAN,
        CERRAR};
    
    /**Campos: una instancia de datos, una instancia de Modo y el identificador de empelado del usuario**/
    private Modo modo;
    private Datos datos;
    private int identEmpleado;

    /**
     * Constructor
     */
    public Visual()
    {
        this.modo = Modo.INICIAL;
        this.datos = new Datos();
        this.identEmpleado = -1;
    }

    /**
     * Lee datos numéricos entre el rango indicado
     */
    private int leeDatosNumericos(int limiteInferior, int limiteSuperior)
    {
        boolean dentroRango = false;
        int num = limiteInferior - 1;
        while (!dentroRango)
        {
            try {
                Scanner s = new Scanner(System.in);
                num = s.nextInt();
            } catch (Exception e){
                System.out.println("    Ha ocurrido un error.");
            }
            
            if (num >= limiteInferior && num <= limiteSuperior){
                dentroRango = true;
            } else {
                System.out.println("    Fuera de rango.");
            }
        }
        return num;
    }
    
    /**
     * Lee datos numéricos desde 1 hasta donde e indique
     */
    private int leeDesde1(int limiteSuperior)
    {
        return this.leeDatosNumericos(1, limiteSuperior);
    }
    
    /**
     * Lee datos numéricos desde 0 hasta donde e indique
     */
    private int leeDesde0(int limiteSuperior)
    {
        return this.leeDatosNumericos(0, limiteSuperior);
    }
    
    /**
     * Lee datos numéricos de una lista
     */
    private int leeListado(int limiteSuperior)
    {
        return this.leeDesde1(limiteSuperior) - 1;
    }
    
    /**
     * Lee texto
     */
    private String leeTexto()
    {
        String texto = new String();
        try {
            Scanner s = new Scanner(System.in);
            texto = s.nextLine();
        } catch (Exception e){
            System.out.println("    Ha ocurrido un error.");
        }
        return texto;
    }
    
    /**
     * Lee fechas
     */
    private LocalDate leeFecha()
    {
        System.out.println("    Introduce un año.");
        int anno = this.leeDatosNumericos(-1000, 50000);
        System.out.println("    Introduce un mes.");
        int mes = this.leeDesde1(12);
        System.out.println("    Introduce un día.");
        LocalDate prov = LocalDate.of(anno, mes, 1);
        int dia = this.leeDesde1(prov.lengthOfMonth());
        LocalDate fecha = LocalDate.of(anno, mes, dia);
        return fecha;
    }
    
    /**
     * Hace que la aplicación espere al mostrar una consulta
     */
    private void terminaVisual()
    {
        System.out.println("    Pulsa 1 para salir.");
        int salida = this.leeDesde1(1);
    }
    
    /**
     * Gestiona el menú de Inicialización. Da dos opciones:
     * 
     * 1 - Cargar datos preconfigurados.
     * 2 - Crear el primer Administrador.
     */
    private void gestionaInicial()
    {
        System.out.println("    INICIALIZACIÓN DE LA APLICACIÓN.\n\n    Elige entre estas dos opciones:");
        System.out.println("    1 - Cargar datos preconfigurados.\n    2 - Crear el primer Administrador.");
        int opcion = this.leeDesde1(2);
        if (opcion == 1){
            this.datos.cargaPreconfiguracion();
            System.out.println("\n    Has elegido cargar la preconfiguración.");
        } else {
            System.out.println("\n    Introduce su nombre.");
            String nombre = this.leeTexto();
            this.datos.insertaEmpleado(1, nombre);
            this.identEmpleado = 1;
        }
        this.modo = Modo.ENTRADA;
    }
    
    /**
     * Visualiza el menú de Entrada. Da cuatro opciones para identificarse:
     * 
     * 1 - Administrador.
     * 2 - Arquitecto.
     * 3 - Aparejador.
     * 4 - Contable.
     */
    private void gestionaEntrada()
    {
        System.out.println("\n    ENTRADA DE LA APLICACIÓN.\n\n    ¿Qué tipo de empleado eres?\n    1 - Administrador.");
        System.out.println("    2 - Arquitecto.\n    3 - Aparejador.\n    4 - Contable.\n    5 - Cerrar aplicación.");
        boolean valido = false;
        int opcion = -1;
        boolean hayArqu = this.datos.devuelveNumEmpleado(2) > 0;
        boolean hayApar = this.datos.devuelveNumEmpleado(3) > 0;
        boolean hayCont = this.datos.devuelveNumEmpleado(4) > 0;
        while (!valido)
        {
            opcion = this.leeDesde1(5);
            if (opcion == 1 || opcion == 2 && hayArqu || opcion == 3 && hayApar || opcion == 4 && hayCont || opcion == 5) {
                valido = true;
            } else {
                System.out.println("    No existe ninguno en nuestra base de datos");
            }
        }
        String[] empleados = {"administrador", "arquitecto", "aparejador", "contable"};
        switch (opcion)
        {
            case 1:
                this.modo = Modo.ADMINENT;
                break;
            case 2:
                this.modo = Modo.ARQUITENT;
                break;
            case 3:
                this.modo = Modo.APARENT;
                break;
            case 4:
                this.modo = Modo.CONTENT;
                break;
            case 5:
                this.modo = Modo.CERRAR;
                System.out.println("    CERRANDO APLICACIÓN.");
                break;
        }
        if (opcion < 5){
            System.out.println("    Identificación del " + empleados[opcion - 1] + "\n    ¿Quién eres?");
            this.datos.visualizaEmpleados(opcion);
            int limSup = this.datos.devuelveNumEmpleado(opcion);
            int eleccion = this.leeListado(limSup);
            this.identEmpleado = this.datos.devuelveIdentEmpleado(opcion, eleccion);
        }
    }
    
    /**
     * Gestiona el menú de Entrada del Administrador. Da cinco opciones:
     * 
     * 1 - Gestión de datos personales de empleados y clientes.
     * 2 - Gestión de proyectos y certificados.
     * 3 - Consulta de construcciones residenciales y no residenciales.
     * 4 - Gestión de la planificación de obras.
     * 5 - Salir.
     */
    private void gestionaEntradaAdmin()
    {
        System.out.println("\n    ENTRADA DE ADMINISTRADORES.\n    Elige qué quieres hacer:");
        System.out.println("    1 - Gestión de datos personales de empleados y clientes.");
        System.out.println("    2 - Gestión de edificios residenciales y no residenciales.");
        System.out.println("    3 - Gestión de proyectos y certificados.");
        System.out.println("    4 - Gestión de la planificación de obras.\n    5 - Salir");
        int numArq = this.datos.devuelveNumEmpleado(2);
        int numApar = this.datos.devuelveNumEmpleado(3);
        int numCont = this.datos.devuelveNumEmpleado(4);
        int numClien = this.datos.devuelveNumClien();
        int numUnif = this.datos.devuelveNumEdificacion(1);
        int numComun = this.datos.devuelveNumEdificacion(2);
        int numNoRes = this.datos.devuelveNumEdificacion(3);
        int numEdif = numUnif + numComun + numNoRes;
        int numProy = this.datos.devuelveNumTodosProyectos();
        int opcion = this.leeDesde1(5);
        while (numClien == 0 && opcion > 1 && opcion < 5 || (numApar == 0 || numProy == 0) && opcion == 4
        || (numArq == 0 || numCont == 0 || numEdif == 0) && opcion > 2 && opcion < 5)
        {
            if (numClien == 0 && opcion > 1 && opcion < 5) {
                System.out.println("    Sin clientes en nuestra base de datos, esa gestión no se permite.");
            } else if (numArq == 0 || numCont == 0 || numEdif == 0) {
                System.out.println("    Sin arquitectos o contables o edificaciones, esa gestión no se permite.");
            } else if (numApar == 0 || numProy == 0) {
                System.out.println("    Sin aparejadores o proyectos, esa gestión no se permite.");
            }
            opcion = this.leeDesde1(5);
        }
        switch (opcion)
        {
            case 1:
                this.modo = Modo.INDIV;
                break;
            case 2:
                this.modo = Modo.EDIFIC;
                break;
            case 3:
                this.modo = Modo.TAREAS;
                break;
            case 4:
                this.modo = Modo.PLAN;
                break;
            case 5:
                this.modo = Modo.ENTRADA;
                break;
        }
    }
    
    /**
     * Gestiona el menú de Gestión de todos los Individuos registrados en el sistema.
     * 
     * Da seis opciones:
     * 
     * 1 - Gestión de administradores.
     * 2 - Gestión de arquitectos.
     * 3 - Gestión de aparejadores.
     * 4 - Gestión de contables.
     * 5 - Gestión de clientes.
     * 6 - Salir.
     */
    private void gestionaIndividuos()
    {
        while (this.modo == Modo.INDIV)
        {
            System.out.println("\n    GESTIÓN DE DATOS PERSONALES DE EMPLEADOS Y CLIENTES.");
            System.out.println("\n    1 - Gestión de administradores.\n    2 - Gestión de arquitectos.");
            System.out.println("    3 - Gestión de aparejadores.\n    4 - Gestión de contables.");
            System.out.println("    5 - Gestión de clientes.\n    6 - Salir");
            int opcion = this.leeDesde1(6);
            if (opcion < 5){
                String[] empleados = {"administrador", "arquitecto", "aparejador", "contable"};
                String emp = empleados[opcion - 1];
                String[] plurales = {"es", "s", "es", "s"};
                System.out.println("    Gestión de datos personales de " + emp + plurales[opcion - 1] + ".");
                this.datos.visualizaEmpleados(opcion);
                System.out.println("\n    1 - Dar de alta a un nuevo " + emp + ".");
                System.out.println("    2 - Modificar los datos de un " + emp + ".\n    3 - Eliminar a un " + emp + ".");
                int limSup = this.datos.devuelveNumEmpleado(opcion);
                int opcionEmp = 0;
                if (opcion > 1){
                    System.out.println("    4 - Consultar sus clientes asignados.");
                    System.out.println("    5 - Consultar sus proyectos y certificados.\n    6 - Salir.");
                    opcionEmp = this.leeDesde1(6);
                } else {
                    System.out.println("    4 - Salir");
                    opcionEmp = this.leeDesde1(4);
                }
                while (limSup == 0 && opcionEmp > 1 && (opcion > 1 && opcionEmp < 6 || opcion == 1 && opcionEmp < 4)
                || limSup == 1 && opcion == 1 && opcionEmp == 3)
                {
                    if (limSup == 0){
                        System.out.println("    No hay ningún empleado de ese tipo.");
                    } else {
                        System.out.println("    Sólo existes tú y no puedes eliminarte.");
                    }
                    if (opcion > 1){
                        opcionEmp = this.leeDesde1(6);
                    } else {
                        opcionEmp = this.leeDesde1(4);
                    }
                }
                switch (opcionEmp)
                {
                    case 1:
                        System.out.println("\n    Introduce su nombre.");
                        String nombre = this.leeTexto();
                        this.datos.insertaEmpleado(opcion, nombre);
                        break;
                    case 2:
                        System.out.println("\n    Elige a un " + emp + ".");
                        int opcionEmpMod = this.leeListado(limSup);
                        System.out.println("    Elige:\n    1 - Cambiar nombre.\n    2 - Salir.");
                        int opcionMod = this.leeDesde1(2);
                        if (opcionMod == 1) {
                            System.out.println("    Introduce su nuevo nombre.");
                            String nuevoNombre = this.leeTexto();
                            this.datos.nombraEmpleado(opcion, opcionEmpMod, nuevoNombre);
                        }
                        break;
                    case 3:
                        String mensajeEliminar = "\n    Elige a un " + emp;
                        if (opcion == 1){
                            mensajeEliminar = mensajeEliminar.concat(" (excepto tú)");
                        }
                        mensajeEliminar = mensajeEliminar.concat(".");
                        System.out.println(mensajeEliminar);
                        int opcionEmpElim = this.leeListado(limSup);
                        while (opcion == 1 && this.datos.devuelveIdentEmpleado(1, opcionEmpElim) == this.identEmpleado){
                            System.out.println("    No puedes eliminarte.");
                            opcionEmpElim = this.leeListado(limSup);
                        }
                        System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                        int opcionElim = this.leeDesde1(2);
                        if (opcionElim == 2){
                            this.datos.eliminaEmpleado(opcion, opcionEmpElim);
                        }
                        break;
                    case 4:
                        if (opcion > 1){
                            System.out.println("\n    Elige a un " + emp + ".");
                            int opcionEmpClien = this.leeListado(limSup);
                            this.datos.visualizaClientesPorEmpleado(opcion, opcionEmpClien);
                        }
                        break;
                    case 5:
                        if (opcion > 1){
                            System.out.println("\n    Elige a un " + emp + ".");
                            int opcionEmpTar = this.leeListado(limSup);
                            int idEmp = this.datos.devuelveIdentEmpleado(opcion, opcionEmpTar);
                            System.out.println("\n    Elige qué quieres hacer:\n    1 - Consultar proyectos.");
                            System.out.println("    2 - Consultar certificados.\n    3 - Salir.");
                            int opcionTar = this.leeDatosNumericos(1, 3);
                            if (opcionTar == 1){
                                System.out.println("\n    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                                System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                                System.out.println("    4 - Salir.");
                                int tipoProyecto = this.leeDesde1(4);
                                int limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, opcion, idEmp);
                                while (limSupProy == 0 && tipoProyecto < 4)
                                {
                                    System.out.println("    No tienes asignado ninguno de ese tipo.");
                                    tipoProyecto = this.leeDesde1(4);
                                    limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, opcion, idEmp);
                                }
                                this.datos.visualizaProyectosPorEmpleado(tipoProyecto, opcion, idEmp);
                                this.terminaVisual();
                            } else if (opcionTar == 2){
                                System.out.println("\n    Elige el tipo de certificado:");
                                System.out.println("    1 - Certificados de habitabilidad.");
                                int tipoCertificado = -1;
                                if (opcion != 3){
                                    System.out.println("    2 - Certificados de inspección.");
                                    System.out.println("    3 - Certificados de eficiencia.");
                                    System.out.println("    4 - Informes periciales.\n    5 - Salir.");
                                    tipoCertificado = this.leeDesde1(5);
                                } else {
                                    System.out.println("    2 - Certificados de eficiencia.\n    3 - Salir.");
                                    tipoCertificado = this.leeDesde1(3);
                                    if (tipoCertificado == 2) {
                                        tipoCertificado++;
                                    } else if (tipoCertificado == 3) {
                                        tipoCertificado = tipoCertificado + 2;
                                    }
                                }
                                int limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, opcion, idEmp);
                                while (limSupCert == 0 &&
                                (tipoCertificado < 5 && opcion != 3 || tipoCertificado < 3 && opcion == 3))
                                {
                                    System.out.println("    No tienes asignado ninguno de ese tipo.");
                                    if (opcion != 3){
                                        tipoCertificado = this.leeDesde1(5);
                                    } else {
                                        tipoCertificado = this.leeDesde1(3);
                                        if (tipoCertificado == 2) {
                                            tipoCertificado++;
                                        } else if (tipoCertificado == 3) {
                                            tipoCertificado = tipoCertificado + 2;
                                        }
                                    }
                                    limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, opcion, idEmp);
                                }
                                this.datos.visualizaCertificadosPorEmpleado(tipoCertificado, opcion, idEmp);
                                this.terminaVisual();
                            }
                        }
                        break;
                }
            } else {
                switch (opcion)
                {
                    case 5:
                        this.modo = Modo.CLIENGEST;
                        break;
                    case 6:
                        this.modo = Modo.ADMINENT;
                        break;
                }
            }
        }
    }
    
    /**
     * Gestiona el menú de los Clientes.
     * 
     * Da seis opciones:
     * 
     * 1 - Dar de alta a un nuevo cliente
     * 2 - Modificar los datos de un cliente
     * 3 - Eliminar a un cliente
     * 4 - Consultar sus edificios.
     * 5 - Consultar sus proyectos y certificados.
     * 6 - Salir
     */
    
    private void gestionaClien()
    {
        while (this.modo != Modo.INDIV)
        {
            System.out.println("\n    Gestión de datos personales de clientes.");
            this.datos.visualizaClientes();
            System.out.println("\n    1 - Dar de alta a un nuevo cliente.\n    2 - Modificar los datos de un cliente.");
            System.out.println("    3 - Eliminar a un cliente.\n    4 - Consultar sus edificios.");
            System.out.println("    5 - Consultar sus proyectos y certificados.\n    6 - Salir.");
            int limSup = this.datos.devuelveNumClien();
            int opcion = this.leeDesde1(6);
            while (limSup == 0 && (opcion > 1 || opcion < 6))
            {
                System.out.println("    No hay ninguno de ese tipo");
                opcion = this.leeDesde1(6);
            }
            switch (opcion)
            {
                case 6:
                    this.modo = Modo.INDIV;
                    break;
                case 1:
                    System.out.println("    Introduce su nombre.");
                    String nombre = this.leeTexto();
                    this.datos.insertaCliente(nombre);
                    break;
                case 2:
                    System.out.println("    Elige a un cliente.");
                    int opcion2 = this.leeListado(limSup);
                    System.out.println("    Elige:\n    1 - Cambiar nombre.\n    2 - Modificar los datos de contacto.");
                    System.out.println("    3 - Salir.");
                    int opcion3 = this.leeDesde1(3);
                    if (opcion3 == 1) {
                        System.out.println("    Cambia su nombre.");
                        String nuevoNombre = this.leeTexto();
                        this.datos.nombraCliente(opcion2, nuevoNombre);
                    } else {
                        System.out.println("    Cambia la dirección.");
                        String nuevaDir = this.leeTexto();
                        System.out.println("    Cambia el teléfono fijo.");
                        String nuevoTelF = this.leeTexto();
                        System.out.println("    Cambia el teléfono móvil.");
                        String nuevoTelM = this.leeTexto();
                        System.out.println("    Cambia el e-mail.");
                        String nuevoEmail = this.leeTexto();
                        this.datos.contactaCliente(opcion2, nuevaDir, nuevoTelF, nuevoTelM, nuevoEmail);
                    }
                    break;
                case 3:
                    System.out.println("    Elige a un cliente.");
                    int opcion4 = this.leeListado(limSup);
                    System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                    int opcion5 = this.leeDesde1(2);
                    if (opcion5 == 2){
                        this.datos.eliminaCliente(opcion4);
                    }
                    break;
                case 4:
                    System.out.println("\n    Elige a un cliente.");
                    int opcionClienEdif = this.leeListado(limSup);
                    System.out.println("\n    Elige el tipo de edificio:\n    1 - Residencial unifamiliar.");
                    System.out.println("    2 - Residencial comunitario.\n    3 - No residencial.\n    4 - Salir");
                    int tipoEdificacion = this.leeDesde1(4);
                    int limSupEdif = this.datos.devuelveNumEdifPorClien(tipoEdificacion, opcionClienEdif);
                    while (limSupEdif == 0 && tipoEdificacion < 4)
                    {
                        System.out.println("    No tiene asignado ninguno de ese tipo.");
                        tipoEdificacion = this.leeDesde1(4);
                        limSupEdif = this.datos.devuelveNumEdifPorClien(tipoEdificacion, opcionClienEdif);
                    }
                    this.datos.visualizaEdifPorClien(tipoEdificacion, opcionClienEdif);
                    this.terminaVisual();
                    break;
                case 5:
                    System.out.println("\n    Elige a un cliente.");
                    int opcionClienTar = this.leeListado(limSup);
                    System.out.println("\n    Elige qué quieres hacer:\n    1 - Consultar proyectos.");
                    System.out.println("    2 - Consultar certificados.\n    3 - Salir.");
                    int opcionTar = this.leeDatosNumericos(1, 3);
                    if (opcionTar == 1){
                        this.datos.visualizaTodosProyPorCl(opcionClienTar);
                    } else {
                        this.datos.visualizaCertPorCl(opcionClienTar);
                    }
                    this.terminaVisual();
                    break;
            }
        }
    }
    
    /**
     * Gestiona el menú de las Edificaciones
     * 
     * Da cuatro opciones:
     * 
     * 1 - Gestión de detalles de edificios
     * 2 - Consultar los certificados de habitabilidad de los edificios residenciales
     * 3 - Consultar los certificados de inspección de los edificios comunitarios
     * 4 - Salir
     */
    private void gestionaEntradaEdific()
    {
        System.out.println("\n    GESTIÓN DE EDIFICIOS.");
        System.out.println("    1 - Gestión de detalles de edificios.");
        System.out.println("    2 - Consultar los certificados de habitabilidad de los edificios residenciales.");
        System.out.println("    3 - Consultar los certificados de inspección de los edificios comunitarios.");
        System.out.println("    4 - Salir.");
        int opcion = this.leeDesde1(4);
        switch (opcion)
        {
            case 1:
                this.modo = Modo.EDIFICGEST;
                break;
            case 2:
                String mensHab = "\n    Listado de edificios residenciales ";
                mensHab = mensHab.concat("con la fecha de sus últimos certificados de habitabilidad.");
                System.out.println(mensHab);
                this.datos.visualizaResidencialesHabitabilidad();
                this.terminaVisual();
                break;
            case 3:
                System.out.println("\n    Listado de edificios comunitarios que precisan de certificado de inspección.");
                this.datos.visualizaComunSinInspecc();
                this.terminaVisual();
                break;
            case 4:
                this.modo = Modo.ADMINENT;
                break;
        }
    }
    
    /**
     * Lee los valores de los campos de una Edificacion
     */
    private void leeCaracterEdif(boolean cambio, int tipoEdificacion, int posicion, int caracteristica)
    {
        String orden = "    ";
        if (cambio) {
            orden = orden.concat("Cambia ");
        } else {
            orden = orden.concat("Introduce ");
        }
        switch (caracteristica)
        {
            case 1:
                System.out.println(orden + "su cliente.");
                this.datos.visualizaClientes();
                int cliente = this.leeListado(this.datos.devuelveNumClien());
                this.datos.cambiaClienteEdificacion(tipoEdificacion, posicion, cliente);
                break;
            case 2:
                System.out.println(orden + "su nombre.");
                String nombre = this.leeTexto();
                this.datos.nombraEdificacion(tipoEdificacion, posicion, nombre);
                break;
            case 3:
                System.out.println(orden + "su dirección.");
                String direccion = this.leeTexto();
                this.datos.cambiaDireccionEdificacion(tipoEdificacion, posicion, direccion);
                break;
            case 4:
                System.out.println(orden + "su fecha de obra:");
                LocalDate fechaEdificacion = this.leeFecha();
                this.datos.cambiaFCreacEdificacion(tipoEdificacion, posicion, fechaEdificacion);
                break;
            case 5:
                System.out.println(orden + "su superficie de terreno en metros cuadrados:");
                int superficieTerreno = this.leeDesde0(100000);
                this.datos.cambiaTerrenoEdificacion(tipoEdificacion, posicion, superficieTerreno);
                break;
            case 6:
                System.out.println(orden + "su superficie de edificio en metros cuadrados:");
                int superficieEdificio = this.leeDesde0(100000);
                this.datos.cambiaSuperficieEdificioEdificacion(tipoEdificacion, posicion, superficieEdificio);
                break;
            case 7:
                if (tipoEdificacion == 3){
                    System.out.println(orden + "su finalidad:");
                    System.out.println("    1 - Industrial.\n    2 - Educativo.\n    3 - Religioso.");
                    System.out.println("    4 - Artístico.\n    5 - Espectáculos.\n    6 - Comercial.");
                    System.out.println("    7 - Sanitario.\n    8 - Gubernamental.");
                    int finalidad = this.leeListado(8);
                    this.datos.cambiaFinalidadNoResidencial(posicion, finalidad);
                } else {
                    int plantas = 1;
                    String mensajeComun = ":";
                    if (tipoEdificacion == 1){
                        System.out.println(orden + "el número de plantas:");
                        plantas = this.leeDesde1(100);
                    } else if (tipoEdificacion == 2){
                        mensajeComun = " por piso:";
                    }
                    System.out.println(orden + "el número de habitaciones" + mensajeComun);
                    int habitaciones = this.leeDesde1(100);
                    System.out.println(orden + "el número de baños" + mensajeComun);
                    int aseos = this.leeDesde1(100);
                    this.datos.cambiaViviendaResidencial(tipoEdificacion, posicion, plantas, habitaciones, aseos);
                }
                break;
            case 8:
                System.out.println(orden + "el número de plantas con pisos:");
                int nuevasPlantasPisos = this.leeDesde1(100);
                this.datos.cambiaPlantasComunitario(posicion, nuevasPlantasPisos);
                break;
            case 9:
                System.out.println(orden + "el número de pisos por planta:");
                int nuevosPisosPorPlanta = this.leeDesde1(100);
                this.datos.cambiaPisosPorPlantaComunitario(posicion, nuevosPisosPorPlanta);
                break;
        }
    }
    
    /**
     * Lee los valores de los campos de una nueva Edificacion
     */
    private void leeCaracterNuevoEdif(int tipoEdificacion, int posicion)
    {
        this.datos.insertaEdificacion(tipoEdificacion);
        int numCarac = 7;
        if (tipoEdificacion == 2){
            numCarac = 9;
        }
        for (int i = 1; i <= numCarac; i++)
        {
            this.leeCaracterEdif(false, tipoEdificacion, posicion, i);
        }
    }
    
    /**
     * Gestiona el menú de los detalles de las Edificaciones
     * 
     * Da cuatro opciones:
     * 
     * 1 - Gestión de edificios unifamiliares
     * 2 - Gestión de edificios comunitarios
     * 3 - Gestión de edificios no residenciales
     * 4 - Salir
     */
    private void gestionaEdific()
    {
        while (this.modo != Modo.EDIFIC)
        {
            System.out.println("\n    Gestión de detalles de edificios.");
            String mensajeUnif = "Gestión de edificios unifamiliares";
            String mensajeComun = "Gestión de edificios comunitarios.";
            String mensajeNoResid = "Gestión de edificios no residenciales.";
            String[] mensajes = {mensajeUnif, mensajeComun, mensajeNoResid};
            System.out.println("\n    1 - " + mensajeUnif + "\n    2 - " + mensajeComun);
            System.out.println("    3 - " + mensajeNoResid + "\n    4 - Salir");
            int opcion = this.leeDesde1(4);
            if (opcion == 4){
                this.modo = Modo.EDIFIC;
            } else {
                System.out.println("    " + mensajes[opcion - 1]);
                System.out.println("\n    1 - Introducir un nuevo edificio.\n    2 - Modificar los datos de un edificio.");
                System.out.println("    3 - Eliminar un edificio.");
                System.out.println("    4 - Gestionar los proyectos y certificados de un edificio.\n    5 - Salir");
                int limSup = this.datos.devuelveNumEdificacion(opcion);
                int opcionEdif = this.leeDesde1(5);
                while (limSup == 0 && opcionEdif > 1 && opcionEdif < 5)
                {
                    System.out.println("    No hay ninguno de ese tipo");
                    opcionEdif = this.leeDesde1(5);
                }
                switch (opcionEdif)
                {
                    case 1:
                        this.leeCaracterNuevoEdif(opcion, limSup);
                        break;
                    case 2:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaEdificaciones(opcion);
                        int opcionEdifMod = this.leeListado(limSup);
                        int opcionModificar = -1;
                        String mensajeModif = "    Elige:\n    1 - Cambiar su cliente.\n    2 - Cambiar su nombre.";
                        mensajeModif = mensajeModif.concat("\n    3 - Cambiar su direccion.\n    4 - Cambiar su fecha de obra.");
                        mensajeModif = mensajeModif.concat("\n    5 - Cambiar su superficie de terreno en metros cuadrados");
                        mensajeModif = mensajeModif.concat(".\n    6 - Cambiar su superficie de edificio en metros cuadrados.");
                        switch (opcion)
                        {
                            case 1:
                                mensajeModif = mensajeModif.concat("\n    7 - Cambia los detalles de la vivienda básica.");
                                System.out.println(mensajeModif);
                                opcionModificar = this.leeDesde1(7);
                                break;
                            case 2:
                                mensajeModif = mensajeModif.concat("\n    7 - Cambia los detalles de la vivienda básica.");
                                mensajeModif = mensajeModif.concat("\n    8 - Cambia el número de plantas con pisos.");
                                mensajeModif = mensajeModif.concat("\n    9 - Cambia el número de pisos por planta.");
                                System.out.println(mensajeModif);
                                opcionModificar = this.leeDesde1(9);
                                break;
                            case 3:
                                mensajeModif = mensajeModif.concat("\n    7 - Cambia la finalidad.");
                                System.out.println(mensajeModif);
                                opcionModificar = this.leeDesde1(7);
                                break;
                        }
                        this.leeCaracterEdif(true, opcion, opcionEdifMod, opcionModificar);
                        break;
                    case 3:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaEdificaciones(opcion);
                        int opcionEdifElim = this.leeListado(limSup);
                        System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                        int opcionElim = this.leeDesde1(2);
                        if (opcionElim == 2){
                            this.datos.eliminaEdificacion(opcion, opcionEdifElim);
                        }
                        break;
                    case 4:
                        System.out.println("\n    Elige uno.");
                        this.datos.visualizaEdificaciones(opcion);
                        int opcEdifTar = this.leeListado(limSup);
                        System.out.println("\n    Elige qué quieres hacer:\n    1 - Consultar proyectos.");
                        System.out.println("    2 - Consultar certificados.\n    3 - Salir.");
                        int opcionTar = this.leeDatosNumericos(1, 3);
                        if (opcionTar == 1){
                            System.out.println("\n    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                            System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                            System.out.println("    4 - Salir.");
                            int tipoProyecto = this.leeDesde1(4);
                            int limSupProy = this.datos.devuelveNumProyPorEdif(tipoProyecto, opcion, opcEdifTar);
                            while (limSupProy == 0 && tipoProyecto < 4)
                            {
                                System.out.println("    No tiene asignado ninguno de ese tipo.");
                                tipoProyecto = this.leeDesde1(4);
                                limSupProy = this.datos.devuelveNumProyPorEdif(tipoProyecto, opcion, opcEdifTar);
                            }
                            this.datos.visualizaProyectosPorEdif(tipoProyecto, opcion, opcEdifTar);
                            this.terminaVisual();
                        } else {
                            System.out.println("\n    Elige el tipo de certificado:");
                            System.out.println("    1 - Certificados de habitabilidad.");
                            System.out.println("    2 - Certificados de inspección.");
                            System.out.println("    3 - Certificados de eficiencia.");
                            System.out.println("    4 - Informes periciales.\n    5 - Salir.");
                            int tipoCertificado = this.leeDesde1(5);
                            int limSupCert = this.datos.devuelveNumCertPorEdif(tipoCertificado, opcion, opcEdifTar);
                            while (limSupCert == 0 && tipoCertificado < 5)
                            {
                                System.out.println("    No tiene asignado ninguno de ese tipo.");
                                tipoCertificado = this.leeDesde1(5);
                                limSupCert = this.datos.devuelveNumCertPorEdif(tipoCertificado, opcion, opcEdifTar);
                            }
                            this.datos.visualizaCertificadosPorEdif(tipoCertificado, opcion, opcEdifTar);
                            this.terminaVisual();
                        }
                        break;
                }
            }
        }
    }
    
    /**
     * Gestiona el menú de entrada de las Tareas
     * 
     * Da tres opciones:
     * 
     * 1 - Gestión de proyectos
     * 2 - Gestión de certificados
     * 3 - Salir
     */
    private void gestionaTareas()
    {
        System.out.println("\n    GESTIÓN DE PROYECTOS Y CERTIFICADOS.\n\n    Elige qué quieres hacer:");
        System.out.println("    1 - Gestión de proyectos.\n    2 - Gestión de certificados.\n    3 - Salir.");
        int opcion = this.leeDesde1(3);
        switch (opcion)
        {
            case 1:
                this.modo = Modo.PROYECTOS;
                break;
            case 2:
                this.modo = Modo.CERTIFICADOS;
                break;
            case 3:
                this.modo = Modo.ADMINENT;
                break;
        }
    }
    
    /**
     * Lee los valores de los campos de un Proyecto
     */
    private void leeCaracterProy(boolean cambio, int tipoProyecto, int posicion, int caracteristica)
    {
        String orden = "    ";
        if (cambio) {
            orden = orden.concat("Cambia ");
        } else {
            orden = orden.concat("Introduce ");
        }
        switch (caracteristica)
        {
            case 1:
                System.out.println(orden + "su fecha de solicitud:");
                LocalDate fechaEdificacion = this.leeFecha();
                this.datos.cambiaSolicProyecto(tipoProyecto, posicion, fechaEdificacion);
                break;
            case 2:
                System.out.println(orden + "su fecha de entrega:");
                LocalDate fechaEntrega = this.leeFecha();
                this.datos.cambiaEntregaProyecto(tipoProyecto, posicion, fechaEntrega);
                break;
            case 3:
                System.out.println(orden + "su arquitecto:");
                this.datos.visualizaEmpleados(2);
                int identArq = this.leeListado(this.datos.devuelveNumEmpleado(2));
                this.datos.cambiaArquitectoProyecto(tipoProyecto, posicion, identArq);
                break;
            case 4:
                System.out.println(orden + "su aparejador:");
                this.datos.visualizaEmpleados(3);
                int identApar = this.leeListado(this.datos.devuelveNumEmpleado(3));
                this.datos.cambiaAparejadorProyecto(tipoProyecto, posicion, identApar);
                break;
            case 5:
                System.out.println(orden + "su contable:");
                this.datos.visualizaEmpleados(4);
                int identCont = this.leeListado(this.datos.devuelveNumEmpleado(4));
                this.datos.cambiaContableProyecto(tipoProyecto, posicion, identCont);
                break;
            case 6:
                int tipoEdif = -1;
                switch (tipoProyecto)
                {
                    case 1:
                        System.out.println(orden + "su tipo de edificio residencial:");
                        System.out.println("    1 - Unifamiliar.\n    2 - Comunitario.");
                        tipoEdif = this.leeDesde1(2);
                        while (this.datos.devuelveNumEdificacion(tipoEdif) == 0)
                        {
                            System.out.println("No hay ninguno de ese tipo");
                            tipoEdif = this.leeDesde1(2);
                        }
                        break;
                    case 2:
                        tipoEdif = 3;
                        break;
                    case 3:
                        System.out.println(orden + "su tipo de edificio:");
                        System.out.println("    1 - Unifamiliar.\n    2 - Comunitario.\n    3 - No residencial.");
                        tipoEdif = this.leeDesde1(3);
                        while (this.datos.devuelveNumEdificacion(tipoEdif) == 0)
                        {
                            System.out.println("    No hay ninguno de ese tipo");
                            tipoEdif = this.leeDesde1(3);
                        }
                        break;
                }
                System.out.println(orden + "el edificio con su cliente:");
                this.datos.visualizaEdificaciones(tipoEdif);
                int limEdif = this.datos.devuelveNumEdificacion(tipoEdif);
                int identEdif = this.leeListado(limEdif);
                this.datos.cambiaEdifProyecto(tipoProyecto, posicion, tipoEdif, identEdif);
                break;
            case 7:
                System.out.println(orden + "su superficie a reformar:");
                System.out.println("    1 - Edificio.\n    2 - Exterior.");
                int nuevaSuperficieReformar = this.leeListado(2);
                this.datos.cambiaSupReforRehabilitacion(posicion, nuevaSuperficieReformar);
                break;
        }
    }
    
    /**
     * Lee los valores de los campos de un nuevo Proyecto
     */
    private void leeCaracterNuevoProy(int tipoProyecto, int posicion)
    {
        this.datos.insertaProyecto(tipoProyecto);
        int numCarac = 6;
        if (tipoProyecto == 3){
            numCarac++;
        }
        for (int i = 1; i <= numCarac; i++)
        {
            this.leeCaracterProy(false, tipoProyecto, posicion, i);
        }
    }
    
    /**
     * Gestiona el menú de los Proyectos
     * 
     * Da cuatro opciones:
     * 
     * 1 - Gestión de construcciones residenciales
     * 2 - Gestión de construcciones no residenciales
     * 3 - Gestión de rehabilitaciones
     * 4 - Salir
     */
    private void gestionaProyectos()
    {
        while (this.modo == Modo.PROYECTOS)
        {
            System.out.println("\n    GESTIÓN DE PROYECTOS.");
            //this.datos.visualizaTodosProyectos();
            String mensajeCResid = "Gestión de construcciones residenciales.";
            String mensajeCNoResid = "Gestión de construcciones no residenciales.";
            String mensajeRehab = "Gestión de rehabilitaciones.";
            int numUnif = this.datos.devuelveNumEdificacion(1);
            int numComun = this.datos.devuelveNumEdificacion(2);
            int numNoRes = this.datos.devuelveNumEdificacion(3);
            int numResid = numUnif + numComun;
            int numEdif = numResid + numNoRes;
            String[] mensajes = {mensajeCResid, mensajeCNoResid, mensajeRehab};
            System.out.println("\n    1 - " + mensajeCResid + "\n    2 - " + mensajeCNoResid);
            System.out.println("    3 - " + mensajeRehab + "\n    4 - Salir");
            int opcion = this.leeDesde1(4);
            while (numResid == 0 && opcion == 1 || numNoRes == 0 && opcion == 2)
            {
                System.out.println("    No hay ninguna edificación para este tipo de proyecto.");
                opcion = this.leeDesde1(4);
            }
            if (opcion == 4){
                this.modo = Modo.TAREAS;
            } else {
                System.out.println("    " + mensajes[opcion - 1]);
                System.out.println("    1 - Introducir un nuevo proyecto.");
                System.out.println("    2 - Modificar las características de un proyecto.");
                System.out.println("    3 - Eliminar un proyecto.\n    4 - Salir.");
                int limSup = this.datos.devuelveNumProyectos(opcion);
                int opcionProy = this.leeDesde1(4);
                while (limSup == 0 && opcionProy > 1 && opcionProy < 4)
                {
                    System.out.println("    No hay ninguno de ese tipo");
                    opcionProy = this.leeDesde1(4);
                }
                switch (opcionProy)
                {
                    case 1:
                        this.leeCaracterNuevoProy(opcion, limSup);
                        break;
                    case 2:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaProyectos(opcion);
                        int opcionProyMod = this.leeListado(limSup);
                        int opcionModificar = -1;
                        String mensajeModif = "    Elige:\n    1 - Cambiar su fecha de solicitud.";
                        mensajeModif = mensajeModif.concat("\n    2 - Cambiar su fecha de entrega.");
                        mensajeModif = mensajeModif.concat("\n    3 - Cambiar su arquitecto.");
                        mensajeModif = mensajeModif.concat("\n    4 - Cambiar su aparejador.\n    5 - Cambiar su contable.");
                        mensajeModif = mensajeModif.concat("\n    6 - Cambiar su edificio.");
                        if (opcion == 3){
                            mensajeModif = mensajeModif.concat(".\n    7 - Cambiar su superficie a reformar.");
                            System.out.println(mensajeModif);
                            opcionModificar = this.leeDesde1(7);
                        } else {
                            System.out.println(mensajeModif);
                            opcionModificar = this.leeDesde1(6);
                        }
                        this.leeCaracterProy(true, opcion, opcionProyMod, opcionModificar);
                        break;
                    case 3:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaProyectos(opcion);
                        int opcionProyElim = this.leeListado(limSup);
                        System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                        int opcionElim = this.leeDesde1(2);
                        if (opcionElim == 2){
                            this.datos.eliminaProyecto(opcion, opcionProyElim);
                        }
                        break;
                }
            }
        }
    }
    
    /**
     * Lee los valores de los campos de un Certificado
     */
    private void leeCaracterCert(boolean cambio, int tipoCertificado, int posicion, int caracteristica)
    {
        String orden = "    ";
        if (cambio) {
            orden = orden.concat("Cambia ");
        } else {
            orden = orden.concat("Introduce ");
        }
        switch (caracteristica)
        {
            case 1:
                System.out.println(orden + " su fecha de solicitud:");
                LocalDate fechaSolicitud = this.leeFecha();
                this.datos.cambiaSolicCertificado(tipoCertificado, posicion, fechaSolicitud);
                break;
            case 2:
                System.out.println(orden + " su fecha de entrega:");
                LocalDate fechaEntrega = this.leeFecha();
                this.datos.cambiaEntregaCertificado(tipoCertificado, posicion, fechaEntrega);
                break;
            case 3:
                System.out.println(orden + " su arquitecto:");
                this.datos.visualizaEmpleados(2);
                int idenArq = this.leeListado(this.datos.devuelveNumEmpleado(2));
                this.datos.cambiaArquitectoCertificado(tipoCertificado, posicion, idenArq);
                break;
            case 4:
                System.out.println(orden + " su aparejador:");
                this.datos.visualizaEmpleados(3);
                int idenApar = this.leeListado(this.datos.devuelveNumEmpleado(3));
                this.datos.cambiaAparejadorCertificado(tipoCertificado, posicion, idenApar);
                break;
            case 5:
                System.out.println(orden + " su contable:");
                this.datos.visualizaEmpleados(4);
                int idenCont = this.leeListado(this.datos.devuelveNumEmpleado(4));
                this.datos.cambiaContableCertificado(tipoCertificado, posicion, idenCont);
                break;
            case 6:
                int tipoEdif = -1;
                if (tipoCertificado == 1){
                    System.out.println(orden + " su tipo de edificio residencial:");
                    System.out.println("    1 - Unifamiliar.\n    2 - Comunitario.");
                    tipoEdif = this.leeDesde1(2);
                    while (this.datos.devuelveNumEdificacion(tipoEdif) == 0)
                    {
                        System.out.println("    No hay ninguno de ese tipo");
                        tipoEdif = this.leeDesde1(2);
                    }
                } else if (tipoCertificado == 2){
                    tipoEdif = 2;
                } else {
                    System.out.println(orden + " su tipo de edificio:");
                    System.out.println("    1 - Unifamiliar.\n    2 - Comunitario.\n    3 - No residencial.");
                    tipoEdif = this.leeDesde1(3);
                    while (this.datos.devuelveNumEdificacion(tipoEdif) == 0)
                    {
                        System.out.println("    No hay ninguno de ese tipo");
                        tipoEdif = this.leeDesde1(3);
                    }
                }
                System.out.println(orden + " uno (el nuevo cliente viene predefinido):");
                this.datos.visualizaEdificaciones(tipoEdif);
                int limEdif = this.datos.devuelveNumEdificacion(tipoEdif);
                int identEdif = this.leeListado(limEdif);
                this.datos.cambiaEdifCertificado(tipoCertificado, posicion, tipoEdif, identEdif);
                break;
            case 7:
                System.out.println(orden + " la fecha de visita del aparejador:");
                LocalDate fechaVisita = this.leeFecha();
                this.datos.cambiaVisitaCertificado(tipoCertificado, posicion, fechaVisita);
                break;
        }
    }
    
    /**
     * Lee los valores de los campos de un nuevo Certificado
     */
    private void leeCaracterNuevoCert(int tipoCertificado, int posicion)
    {
        this.datos.insertaCertificado(tipoCertificado);
        int numCarac = 7;
        if (tipoCertificado == 3){
            numCarac++;
        }
        for (int i = 1; i <= numCarac; i++)
        {
            if ((tipoCertificado == 2 || tipoCertificado == 4) && (i == 4 || i == 7)){
                continue;
            }
            this.leeCaracterCert(false, tipoCertificado, posicion, i);
        }
    }
    
    /**
     * Gestiona el menú de los Certificados
     * 
     * Da cinco opciones:
     * 
     * 1 - Gestión de certificados de habitabilidad
     * 2 - Gestión de certificados de residenciales
     * 3 - Gestión de certificados de eficiencia
     * 4 - Gestión de informes periciales
     * 5 - Salir
     */
    private void gestionaCertificados()
    {
        while (this.modo == Modo.CERTIFICADOS)
        {
            System.out.println("\n    GESTIÓN DE CERTIFICADOS.");
            //this.datos.visualizaTodosCertificados();
            String mensajeHabit = "Gestión de certificados de habitabilidad.";
            String mensajeInspec = "Gestión de certificados de inspección.";
            String mensajeEfic = "Gestión de certificados de eficiencia.";
            String mensajePeric = "Gestión de informes periciales.";
            String[] mensajes = {mensajeHabit, mensajeInspec, mensajeEfic, mensajePeric};
            System.out.println("\n    1 - " + mensajeHabit + "\n    2 - " + mensajeInspec);
            System.out.println("    3 - " + mensajeEfic + "\n    4 - " + mensajePeric + "\n    5 - Salir");
            int numUnif = this.datos.devuelveNumEdificacion(1);
            int numComun = this.datos.devuelveNumEdificacion(2);
            int numResid = numUnif + numComun;
            int numApar = this.datos.devuelveNumEmpleado(3);
            int opcion = this.leeDesde1(5);
            while (numResid == 0 && opcion == 1 || numComun == 0 && opcion == 2 || numApar == 0 && (opcion == 1 || opcion == 3))
            {
                System.out.println("    No hay ninguna edificación o aparejador para este tipo de certificado.");
                opcion = this.leeDesde1(5);
            }
            if (opcion == 5){
                this.modo = Modo.TAREAS;
            } else {
                System.out.println("    " + mensajes[opcion - 1]);
                System.out.println("\n    1 - Introducir un nuevo certificado.");
                System.out.println("    2 - Modificar las características de un certificado.");
                System.out.println("    3 - Eliminar un certificado.\n    4 - Salir");
                int limSup = this.datos.devuelveNumCertificados(opcion);
                int opcionCert = this.leeDesde1(4);
                while (limSup == 0 && opcionCert > 1 && opcionCert < 4)
                {
                    System.out.println("    No hay ninguno de ese tipo");
                    opcionCert = this.leeDesde1(4);
                }
                switch (opcionCert)
                {
                    case 1:
                        this.leeCaracterNuevoCert(opcion, limSup);
                        break;
                    case 2:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaCertificado(opcion);
                        int opcionProyMod = this.leeListado(limSup);
                        int opcionModificar = -1;
                        String mensajeModif = "    Elige:\n    1 - Cambiar su fecha de solicitud.";
                        mensajeModif = mensajeModif.concat("\n    2 - Cambiar su fecha de entrega.");
                        mensajeModif = mensajeModif.concat("\n    3 - Cambiar su arquitecto.");
                        if (opcion == 1 || opcion == 3){
                            mensajeModif = mensajeModif.concat("\n    4 - Cambiar su aparejador.");
                            mensajeModif = mensajeModif.concat("\n    5 - Cambiar su contable.\n    6 - Cambiar su edificio.");
                            mensajeModif = mensajeModif.concat("\n    7 - Cambiar la fecha de visita del aparejador.");
                            System.out.println(mensajeModif);
                            opcionModificar = this.leeDesde1(7);
                            
                        } else {
                            mensajeModif = mensajeModif.concat("\n    4 - Cambiar su contable.\n    5 - Cambiar su edificio.");
                            System.out.println(mensajeModif);
                            opcionModificar = this.leeDesde1(5);
                            if (opcionModificar > 3){
                                opcionModificar++;
                            }
                        }
                        this.leeCaracterCert(true, opcion, opcionProyMod, opcionModificar);
                        break;
                    case 3:
                        System.out.println("\n    Elige uno:");
                        this.datos.visualizaCertificado(opcion);
                        int opcionCertElim = this.leeListado(limSup);
                        System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                        int opcionElim = this.leeDesde1(2);
                        if (opcionElim == 2){
                            this.datos.eliminaProyecto(opcion, opcionCertElim);
                        }
                        break;
                }
            }
        }
    }
    
    /**
     * Gestiona el menú de Planificacion
     * 
     * Da dos opciones:
     * 
     * 1 - Ver la planificación de proyectos actuales
     * 2 - Salir
     */
    private void gestionaPlanificacion()
    {
        while (this.modo == Modo.PLAN)
        {
            System.out.println("    PLANIFICACIÓN DE PROYECTOS.");
            System.out.println("\n    Elige qué quieres hacer:");
            System.out.println("    1 - Ver la planificación de proyectos actuales.\n    2 - Salir.");
            int opcion = this.leeDesde1(2);
            if (opcion == 2) {
                this.modo = Modo.ADMINENT;
            } else if (opcion == 1) {
                System.out.println("    Calendario de la planificación.");
                this.datos.visualizaCalendario();
                System.out.println("\n    Elige qué quieres hacer:");
                System.out.println("    1 - Ver todos los proyectos pendientes de planificar.");
                System.out.println("    2 - Salir.");
                int opcionAcc = this.leeDesde1(2);
                if (opcionAcc == 1) {
                    this.datos.visualizaProyPlanif();
                    System.out.println("\n    Elige qué quieres hacer:\n    1 - Darle a uno fecha de inicio.");
                    System.out.println("    2 - Eliminar un proyecto de la planificación.\n    3 - Salir.");
                    int opcionMod = this.leeDesde1(3);
                    if (opcionMod == 1){
                        System.out.println("    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                        System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                        System.out.println("    4 - Salir.");
                        int tipoProyecto = this.leeDesde1(4);
                        int limSupProy = this.datos.devuelveNumProyPlanif(tipoProyecto);
                        while (limSupProy == 0 && tipoProyecto < 4)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoProyecto = this.leeDesde1(4);
                            limSupProy = this.datos.devuelveNumProyPlanif(tipoProyecto);
                        }
                        if (tipoProyecto < 4){
                            System.out.println("    1 - Elegir uno.\n    2 - Salir.");
                            int opcionProy = this.leeDesde1(2);
                            if (opcionProy == 1) {
                                System.out.println("    Elige el proyecto en concreto:");
                                int opcionProyMod = this.leeListado(limSupProy);
                                System.out.println("    Introduce la fecha de inicio.");
                                LocalDate fechaInicio = this.leeFecha();
                                while (this.datos.insertaPeriodo(fechaInicio, tipoProyecto, opcionProyMod) == -1)
                                {
                                    System.out.println("    Solapa con alguna existente. Introduce otra.");
                                    fechaInicio = this.leeFecha();
                                }
                            }
                        }
                    } else if (opcionMod == 2){
                        System.out.println("    Elige la línea de programación.\n    1.\n    2.\n    3.\n    4 - Salir.");
                        int eliminar = this.leeDesde1(4);
                        int numLinea = this.datos.devuelveNumProyLinea(eliminar);
                        while (numLinea == 0 && eliminar < 4)
                        {
                            System.out.println("    No hay ninguno.");
                            eliminar = this.leeDesde1(4);
                            numLinea = this.datos.devuelveNumProyPlanif(eliminar);
                        }
                        if (eliminar < 4){
                            System.out.println("    Elige el proyecto en concreto:");
                            int opcionProyElim = this.leeListado(numLinea);
                            System.out.println("    Elige:\n    1 - Cancelar.\n    2 - Confirmar eliminación.");
                            int opcionElim = this.leeDesde1(2);
                            if (opcionElim == 2){
                                this.datos.eliminaPeriodo(opcionProyElim, eliminar);
                            }
                        }
                    }
                }
            }
        }
    }
    
    /**
     * Gestiona el menú de Entrada del Arquitecto. Da tres opciones:
     * 
     * 1 - Consulta de los clientes asignados.
     * 2 - Gestión de proyectos y certificados asignados.
     * 3 - Salir.
     */
    private void gestionaEntradaArquit()
    {
        while (this.modo == Modo.ARQUITENT)
        {
            System.out.println("\n    ENTRADA DE ARQUITECTOS.\n    1 - Consulta de los clientes asignados.");
            System.out.println("    2 - Gestión de proyectos y certificados asignados.\n    3 - Salir.");
            int opcion = this.leeDesde1(3);
            switch (opcion)
            {
                case 1:
                    this.datos.visualizaClientesPorArquitecto(this.identEmpleado);
                    this.terminaVisual();
                    break;
                case 2:
                    System.out.println("\n    Gestión de proyectos y certificados asignados:");
                    System.out.println("    1 - Consultar proyectos.\n    2 - Consultar certificados.\n    3 - Salir.");
                    int opcionCons = this.leeDesde1(3);
                    if (opcionCons == 1){
                        System.out.println("\n    Gestión de proyectos asignados:");
                        System.out.println("\n    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                        System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                        System.out.println("    4 - Salir.");
                        int tipoProyecto = this.leeDesde1(4);
                        int limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 2, this.identEmpleado);
                        while (limSupProy == 0 && tipoProyecto < 4)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoProyecto = this.leeDesde1(4);
                            limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 2, this.identEmpleado);
                        }
                        if (tipoProyecto < 4){
                            this.datos.visualizaProyectosPorEmpleado(tipoProyecto, 2, this.identEmpleado);
                            System.out.println("    1 - Modificar la duración prevista de un proyecto.");
                            System.out.println("    2 - Introducir la fecha de fin de obra.\n    3 - Salir.");
                            int opcionProy = this.leeDesde1(2);
                            if (opcionProy == 1) {
                                System.out.println("    Elige el proyecto en concreto:");
                                int opcionProyMod = this.leeListado(limSupProy);
                                System.out.println("    Introduce el número de años (entre 0 y 10):");
                                int annos = this.leeDesde0(10);
                                System.out.println("    Introduce el número de meses (entre 0 y  11):");
                                int meses = this.leeDesde0(11);
                                System.out.println("    Introduce el número de días (entre 0 y  30):");
                                int dias = this.leeDesde0(30);
                                this.datos.cambiaDuracionPrevProyecto(tipoProyecto, opcionProyMod,
                                annos, meses, dias, this.identEmpleado);
                            } else if (opcionProy == 2) {
                                System.out.println("    Elige el proyecto en concreto:");
                                int opcionProyMod = this.leeListado(limSupProy);
                                System.out.println("    Introduce la fecha de fin de obra:");
                                LocalDate fechaFinObra = this.leeFecha();
                                this.datos.cambiaFechaFinObrasProyecto(tipoProyecto, opcionProyMod,
                                fechaFinObra ,this.identEmpleado);
                            }
                        }
                    } else {
                        System.out.println("    Gestión de certificados asignados:");
                        System.out.println("    Elige el tipo de certificado:\n    1 - Certificados de habitabilidad.");
                        System.out.println("    2 - Certificados de inspección.\n    3 - Certificados de eficiencia.");
                        System.out.println("    4 - Informes periciales.\n    5 - Salir.");
                        int tipoCertificado = this.leeDesde1(5);
                        int limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 2, this.identEmpleado);
                        while (limSupCert == 0 && tipoCertificado < 5)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoCertificado = this.leeDesde1(5);
                            limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 2, this.identEmpleado);
                        }
                        if (tipoCertificado < 5){
                            this.datos.visualizaCertificadosPorEmpleado(tipoCertificado, 2, this.identEmpleado);
                            System.out.println("    1 - Modificar la fecha de emisión de un certificado.");
                            int opcionCert = -1;
                            if (tipoCertificado == 3){
                                System.out.print("    2 - Modificar la categoría de un certificado.\n    3 - Salir");
                                opcionCert = this.leeDesde1(3);
                            } else {
                                System.out.print("    2 - Salir.");
                                opcionCert = this.leeDesde1(2);
                            }
                            if (opcionCert == 1){
                                System.out.println("    Elige el certificado en concreto:");
                                int opcionCertMod = this.leeListado(limSupCert);
                                System.out.println("    Cambia su fecha de emisión:");
                                LocalDate fechaEmision = this.leeFecha();
                                this.datos.cambiaEmisionCertificado(tipoCertificado, opcionCertMod,
                                fechaEmision, this.identEmpleado);
                            } else if (tipoCertificado == 3 && opcionCert == 2) {
                                System.out.println("    Elige el certificado en concreto:");
                                int opcionCertMod = this.leeListado(limSupCert);
                                System.out.println("    Cambia su categoría:\n    1 - A.\n    2 - B.\n    3 - C.");
                                System.out.println("\n    4 - D.\n    5 - E.\n    6 - F.\n    7 - G.");
                                int categoria = this.leeDesde1(7);
                                this.datos.cambiaCategoriaEfic(opcionCertMod, categoria, this.identEmpleado);
                            }
                        }
                    }
                    break;
                case 3:
                    this.modo = Modo.ENTRADA;
                    break;
            }
        }
    }
    
    /**
     * Gestiona el menú de Entrada del Aparejador. Da tres opciones:
     * 
     * 1 - Consulta de los clientes asignados
     * 2 - Gestión de proyectos y certificados asignados
     * 3 - Consulta de visitas pendientes
     * 4 - Salir
     */
    private void gestionaEntradaApar()
    {
        while (this.modo == Modo.APARENT)
        {
            System.out.println("\n    ENTRADA DE APAREJADORES.\n\n    Elige qué quieres hacer:");
            System.out.println("    1 - Consulta de los clientes asignados.");
            System.out.println("    2 - Consulta de proyectos y certificados asignados.");
            System.out.println("    3 - Consulta de visitas pendientes.\n    4 - Salir.");
            int opcion = this.leeDesde1(4);
            switch (opcion)
            {
                case 1:
                    this.datos.visualizaClientesPorAparejador(this.identEmpleado);
                    this.terminaVisual();
                    break;
                case 2:
                    System.out.println("    Consulta de proyectos y certificados asignados:\n\nElige qué quieres hacer:");
                    System.out.println("    1 - Consultar proyectos.\n    2 - Consultar certificados.\n    3 - Salir.");
                    int opcionCons = this.leeDesde1(3);
                    if (opcionCons == 1){
                        System.out.println("    Consulta de proyectos asignados:");
                        System.out.println("\n    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                        System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                        System.out.println("    4 - Salir.");
                        int tipoProyecto = this.leeDesde1(4);
                        int limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 3, this.identEmpleado);
                        while (limSupProy == 0 && tipoProyecto < 4)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoProyecto = this.leeDesde1(4);
                            limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 3, this.identEmpleado);
                        }
                        this.datos.visualizaProyectosPorEmpleado(tipoProyecto, 3, this.identEmpleado);
                    } else {
                        System.out.println("    Consulta de certificados asignados:");
                        System.out.println("    Elige el tipo de certificado:\n    1 - Certificados de habitabilidad.");
                        System.out.println("    2 - Certificados de eficiencia.\n    3 - Salir.");
                        int tipoCertificado = this.leeDesde1(3);
                        if (tipoCertificado == 2) {
                            tipoCertificado++;
                        } else if (tipoCertificado == 3) {
                            tipoCertificado = tipoCertificado + 2;
                        }
                        int limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 3, this.identEmpleado);
                        while (limSupCert == 0 && tipoCertificado < 5)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoCertificado = this.leeDesde1(3);
                            if (tipoCertificado == 2) {
                                tipoCertificado++;
                            } else if (tipoCertificado == 3) {
                                tipoCertificado = tipoCertificado + 2;
                            }
                            limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 3, this.identEmpleado);
                        }
                        this.datos.visualizaCertificadosPorEmpleado(tipoCertificado, 3, this.identEmpleado);
                    }
                    break;
                case 3:
                    this.datos.visualizaClientesPendApar(this.identEmpleado);
                    this.terminaVisual();
                    break;
                case 4:
                    this.modo = Modo.ENTRADA;
                    break;
            }
        }
    }
    
    /**
     * Gestiona el menú de Entrada del Contable. Da tres opciones:
     * 
     * 1 - Consulta de los clientes asignados
     * 2 - Gestión de proyectos y certificados asignados
     * 3 - Salir
     */
    private void gestionaEntradaCont()
    {
        while (this.modo == Modo.CONTENT)
        {
            System.out.println("\n    ENTRADA DE CONTABLES.\n\n    Elige qué quieres hacer:");
            System.out.println("    1 - Consulta de los clientes asignados.");
            System.out.println("    2 - Gestión de proyectos y certificados asignados.\n    3 - Salir.");
            int opcion = this.leeDesde1(3);
            switch (opcion)
            {
                case 1:
                    this.datos.visualizaClientesPorContable(this.identEmpleado);
                    this.terminaVisual();
                    break;
                case 2:
                    System.out.println("    Gestión de proyectos y certificados asignados:\n\n    Elige qué quieres hacer:");
                    System.out.println("    1 - Consultar proyectos.\n    2 - Consultar certificados.\n    3 - Salir.");
                    int opcionCons = this.leeDesde1(3);
                    if (opcionCons == 1){
                        System.out.println("    Gestión de proyectos asignados:");
                        System.out.println("\n    Elige el tipo de proyecto:\n    1 - Construcciones residenciales.");
                        System.out.println("    2 - Construcciones no residenciales.\n    3 - Rehabilitaciones.");
                        System.out.println("    4 - Salir.");
                        int tipoProyecto = this.leeDesde1(4);
                        int limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 4, this.identEmpleado);
                        while (limSupProy == 0 && tipoProyecto < 4)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoProyecto = this.leeDesde1(4);
                            limSupProy = this.datos.devuelveNumProyectosPorEmpleado(tipoProyecto, 4, this.identEmpleado);
                        }
                        if (tipoProyecto < 4){
                            this.datos.visualizaProyectosPorEmpleado(tipoProyecto, 4, this.identEmpleado);
                            System.out.println("    1 - Modificar el presupuesto de un proyecto.\n    2 - Salir.");
                            int opcionProy = this.leeDesde1(2);
                            if (opcionProy == 1){
                                System.out.println("    Elige el proyecto en concreto:");
                                int opcionProyMod = this.leeListado(limSupProy);
                                System.out.println("    Introduce el valor del presupuesto en € (entre 100.000 y 10.000.000):");
                                int presupuesto = this.leeDatosNumericos(100_000, 10_000_000);
                                this.datos.cambiaPresupuestoProyecto(tipoProyecto, opcionProyMod,
                                presupuesto, this.identEmpleado);
                            }
                        }
                    } else {
                        System.out.println("    Gestión de certificados asignados:");
                        System.out.println("    Elige el tipo de certificado:\n    1 - Certificados de habitabilidad.");
                        System.out.println("    2 - Certificados de inspección.\n    3 - Certificados de eficiencia.");
                        System.out.println("    4 - Informes periciales.\n    5 - Salir.");
                        int tipoCertificado = this.leeDesde1(4);
                        int limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 4, this.identEmpleado);
                        while (limSupCert == 0 && tipoCertificado < 5)
                        {
                            System.out.println("    No tienes asignado ninguno de ese tipo.");
                            tipoCertificado = this.leeDesde1(5);
                            limSupCert = this.datos.devuelveNumCertificadosPorEmpleado(tipoCertificado, 4, this.identEmpleado);
                        }
                        if (tipoCertificado < 5){
                            this.datos.visualizaCertificadosPorEmpleado(tipoCertificado, 4, this.identEmpleado);
                            System.out.println("    1 - Modificar el presupuesto de un certificado.\n    2 - Salir.");
                            int opcionCert = this.leeDesde1(2);
                            if (opcionCert == 1){
                                System.out.println("    Elige el certificado en concreto:");
                                int opcionCertMod = this.leeListado(limSupCert);
                                System.out.println("    Introduce el valor del presupuesto en € (entre 30 y 150):");
                                int presupuesto = this.leeDatosNumericos(30, 150);
                                this.datos.cambiaPresupuestoCertificado(tipoCertificado, opcionCertMod,
                                presupuesto, this.identEmpleado);
                            }
                        }
                    }
                    break;
                case 3:
                    this.modo = Modo.ENTRADA;
                    break;
            }
        }
    }
    
    /**
     * Gestiona que la aplicación use el método correcto
     */
    public void gestionaAplicacion()
    {
        while (this.modo != Modo.CERRAR){
            switch (this.modo)
            {
                case INICIAL:
                    this.gestionaInicial();
                    break;
                case ENTRADA:
                    this.gestionaEntrada();
                    break;
                case ADMINENT:
                    this.gestionaEntradaAdmin();
                    break;
                case INDIV:
                    this.gestionaIndividuos();
                    break;
                case CLIENGEST:
                    this.gestionaClien();
                    break;
                case EDIFIC:
                    this.gestionaEntradaEdific();
                    break;
                case EDIFICGEST:
                    this.gestionaEdific();
                    break;
                case TAREAS:
                    this.gestionaTareas();
                    break;
                case PROYECTOS:
                    this.gestionaProyectos();
                    break;
                case CERTIFICADOS:
                    this.gestionaCertificados();
                    break;
                case PLAN:
                    this.gestionaPlanificacion();
                    break;
                case ARQUITENT:
                    this.gestionaEntradaArquit();
                    break;
                case APARENT:
                    this.gestionaEntradaApar();
                    break;
                case CONTENT:
                    this.gestionaEntradaCont();
                    break;
            }
        }
    }
}
