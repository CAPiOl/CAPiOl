import java.time.LocalDate;

/**
 * La clase Comunitario define uno de los dos tipos de edificios residenciales
 * Se asume que es un bloque de pisos, todos los cuales tienen la misma estructura,
 * definida por la clase privada heredada Vivienda, todas con una única planta (plantas = 1).
 * Las plantas con pisos tienen también estructuras comparables, con el mismo número de pisos.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class Comunitario extends Residencial
{
    /**
     * Campos específicos para construir la subclase Comunitario.
     * plantasPisos es el número total de plantas con pisos
     * pisosPorPlanta el número de pisos por planta
     */
    private int plantasPisos;
    private int pisosPorPlanta;
    /**
     * Campos específicos de la subclase Comunitario cuyo valor se asigna automáticamente.
     * totalPisos es el producto de plantasViviendas y pisosPorPlanta.
     * fechaInspeccion se calcula respecto al campo heredado fechaEdificacion y a duracionInspecc.
     */
    private int totalPisos;
    private LocalDate fechaInspeccion;
    private final int duracionInspecc = 45;
    
    /**
     * Constructor
     */
    public Comunitario(int identificador)
    {
        super(identificador);
    }
    
    /**
     * Modifica las características de la variable tipoVivienda con la limitación de una planta
     */
    public void modificaViviendas(int habitaciones, int aseos)
    {
        super.modificaViviendas(1, habitaciones, aseos);
    }
    
    /**
     * Devuelve el número de plantas con pisos
     */
    public int devuelvePlantasPisos()
    {
        return this.plantasPisos;
    }
    
    /**
     * Modifica el número de plantas con pisos
     */
    public void modificaPlantasPisos(int plantasPisos)
    {
        this.plantasPisos = plantasPisos;
    }
    
    /**
     * Devuelve el número de pisos por planta
     */
    public int devuelvePisosPorPlanta()
    {
        return this.pisosPorPlanta;
    }
    
    /**
     * Modifica el número de pisos por planta
     */
    public void modificaPisosPorPlanta(int pisosPorPlanta)
    {
        this.pisosPorPlanta = pisosPorPlanta;
    }
    
    /**
     * Actualiza el número total de pisos
     * Depende de los campos plantasPisos y pisosPorPlanta
     */
    private void actualizaTotalPisos()
    {
        this.totalPisos = this.plantasPisos * this.pisosPorPlanta;
    }
    
    /**
     * Devuelve el total de pisos. Primero actualiza su valor
     */
    public int devuelveTotalPisos()
    {
        this.actualizaTotalPisos();
        return this.totalPisos;
    }
    
    /**
     * Actualiza la fecha de inspección
     */
    private void actualizaFechaInspeccion()
    {
        this.fechaInspeccion = this.fechaEdificacion.plusYears(this.duracionInspecc);
    }
    
    /**
     * Devuelve la fecha de inspección
     */
    public LocalDate devuelveFechaInspeccion()
    {
        this.fechaInspeccion = this.fechaEdificacion.plusYears(this.duracionInspecc);
        return this.fechaInspeccion;
    }
    
    /**
     * Devuelve el valor TipoResidencial COMUNITARIO
     */
    public TipoResidencial devuelveTipoResidencial()
    {
        return TipoResidencial.COMUNITARIO;
    }
    
    /**
     * Devuelve el Comunitario como String
     */
    public String toString()
    {
        this.actualizaTotalPisos();
        String datos = this.devuelveDatos();
        datos = datos.concat("\n    " + this.devuelveTipoResidencial() + " " + plantasPisos + " plantas, ");
        datos = datos.concat(totalPisos + " pisos\n    Cada piso tiene ");
        datos = datos.concat(this.devuelveDatosVivienda());
        return datos;
    }
}
