import java.time.LocalDate;

/**
 * Clase abstracta Residencial. Será la base de los domicilios particulares.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public abstract class Residencial extends Edificacion
{
    /**
     * Enumeración TipoResidencial (para identificar mejor el tipo de Residencial)
     */
    protected enum TipoResidencial{UNIFAMILIAR, COMUNITARIO};
    
    /**
     * Clase privada Vivienda. Esta clase definirá una vivienda destinada a una sola familia.
     * Como nuestras Residencias pueden ser comunitarias o unifamiliares, es conveniente.
     */
    private class Vivienda
    {
        /**
         * Campos de la Vivienda: número de plantas, número de habitaciones y número de baños
         */
        private int plantas;
        private int habitaciones;
        private int aseos;
        
        /**
         * Constructor
         */
        private Vivienda(int plantas, int habitaciones, int aseos)
        {
            this.plantas = plantas;
            this.habitaciones = habitaciones;
            this.aseos = aseos;
        }
        
        /**
         * Devuelve el número de plantas
         */
        private int devuelvePlantas()
        {
            return this.plantas;
        }
        
        /**
         * Modifica el número de plantas
         */
        private void modificaPlantas(int plantas)
        {
            this.plantas = plantas;
        }
        
        /**
         * Devuelve el número de habitaciones
         */
        private int devuelveHabitaciones()
        {
            return this.habitaciones;
        }
         
        /**
         * Modifica el número de habitaciones
         */
        private void modificaHabitaciones(int habitaciones)
        {
            this.habitaciones = habitaciones;
        }
        
        /**
         * Devuelve el número de aseos
         */
        private int devuelveAseos()
        {
            return this.aseos;
        }
         
        /**
         * Método que modifica el número de aseos
         */
        private void modificaAseos(int aseos)
        {
            this.aseos = aseos;
        }
        
        /**
         * Modifica todos los campos
         */
        private void modificaTodo(int plantas, int habitaciones, int aseos)
        {
            this.modificaPlantas(plantas);
            this.modificaHabitaciones(habitaciones);
            this.modificaAseos(aseos);
        }
        
        /**
         * Devuelve la Vivienda como String
         */
        public String toString()
        {
            String datos = this.plantas + " planta";
            if (this.plantas > 1){
                datos = datos.concat("s");
            }
            datos = datos.concat(", " + this.habitaciones + " habitaciones y " + this.aseos + " baño");
            if (this.aseos > 1){
                datos = datos.concat("s");
            }
            return datos;
        }
    }
    
    /**
     * Campos comunes a todas los Residenciales:
     * la Vivienda basica y la fecha de de caducidad a partir de la cual necesitaría un certificado de habitabilidad
     * Se incluye el tiempo en años de validez como constante
     */
    protected Vivienda tipoVivienda;
    protected LocalDate fechaCaduc;
    protected final int duracionHabitab = 15;
    
    /**
     * Constructor
     */
    public Residencial(int identificador)
    {
        super(identificador);
        tipoVivienda = new Vivienda(0, 0, 0);
    }
    
    /**
     * Devuelve el número de plantas de tipoVivienda
     */
    public int devuelvePlantasVivienda()
    {
        return this.tipoVivienda.devuelvePlantas();
    }
    
    /**
     * Devuelve el número de habitaciones de tipoVivienda
     */
    public int devuelveHabitacionesVivienda()
    {
        return this.tipoVivienda.devuelveHabitaciones();
    }
    
    /**
     * Devuelve el número de baños de tipoVivienda
     */
    public int devuelveAseosVivienda()
    {
        return this.tipoVivienda.devuelveAseos();
    }
    
    /**
     * Modifica las características de la variable tipoVivienda
     */
    public void modificaViviendas(int plantas, int habitaciones, int aseos)
    {
        this.tipoVivienda.modificaTodo(plantas, habitaciones, aseos);
    }
    
    /**
     * Actualiza la fecha de caducidad
     */
    private void actualizaFechaCaduc()
    {
        this.fechaCaduc = this.fechaEdificacion.plusYears(this.duracionHabitab);
    }
    
    /**
     * Devuelve la fecha de caducidad
     */
    public LocalDate devuelveFechaCaduc()
    {
        this.actualizaFechaCaduc();
        return this.fechaCaduc;
    }
    
    /**
     * Devuelve el valor TipoResidencial del Residencial
     */
    protected abstract TipoResidencial devuelveTipoResidencial();
    
    /**
     * Devuelve los datos básicos de la Residencial como String,
     * es parte de los métodos toString de las subclases.
     */
    protected String devuelveDatosVivienda()
    {
        return " Tiene " + this.tipoVivienda.toString();
    }
}
