
/**
 * Clase NoResidencial, es la clase de cualquier construcción que no sea un lugar para vivir.
 * 
 * @Carlos Alberto Piñero Olanda
 * @13/05/2022
 */
public class NoResidencial extends Edificacion
{
    /**
     * Enumeración Finalidad
     */
    private enum Finalidad{INDUSTRIAL, EDUCATIVO, RELIGIOSO, ARTISTICO, ESPECTACULOS, COMERCIAL, SANITARIO, GUBERNAMENTAL};
    
    /**
     * Campo que expresa la finalidad del NoResidencial
     */
    private Finalidad finalidad;
    
    /**
     * Constructor
     */
    public NoResidencial(int identificador)
    {
        super(identificador);
        this.finalidad = null;
    }

    /**
     * Devuelve la finalidad
     */
    public Finalidad devuelveFinalidad()
    {
        return this.finalidad;
    }
    
    /**
     * Modifica la finalidad
     */
    public void modificaFinalidad(int finalidad)
    {
        Finalidad[] finalidades = {
            Finalidad.INDUSTRIAL, Finalidad.EDUCATIVO, Finalidad.RELIGIOSO, Finalidad.ARTISTICO, Finalidad.ESPECTACULOS,
            Finalidad.COMERCIAL, Finalidad.SANITARIO, Finalidad.GUBERNAMENTAL};
        this.finalidad = finalidades[finalidad];
    }
    
    /**
     * Devuelve el NoResidencial como String
     */
    public String toString()
    {
        String datos1 = this.devuelveDatos();
        datos1 = datos1 + "\n    Finalidad " + this.finalidad;
        return datos1;
    }
}
