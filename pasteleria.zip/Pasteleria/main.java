import java.io.BufferedReader;
import java.io.FileReader;
import java.io.PrintStream;
import java.io.File;

/**
 * Clase main.
 * Esta clase se ocupa de:
 * 1. La lectura de los archivos según la dirección pasada en el argumento.
 * 2. La llamada a la clase Pasteleria y su método de asignación.
 * 3. La escritura del archivo según la dirección pasada.
 * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public class main
{
    /**
     * Muestra la ayuda si se elige esa opción.
     */
    private static void muestraAyuda()
    {
        System.out.println("AYUDA\n La sintaxis del programa es: java pasteleria [-t][-h] [fichero_entrada]  [fichero_salida]");
        System.out.println("-t                (OPCIONAL) Traza el programa.");
        System.out.println("-h                (OPCIONAL) Muestra esta ayuda.");
        System.out.println("fichero_entrada   Dirección del fichero de entrada");
        System.out.println("fichero_salida    (OPCIONAL) Dirección del fichero de salida. Si no se pasa, se creará in situ.");
        System.out.println("\nACLARACIÓN: Si sólo se da una dirección, se entenderá que es el fichero de entrada.\n");
    }
    
    /**
     * Método main, lleva a cabo la asignación de la pastelería.
     * También muestra la ayuda o la traza si se piden.
     */
    public static void main(String[] args) throws java.io.IOException
    {
        String entrada = "";
        String salida = "";
        boolean ayudaSi = false;
        boolean hayTraza = false;
        //Según el número de argumentos y cuáles sean, se determinará qué hacer.
        switch (args.length)
        {
            case 0:
                System.out.println("No hay argumentos.");
                break;
            case 1:
                if (args[0].equals("-h")){
                    muestraAyuda();
                    return;
                }
                else if (!args[0].equals("-t")){
                    entrada = args[0];
                    salida = entrada + "_salida";
                } else {return;}
                break;
            case 2:
                if (args[0].equals("-h")){
                    muestraAyuda();
                    if (!args[1].equals("-t")){
                        entrada = args[1];
                        salida = entrada + "_salida";
                    } else {return;}
                } else if (args[0].equals("-t")){
                    hayTraza = true;
                    entrada = args[1];
                    salida = entrada + "_salida";
                } else {
                    entrada = args[0];
                    salida = args[1];
                }
                break;
            case 3:
                if (args[0].equals("-h")){muestraAyuda();}
                else if (args[0].equals("-t")){hayTraza = true;}
                entrada = args[1];
                salida = args[2];
                break;
            case 4:
                if (args[0].equals("-t")){muestraAyuda();}
                if (args[1].equals("-h")){hayTraza = true;}
                entrada = args[2];
                salida = args[3];
                break;
        }
        //Se indica si se mostrará la traza.
        Traza traza = new Traza(hayTraza);
        
        //Empieza la lectura.
        traza.traza("Empieza la lectura del fichero.");
        BufferedReader lectura = new BufferedReader(new FileReader(entrada));
        String linea;
        String contenido = "";
        traza.traza("Se lee hasta que el fichero llegue a una línea en blanco.");
        while ((linea = lectura.readLine()) != null){contenido = contenido.concat(linea + "\n");}
        if (contenido == null){
            System.out.println("El archivo está vacío o mal configurado.");
            return;
        }
        //Se finaliza la lectura. El String obtenido se trata dentro de Pasteleria.
        traza.traza("Acaba la lectura del fichero.");
        lectura.close();
        
        //Se llama la Pasteleria y se realiza la asignación.
        traza.traza("Se crea la Pasteleria.");
        Pasteleria pasteleria = new Pasteleria(contenido, traza);
        traza.traza("Se ejecuta la asignación de pedidos de la Pasteleria.");
        pasteleria.asignaPasteleros();
        
        //Empieza la escritura.
        traza.traza("Empieza la escritura del fichero de salida.");
        PrintStream escritura = new PrintStream(new File(salida));
        escritura.print(pasteleria.toString());
        //Acaba la escritura.
        traza.traza("Acaba la escritura del fichero de salida.");
        escritura.close();
    }
}
