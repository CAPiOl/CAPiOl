
/**
 * Clase Traza
 * Esta clase existe para facilitar la aparición de la traza en caso afirmativo.
 * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public class Traza
{
    /**
     * El único campo necesario es si va a estar activa la traza.
     */
    private boolean activa;

    /**
     * Constructor.
     */
    public Traza(boolean activa){this.activa = activa;}

    /**
     * Muestra un mensaje de traza.
     */
    public void traza(String mensaje){if (this.activa){System.out.println(mensaje);}}
}
