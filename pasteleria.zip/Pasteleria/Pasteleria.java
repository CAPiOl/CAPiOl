import java.util.ArrayList;

/**
 * Clase Pasteleria
 * Incluye los métodos necesarios para:
 * 1. La creación de los objetos de partida necesarios a partir de un fichero.
 * 2. El cálculo de los parámetros de cada Rama.
 * 3. La asignación de pasteleros mediante una selección por montículo.
 * 3. La creación de un String para devolver los datos de la asignación realizada y el coste total.
 * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public class Pasteleria
{
    /**
     * Clase privada Rama
     * Expresa las ramas creadas durante el algoritmo de asignación de pasteleros con los datos que les hayan sido asignados.
     * Es una extensión de la clase abstracta Nodo.
     */
    private class Rama extends Nodo
    {
        /**
         * Campos de la Rama:
         * -Un ArrayList de booleanos que indica cuáles pasteleros están ya asignados.
         * -Un ArrayList de enteros para indicar el orden de los pasteleros ya asignados.
         * -Un entero para el último pedido asignado.
         * -Un entero para el coste de los pedidos ya asignados.
         * -Un entero para la estimación del coste mínimo posible.
         */
        private ArrayList<Boolean> ocupados;
        private ArrayList<Integer> encargados;
        private int ultPedido;
        private int costeNodo;
        private int estOpt;
        
        /**
         * Constructor.
         */
        private Rama(ArrayList<Boolean> ocupados, ArrayList<Integer> encargados, int ultPedido, int costeNodo, int estOpt)
        {
            this.ocupados = ocupados;
            this.encargados = encargados;
            this.ultPedido = ultPedido;
            this.costeNodo = costeNodo;
            this.estOpt = estOpt;
        }
        
        /**
         * Devuelve los pasteleros ya asignados.
         */
        private ArrayList<Boolean> devOcupados(){return this.ocupados;}
        
        /**
         * Devuelve el orden de pasteleros ya asignados.
         */
        private ArrayList<Integer> devEncargados(){return this.encargados;}
        
        /**
         * Devuelve el último pedido.
         */
        private int devPedido(){return this.ultPedido;}
        
        /**
         * Devuelve el coste de la Rama.
         */
        private int devCosteRama(){return this.costeNodo;}
        
        /**
         * Devuelve la estimación del coste mínimo posible.
         */
        private int devEstOpt(){return this.estOpt;}
        
        /**
         * Devuelve la estimación optimista de la Rama para el montículo.
         */
        public float devValor(){return new Float(this.devEstOpt());}
    }
    
    /**
     * Los campos son:
     * -Una matriz de enteros (ArrayList de ArrayLists) que indica el coste de preparar los diferentes pasteles por cada pastelero.
     * -Un ArrayList de enteros que expresa los pedidos encargados.
     * -Un ArrayList de enteros para indicar los pasteleros asignados al pedido.
     * -Un entero para expresar el coste total.
     * -Una Traza para mostrar la traza del algoritmo.
     */
    private ArrayList<ArrayList<Integer>> costes;
    private ArrayList<Integer> pedidos;
    private ArrayList<Integer> encargados;
    private int costeTotal;
    private Traza traza;

    /**
     * El contructor toma el texto leído del fichero y toma los datos que necesitamos para el algoritmo.
     */
    public Pasteleria(String fichero, Traza traza)
    {
        this.traza = traza;
        traza.traza("Se inicializan los campos de Pasteleria.");
        this.costes = new ArrayList<ArrayList<Integer>>();
        this.pedidos = new ArrayList<Integer>();
        this.encargados = new ArrayList<Integer>();
        this.costeTotal = 0;
        traza.traza("Se divide el texto del fichero por líneas.");
        String[] lineas = fichero.split("\n");
        int pasteleros = new Integer(lineas[0]);
        int carta = new Integer(lineas[1]);
        String[] pedidos = lineas[2].split("-");
        traza.traza("Se leen los pedidos.");
        for (int p = 0; p < pedidos.length; p++)
        {
            //Si hubiera más pedidos que pasteleros, se cortaría la adición de pedidos
            if (p == pasteleros){break;}
            this.pedidos.add(new Integer(pedidos[p]));
        }
        int numLineas = lineas.length;
        traza.traza("Empieza la lectura de los costes de cada pastelero.");
        for (int i = 0; i < pasteleros; i++)
        {
            traza.traza("Se lee otro pastelero.");
            String linea = lineas[i + 3];
            if (linea == null){continue;}
            String[] linDatos = linea.split(" ");
            if (linDatos.length < carta){continue;}
            ArrayList<Integer> costesPastelero = new ArrayList<Integer>();
            for (int c = 0; c < carta; c++){costesPastelero.add(new Integer(linDatos[c]));}
            this.costes.add(costesPastelero);
        }
        traza.traza("Acaba la lectura del texto.");
    }
    
    /**
     * Devuelve el coste que conlleva que un pastelero haga un tipo de pastel.
     */
    private int devCosteCelda(int pastelero, int plato){return this.costes.get(pastelero).get(plato);}
    
    /**
     * Devuelve el peor coste posible según los pedidos ya asignados.
     */
    private int calcPesim(int pedido, int costeNodo)
    {
        int nuevEstim = costeNodo;
        for (int ped = pedido + 1; ped < this.pedidos.size(); ped++)
        {
            int colPedido = this.pedidos.get(ped) - 1;
            int mayor = this.devCosteCelda(0, colPedido);
            for (int fila = 1; fila < this.costes.size(); fila++)
            {
                int costeCelda = this.devCosteCelda(fila, colPedido);
                if (mayor < costeCelda){mayor = costeCelda;}
            }
            nuevEstim += mayor;
        }
        return nuevEstim;
    }
    
    /**
     * Devuelve el mejor coste posible según los pedidos ya asignados.
     */
    private int calcOptim(int pedido, int costeNodo)
    {
        int nuevEstim = costeNodo;
        for (int ped = pedido + 1; ped < this.pedidos.size(); ped++)
        {
            int colPedido = this.pedidos.get(ped) - 1;
            int menor = this.devCosteCelda(0, colPedido);
            for (int fila = 1; fila < this.costes.size(); fila++)
            {
                int costeCelda = this.devCosteCelda(fila, colPedido);
                if (menor > costeCelda){menor = costeCelda;}
            }
            nuevEstim += menor;
        }
        return nuevEstim;
    }
    
    /**
     * Asigna los pasteleros a los pedidos, minimizando el coste mediante una selección por montículo.
     */
    public void asignaPasteleros()
    {
        traza.traza("Se empieza creando el primer nodo padre.");
        int optima = this.calcOptim(-1, 0);
        int pedido = -1;
        ArrayList<Boolean> ocupNodo = new ArrayList<Boolean>();
        for (int p = 0; p < this.pedidos.size(); p++){ocupNodo.add(false);}
        Rama padre = new Rama(ocupNodo, new ArrayList<Integer>(this.encargados), pedido, 0, optima);
        MonticuloGeneral<Rama> montic = new MonticuloGeneral<Rama>(false);
        montic.insertaValor(padre);
        int cota = this.calcPesim(0, optima);
        while (!montic.estaVacio() && montic.devPrim().devEstOpt() <= cota)
        {
            traza.traza("Se saca la cima del montículo y se obtienen sus parámetros.");
            padre = montic.obtenCima();
            pedido = padre.devPedido() + 1;
            ArrayList<Integer> encargNodo = padre.devEncargados();
            ocupNodo = padre.devOcupados();
            for (int i = 0; i < ocupNodo.size(); i++)
            {
                if (ocupNodo.get(i)){continue;}
                int pastelero = i + 1;
                traza.traza("Se asigna el pastelero " + pastelero + " a otro pedido.");
                ArrayList<Boolean> ocupNodoIter = new ArrayList<Boolean>(ocupNodo);
                ocupNodoIter.set(i, true);
                ArrayList<Integer> encargNodoIter = new ArrayList<Integer>(encargNodo);
                encargNodoIter.add(pastelero);
                int costeNodo = padre.devCosteRama() + this.devCosteCelda(i, this.pedidos.get(pedido) - 1);
                if (pedido + 1 == this.pedidos.size())
                {
                    traza.traza("Hemos asignados todos los pedidos. Si los costes son aceptables, se actualizará la asignación.");
                    if (cota >= costeNodo)
                    {
                        traza.traza("Se ha actualizado la asignación.");
                        this.encargados = new ArrayList<Integer>(encargNodoIter);
                        this.costeTotal = costeNodo;
                        cota = this.costeTotal;
                    }
                }
                else
                {
                    int pedPend = this.pedidos.size() - pedido - 1;
                    traza.traza("Aún quedan " + pedPend + " pedidos por asignar, así que creamos un nuevo nodo.");
                    optima = this.calcOptim(pedido, costeNodo);
                    Rama hijo = new Rama(ocupNodoIter, encargNodoIter, pedido, costeNodo, optima);
                    traza.traza("Lo insertamos en el montículo.");
                    montic.insertaValor(hijo);
                    int pesima = this.calcPesim(pedido, costeNodo);
                    if (cota > pesima){cota = pesima;}
                }
            }
        }
    }
    
    /**
     * Devuelve un texto para el fichero de salida con:
     * -La asignación de pasteleros a los pedidos.
     * -El coste total.
     */
    public String toString()
    {
        String contenido = "";
        for (int enc = 0; enc < this.encargados.size(); enc++)
        {
            String separador = "-";
            if (enc == this.encargados.size() - 1){separador = "\n";}
            contenido = contenido.concat(this.encargados.get(enc) + separador);
        }
        contenido = contenido.concat(this.costeTotal + "");
        return contenido;
    }
}
