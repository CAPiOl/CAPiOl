
/**
 * Clase abstracta Nodo
 * Esta clase va a ser la base de elementos más complejos que un número que han de ser ordenados con algoritmos.
 * Por ejemplo, heapsort, mergesort, quicksort...
 * Para ello, cada subclase concreta tendrá su propia implementación del método devValor.
 * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public abstract class Nodo
{
    /**
     * Devuelve el valor numérico que tiene el elemento genérico. Como cada cual tendrá sus características, es abstracto.
     */
    abstract public float devValor();
}
