import java.util.ArrayList;
import java.util.Collections;

/**
 * Clase MonticuloGeneral
 * Un montículo es una modalidad de árbol binario balanceado. Sus principales características son:
 * 1. Sus elementos son numéricos y puede haber más de uno con el mismo valor.
 * 2. Se ordenan de modo que la raíz es o bien el mayor, o bien el menor del montículo.
 * 3. Por ello, los hijos de un nodo son siempre o bien menores o iguales, o bien mayores o iguales.
 * Ahora bien, un montículo puede tener elementos más complejos que un número, ordenándose respecto a sus parámetros.
 * Esta implementación es una generalización del montículo numérico para tratar correctamente estos casos.
 * Usa genéricos para así poder obtener en cada caso el objeto necesario.
 * Estos serán extensiones de la clase abstracta auxiliar Nodo para obtener el valor respecto al cual deben ordenarse.
 * 
 * @Carlos Alberto Piñero Olanda
 * @2022/12
 */
public class MonticuloGeneral<E extends Nodo>
{
    /**
     * Enumeración TipoMontic. Indica si el montículo es de máximos o de mínimos.
     */
    private enum TipoMontic{MAX, MIN};
    
    /**
     * Los campos son:
     * -Un vector de genéricos que contendrán el elemento que ha de ordenarse.
     * -Un entero para el tamaño del montículo, que viene a ser el mismo que del vector.
     * -Un TipoMontic para definir el tipo de montículo.
     */
    private ArrayList<E> vector;
    private int nodos;
    private TipoMontic tipo;

    /**
     * Constructor de un montículo vacío.
     */
    public MonticuloGeneral(boolean max)
    {
        this.vector = new ArrayList<E>();
        this.nodos = 0;
        if (max){tipo = TipoMontic.MAX;} else {tipo = TipoMontic.MIN;}
    }

    /**
     * Constructor de un montículo a partir de un vector.
     */
    public MonticuloGeneral(ArrayList<E> vector, boolean max)
    {
        this(max);
        this.vector = vector;
        this.nodos = this.vector.size();
        for (int i = this.nodos / 2; i >= 0; i--){this.hunde(i);}
    }
    
    /**
     * Determina si el valor de la posición 1 es mayor o menor que la de posición 2 según el tipo de montículo.
     * Para uno de mínimos, compara los negativos.
     */
    private boolean esPos1MayorPos2(int pos1, int pos2)
    {
        Nodo pr = this.vector.get(pos1);
        Nodo se = this.vector.get(pos2);
        int factor = 1;
        if (tipo == TipoMontic.MIN){factor = -1;}
        return factor * pr.devValor() > factor * se.devValor();
    }
    
    /**
     * Intercambia los valores de las posiciones 1 y 2.
     */
    private void intercValores(int pos1, int pos2){Collections.swap(this.vector, pos1, pos2);}
    
    /**
     * Comprueba si el montículo está vacío.
     */
    public boolean estaVacio(){return this.nodos == 0;}
    
    /**
     * Determina si un valor está mal ordenado respecto a su padre.
     */
    private boolean debeFlotar(int pos)
    {
        int posPadre = 0;
        if (pos > 0){posPadre = (pos + 1) / 2 - 1;}
        return this.esPos1MayorPos2(pos, posPadre);
    }
    
    /**
     * Mientras un un valor no esté bien ordenado respecto a sus sucesivos padres, intercambiará sus posiciones.
     */
    private void flota(int pos)
    {
        while (this.debeFlotar(pos))
        {
            int posPadre = (pos + 1) / 2 - 1;
            this.intercValores(pos, posPadre);
            pos = posPadre;
        }
    }
    
    /**
     * Comprueba si un valor está mal ordenado respecto a cualquiera de sus hijos.
     * Como un árbol binario puede tener dos hijos, es necesario indicar cuál es el que se va a devolver en su caso.
     */
    private int debeHundir(int pos)
    {
        int nuevaPos = -1;
        int posIzq = 2 * pos + 1;
        int posDer = 2 * pos + 2;
        boolean hayIzq = this.nodos >= posIzq + 1;
        boolean hayDer = this.nodos >= posDer + 1;
        if (hayIzq && this.esPos1MayorPos2(posIzq, pos)){nuevaPos = 0;}
        if (hayDer && this.esPos1MayorPos2(posDer, pos) && this.esPos1MayorPos2(posDer, posIzq)){nuevaPos = 1;}
        return nuevaPos;
    }
    
    /**
     * Mientras un valor no esté bien ordenado respecto a sus sucesivos hijos, intercambiará su posición con el más adecuado.
     */
    private void hunde(int pos)
    {
        while (this.debeHundir(pos) > -1)
        {
            int posHijo = 2 * pos + 1 + this.debeHundir(pos);
            this.intercValores(pos, posHijo);
            pos = posHijo;
        }
    }
    
    /**
     * Añade un nuevo elemento al final y luego hace que flote.
     */
    public void insertaValor(E nodo)
    {
        this.vector.add(nodo);
        this.nodos++;
        this.flota(this.nodos - 1);
    }
    
    /**
     * Devuelve el elemento de la cima sin alterar el montículo.
     */
    public E devPrim(){return this.vector.get(0);}
    
    /**
     * Devuelve el elemento de la cima y la elimina, restaurando la propiedad de montículo.
     */
    public E obtenCima()
    {
        E cima = this.devPrim();
        this.vector.remove(0);
        this.nodos--;
        //Para restaurar un montículo con más de un elemento, debe subirse el último elemento hasta la cima y luego aplicar hunde(0)
        if (this.nodos > 1)
        {
            this.vector.add(0, this.vector.get(this.nodos - 1));
            this.vector.remove(this.nodos);
            this.hunde(0);
        }
        //Se devuelve la cima
        return cima;
    }
}
