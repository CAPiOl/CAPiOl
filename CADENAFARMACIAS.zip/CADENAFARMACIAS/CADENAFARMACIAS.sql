
# Fichero para la solución del Caso Práctico de "Bases de datos". 

# Modifíquelo para incluir el codigo necesario para llevar a cabo los pasos necesarios para
# resolver los distintos apartados. Debe incluir comentarios con explicaciones del código
# propuesto.


-- Si existe, borrar la base de datos CADENAFARMACIAS:

DROP DATABASE IF EXISTS CADENAFARMACIAS;

-- Crear la base de datos CADENAFARMACIAS:

CREATE DATABASE IF NOT EXISTS CADENAFARMACIAS;

-- Usar la base de datos CADENAFARMACIAS: 

USE CADENAFARMACIAS;


#################################################################################################
# 1. Cree la base de datos con las tablas que se extraen del diagrama E-R presentado y del propio 
#    enunciado del problema.
#################################################################################################

-- Crear la tabla Sucursales (se corresponde a la entidad Farmacia):
#DROP TABLE IF EXISTS Sucursales;
CREATE TABLE Sucursales (
  cifs char(9) NOT NULL,
  NombreSuc varchar(30) NOT NULL,
  Dirección varchar(40) NOT NULL,
  PRIMARY KEY (cifs)
);

-- Crear la tabla Medicamentos (se corresponde a la entidad Medicamento):
#DROP TABLE IF EXISTS Medicamentos;
CREATE TABLE Medicamentos (
  cim char(4) NOT NULL,
  NombreMed varchar(30) NOT NULL,
  PVP numeric(4,2),
  Descripción varchar(200) NOT NULL,
  PRIMARY KEY (cim)
);

-- Crear la tabla Inventarios (se corresponde a la relación Stock):
#DROP TABLE IF EXISTS Inventarios;
CREATE TABLE Inventarios (
  cifs char(9) NOT NULL,
  cim char(4) NOT NULL,
  Cantidad int UNSIGNED,
  Umbral int UNSIGNED,
  PRIMARY KEY (cifs, cim),
  FOREIGN KEY (cifs) REFERENCES Sucursales(cifs),
  FOREIGN KEY (cim) REFERENCES Medicamentos(cim)
);

-- Crear la tabla Pedidos (se corresponde a la entidad Pedido):
#DROP TABLE IF EXISTS Pedidos;
CREATE TABLE Pedidos (
  id_ped int NOT NULL AUTO_INCREMENT,
  fecha date,
  cifs char(9) NOT NULL,
  PRIMARY KEY (id_ped),
  FOREIGN KEY (cifs) REFERENCES Sucursales(cifs)
);

-- Crear la tabla DetallesPedidos (se corresponde a la entidad débil DetallePedido):
#DROP TABLE IF EXISTS DetallesPedidos;
CREATE TABLE DetallesPedidos (
  id_ped int NOT NULL,
  cim char(4) NOT NULL,
  Coste numeric(4,2),
  Cantidad int UNSIGNED,
  PRIMARY KEY (id_ped, cim),
  FOREIGN KEY (id_ped) REFERENCES Pedidos(id_ped),
  FOREIGN KEY (cim) REFERENCES Medicamentos(cim)
);

-- Crear la tabla Clientes (se corresponde a la entidad Cliente):
#DROP TABLE IF EXISTS Clientes;
CREATE TABLE Clientes (
  dni char(9) NOT NULL,
  NombreCl varchar(30) NOT NULL,
  PRIMARY KEY (dni)
);

-- Crear la tabla Ventas (se corresponde a parte de la relación Compra):
#DROP TABLE IF EXISTS Ventas;
CREATE TABLE Ventas (
  civ int NOT NULL AUTO_INCREMENT,
  cifs char(9) NOT NULL,
  dni char(9) NOT NULL,
  Fecha timestamp,
  PRIMARY KEY (civ),
  FOREIGN KEY (cifs) REFERENCES Sucursales(cifs),
  FOREIGN KEY (dni) REFERENCES Clientes(dni)
);

-- Crear la tabla DetallesVentas (se corresponde a parte de la relación Compra):
#DROP TABLE IF EXISTS DetallesVentas;
CREATE TABLE DetallesVentas (
  civ int NOT NULL,
  cim char(4) NOT NULL,
  PVP numeric(4,2),
  Unidades int UNSIGNED,
  PRIMARY KEY (civ, cim),
  FOREIGN KEY (civ) REFERENCES Ventas(civ),
  FOREIGN KEY (cim) REFERENCES Medicamentos(cim)
);

SHOW TABLES;

################################################################################################
# 2. Rellene las tablas creadas con algunos datos de ejemplo.
#################################################################################################

-- Insertamos valores para las Sucursales
INSERT INTO Sucursales VALUES(
'01234567Z', 'Farmacia Nueva', 'Plaza Nueva, Sevilla');
INSERT INTO Sucursales VALUES(
'12345678Y', 'Farmacia Vieja', 'Avenida de la Constitución, Málaga');
INSERT INTO Sucursales VALUES(
'23456789X', 'Botica de la Cruz', 'Calle Cruz de Pasión, Córdoba');
INSERT INTO Sucursales VALUES(
'34567890W', 'La alegría de la salud', 'Avenida de la Pepa, Cádiz');
INSERT INTO Sucursales VALUES(
'45678901V', 'Farmacia del Polígono', 'PI La Llanura, Huelva');

-- Insertamos valores para los Medicamentos
INSERT INTO Medicamentos VALUES('0000',
'Astringente', 10.00, 'Elimina los granos');
INSERT INTO Medicamentos VALUES('0001',
'Pañales', 15.00, 'Producto higiénico para bebés');
INSERT INTO Medicamentos VALUES('0002',
'Bisoprolol', 5.00, 'Tratamiento para problemas cardíacos');
INSERT INTO Medicamentos VALUES('0003',
'Aspirina', 3.00, 'Tableta de 15 comprimidos analgésicos');
INSERT INTO Medicamentos VALUES('0004',
'Bote 1 kg valium', 75.00, 'Tranquilizante');
INSERT INTO Medicamentos VALUES('0005',
'Inhalador', 60.00, 'Instrumento para el tratamiento de afecciones respiratorias');
INSERT INTO Medicamentos VALUES('0006',
'Desinfectante intestinal', 55.00, 'Supositorios para eliminar tenias intestinales');
INSERT INTO Medicamentos VALUES('0007',
'Paracetamol 2x', 20.00, 'Nuevo paracetamol, cuyo efecto se supone el mismo en la mitad de producto');
INSERT INTO Medicamentos VALUES('0008',
'Pastilla dental', 18.00, 'Dentífrico en un nuevo y sorprendente formato');

-- Insertamos valores para los Inventarios
INSERT INTO Inventarios VALUES('01234567Z', '0000', 200, 50);
INSERT INTO Inventarios VALUES('12345678Y', '0001', 50, 15);
INSERT INTO Inventarios VALUES('23456789X', '0002', 80, 10);
INSERT INTO Inventarios VALUES('34567890W', '0003', 400, 100);
INSERT INTO Inventarios VALUES('45678901V', '0004', 40, 10);
INSERT INTO Inventarios VALUES('01234567Z', '0004', 20, 5);
INSERT INTO Inventarios VALUES('12345678Y', '0005', 15, 8);
INSERT INTO Inventarios VALUES('23456789X', '0006', 30, 6);
INSERT INTO Inventarios VALUES('34567890W', '0007', 100, 25);
INSERT INTO Inventarios VALUES('45678901V', '0008', 30, 5);
INSERT INTO Inventarios VALUES('01234567Z', '0001', 60, 18);
INSERT INTO Inventarios VALUES('23456789X', '0001', 45, 12);
INSERT INTO Inventarios VALUES('34567890W', '0001', 58, 16);
INSERT INTO Inventarios VALUES('45678901V', '0001', 80, 24);
INSERT INTO Inventarios VALUES('01234567Z', '0006', 26, 5);
INSERT INTO Inventarios VALUES('12345678Y', '0006', 31, 8);
INSERT INTO Inventarios VALUES('34567890W', '0006', 50, 9);
INSERT INTO Inventarios VALUES('45678901V', '0006', 40, 8);

-- Insertamos valores para los Pedidos
INSERT INTO Pedidos VALUES(NULL, '2023-04-09', '34567890W');
INSERT INTO Pedidos VALUES(NULL, '2023-04-18', '12345678Y');
INSERT INTO Pedidos VALUES(NULL, '2023-04-26', '45678901V');
INSERT INTO Pedidos VALUES(NULL, '2023-05-02', '23456789X');
INSERT INTO Pedidos VALUES(NULL, '2023-05-06', '45678901V');
INSERT INTO Pedidos VALUES(NULL, '2023-05-11', '34567890W');

-- Insertamos valores para los DetallesPedidos
INSERT INTO DetallesPedidos VALUES(1, '0002', 4.00, 15);
INSERT INTO DetallesPedidos VALUES(1, '0003', 2.50, 30);
INSERT INTO DetallesPedidos VALUES(1, '0006', 48.00, 48);
INSERT INTO DetallesPedidos VALUES(2, '0007', 19.00, 12);
INSERT INTO DetallesPedidos VALUES(2, '0008', 16.00, 100);
INSERT INTO DetallesPedidos VALUES(3, '0007', 19.00, 20);
INSERT INTO DetallesPedidos VALUES(4, '0004', 60.00, 5);
INSERT INTO DetallesPedidos VALUES(5, '0005', 45.00, 5);
INSERT INTO DetallesPedidos VALUES(6, '0001', 7.00, 10);

-- Insertamos valores para los Clientes
INSERT INTO Clientes VALUES('98765432A', 'Juan Pérez Gómez');
INSERT INTO Clientes VALUES('87654321B', 'Elena García Fajardo');
INSERT INTO Clientes VALUES('76543210C', 'Francisco Herrera Martínez');
INSERT INTO Clientes VALUES('65432109D', 'Josefina Barragán Ruiz');
INSERT INTO Clientes VALUES('54321098E', 'Salvador Sánchez Dueño');
INSERT INTO Clientes VALUES('43210987F', 'Marta Castillo Carmona');
INSERT INTO Clientes VALUES('32109876G', 'Venancio Reig Costa');
INSERT INTO Clientes VALUES('21098765H', 'Mónica Gil Casas');
INSERT INTO Clientes VALUES('10987654I', 'Ignacio Iglesias Barra');
INSERT INTO Clientes VALUES('09876543J', 'Luisa Ramos Canto');

-- Insertamos valores para las Ventas
INSERT INTO Ventas VALUES(NULL, '01234567Z', '65432109D', '2023-05-06 09:14:07');
INSERT INTO Ventas VALUES(NULL, '12345678Y', '32109876G', '2023-05-07 10:21:35');
INSERT INTO Ventas VALUES(NULL, '34567890W', '76543210C', '2023-05-08 11:38:43');
INSERT INTO Ventas VALUES(NULL, '45678901V', '21098765H', '2023-05-09 12:54:16');
INSERT INTO Ventas VALUES(NULL, '23456789X', '54321098E', '2023-05-10 17:31:26');
INSERT INTO Ventas VALUES(NULL, '01234567Z', '87654321B', '2023-05-16 18:42:48');
INSERT INTO Ventas VALUES(NULL, '12345678Y', '32109876G', '2023-05-17 09:06:10');
INSERT INTO Ventas VALUES(NULL, '23456789X', '54321098E', '2023-05-18 10:00:58');
INSERT INTO Ventas VALUES(NULL, '34567890W', '76543210C', '2023-05-19 11:25:00');
INSERT INTO Ventas VALUES(NULL, '45678901V', '43210987F', '2023-05-20 13:41:44');
INSERT INTO Ventas VALUES(NULL, '01234567Z', '65432109D', '2023-06-07 14:27:37');
INSERT INTO Ventas VALUES(NULL, '12345678Y', '98765432A', '2023-06-08 17:01:09');
INSERT INTO Ventas VALUES(NULL, '23456789X', '54321098E', '2023-06-09 18:22:39');
INSERT INTO Ventas VALUES(NULL, '34567890W', '98765432A', '2023-06-10 19:14:55');
INSERT INTO Ventas VALUES(NULL, '01234567Z', '87654321B', '2023-06-11 09:07:11');
INSERT INTO Ventas VALUES(NULL, '01234567Z', '65432109D', '2023-06-17 09:32:28');
INSERT INTO Ventas VALUES(NULL, '34567890W', '76543210C', '2023-06-18 10:10:09');
INSERT INTO Ventas VALUES(NULL, '45678901V', '43210987F', '2023-06-19 10:28:16');
INSERT INTO Ventas VALUES(NULL, '01234567Z', '87654321B', '2023-06-20 11:00:04');
INSERT INTO Ventas VALUES(NULL, '23456789X', '32109876G', '2023-06-21 11:10:44');

-- Insertamos valores para los DetallesVentas
INSERT INTO DetallesVentas VALUES(1, '0002', 5.0, 1);
INSERT INTO DetallesVentas VALUES(2, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(3, '0001', 15.0, 1);
INSERT INTO DetallesVentas VALUES(4, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(5, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(6, '0002', 5.0, 1);
INSERT INTO DetallesVentas VALUES(7, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(8, '0001', 15.0, 1);
INSERT INTO DetallesVentas VALUES(9, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(10, '0000', 10.0, 1);
INSERT INTO DetallesVentas VALUES(10, '0002', 5.0, 1);
INSERT INTO DetallesVentas VALUES(11, '0001', 15.0, 1);
INSERT INTO DetallesVentas VALUES(12, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(13, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(14, '0002', 5.0, 3);
INSERT INTO DetallesVentas VALUES(15, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(16, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(16, '0002', 5.0, 2);
INSERT INTO DetallesVentas VALUES(17, '0000', 10.0, 1);
INSERT INTO DetallesVentas VALUES(18, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(19, '0002', 5.0, 2);
INSERT INTO DetallesVentas VALUES(20, '0003', 3.0, 1);
INSERT INTO DetallesVentas VALUES(20, '0002', 5.0, 1);

#################################################################################################
# 3. Una vez poblada la base de datos con algunos ejemplos, realice las siguientes consultas:
################################################################################################# 


# 3.1.	Seleccionar los nombres y precios de todos los medicamentos.
SELECT NombreMed, PVP FROM Medicamentos;


# 3.2.	Seleccionar todos los medicamentos que tengan un precio mayor a 50 euros.
SELECT * FROM Medicamentos
WHERE PVP > 50;


# 3.3.	Seleccionar todos los medicamentos que tengan un precio mayor a 50 euros y 
#       que estén disponibles en inventario para todas las sucursales.
WITH
     numSucursales AS (
     SELECT COUNT(DISTINCT cifs) AS Total FROM Sucursales),
     SucDisp AS (
     SELECT cim, COUNT(DISTINCT cifs) AS Presentes FROM Inventarios
     GROUP BY cim ORDER BY cim)
SELECT cim, NombreMed, PVP, Descripción
FROM Medicamentos NATURAL JOIN SucDisp NATURAL JOIN numSucursales
WHERE PVP > 50 AND Presentes = Total;


# 3.4.	Seleccionar todos los pedidos realizados por una sucursal en particular.
SELECT * FROM Pedidos
WHERE cifs = '34567890W';


# 3.5.	Seleccionar todos los pedidos realizados por una sucursal en particular en 
#       una tabla de pedidos que estén pendientes de ser recibidos. Se asume que un 
#       pedido está pendiente de entrega cuando la fecha del pedido es inferior a una semana 
#       respecto a la fecha actual.
SELECT * FROM Pedidos
WHERE cifs = '34567890W' AND (SELECT DATEDIFF(current_date(), Fecha)) < 7;



# 3.6.	Seleccionar el nombre y la cantidad de todos los medicamentos que ha pedido 
#       una sucursal en un periodo de tiempo específico.
WITH
     CantidadesPedidas AS (
     SELECT cim , SUM(Cantidad) AS Unidades
     FROM DetallesPedidos
     WHERE id_ped IN (SELECT id_ped FROM Pedidos
     WHERE cifs = '34567890W' AND Fecha >= '2023-04-01' AND Fecha <= '2023-04-30')
     GROUP BY cim ORDER BY cim)
SELECT NombreMed, Unidades
FROM Medicamentos NATURAL JOIN CantidadesPedidas;



# 3.7.	Seleccionar todos los medicamentos que estén disponibles en inventario 
#       y que hayan sido vendidos más de 10 veces.
WITH
     MedicamentosVendidos AS (
     SELECT cim, SUM(Unidades) AS VecesVendidos FROM DetallesVentas
     WHERE cim IN (SELECT DISTINCT cim FROM Inventarios)
     GROUP BY cim ORDER BY cim)
SELECT cim, NombreMed, PVP, Descripción
FROM Medicamentos NATURAL JOIN MedicamentosVendidos
WHERE VecesVendidos > 10;



# 3.8.	Seleccionar el nombre y la descripción de todos los medicamentos que tengan 
#       una descripción que contenga la palabra "nuevo" en una tabla de productos.
SELECT NombreMed, Descripción FROM Medicamentos
WHERE Descripción LIKE '%nuevo%';



################################################################################################################# 
# 4.	Implemente el disparador que se presenta en el enunciado. A continuación, debe realizar 
#       diferentes actualizaciones del stock de medicamentos para comprobar el correcto funcionamiento 
#       del disparador
#################################################################################################################

-- Realiza un nuevo Pedido cuando la cantidad de un Medicamento baja por debajo de un nivel
-- Como dicho nivel depende de la Sucursal y del Medicamento,
-- se ha definido la columna "Umbral" se define en Inventarios
#DROP TRIGGER IF EXISTS Encargo;
DELIMITER $$
CREATE TRIGGER Encargo AFTER UPDATE ON Inventarios FOR EACH ROW
BEGIN
   IF NEW.Cantidad < NEW.Umbral THEN
      IF NEW.cifs NOT IN (
                  SELECT cifs FROM Pedidos WHERE Fecha = current_date()) THEN
         INSERT INTO Pedidos VALUES(NULL, current_date(), OLD.cifs);   
      END IF;
      IF NEW.cim NOT IN (
	             SELECT cim FROM DetallesPedidos WHERE id_ped IN (
			     SELECT id_ped FROM Pedidos
				 WHERE cifs = NEW.cifs AND (SELECT DATEDIFF(current_date(), Fecha)) < 7)) THEN
         INSERT INTO DetallesPedidos
	     VALUES((SELECT MAX(id_ped) FROM Pedidos WHERE cifs = NEW.cifs), NEW.cim,
         (SELECT 0.8 * PVP FROM Medicamentos WHERE cim = OLD.cim), NEW.Umbral * 1.5);
      END IF;
   END IF;
END$$

-- Actualizamos los Inventarios para comprobar que el disparador funciona
-- Haremos tres pruebas con Cantidad y luego otra con Umbral
SELECT * FROM Inventarios;
SELECT * FROM Pedidos;
SELECT * FROM DetallesPedidos;

UPDATE Inventarios SET Cantidad = 13
WHERE cifs = '12345678Y' AND cim = '0001';

SELECT * FROM Inventarios;
SELECT * FROM Pedidos;
SELECT * FROM DetallesPedidos;

UPDATE Inventarios SET Cantidad = 6
WHERE cifs = '12345678Y' AND cim = '0005';

SELECT * FROM Inventarios;
SELECT * FROM Pedidos;
SELECT * FROM DetallesPedidos;

UPDATE Inventarios SET Cantidad = 96
WHERE cifs = '34567890W' AND cim = '0003';

SELECT * FROM Inventarios;
SELECT * FROM Pedidos;
SELECT * FROM DetallesPedidos;

UPDATE Inventarios SET Umbral = 46
WHERE cifs = '23456789X' AND cim = '0001';

SELECT * FROM Inventarios;
SELECT * FROM Pedidos;
SELECT * FROM DetallesPedidos;
