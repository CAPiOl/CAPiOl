% El autor de este código es Carlos Alberto Piñero Olanda 28814469T 
% cpinero30@alumno.uned.es
% FUNDAMENTOS DE LA INTELIGENCIA ARTIFICIAL PEC 2
% Centro asociado de Sevilla.

% Participantes y sus respectivas nacionalidades
nacionalidad('Farid', 'Argelia').
nacionalidad('Anush', 'Armenia').
nacionalidad('Noah', 'Australia').
nacionalidad('Sviatlana', 'Bielorrusia').
nacionalidad('Luisa', 'Brasil').
nacionalidad('John', 'Canada').
nacionalidad('Pei-ling', 'China').
nacionalidad('Ji-young', 'Corea del Sur').
nacionalidad('Julio', 'España').
nacionalidad('Judy', 'Estados Unidos').
nacionalidad('Philippe', 'Francia').
nacionalidad('Eva', 'Georgia').
nacionalidad('Akakios', 'Grecia').
nacionalidad('Peter', 'Irlanda').
nacionalidad('Giorgio', 'Italia').
nacionalidad('Sachiko', 'Japón').
nacionalidad('Mariuszka', 'Polonia').
nacionalidad('Estevao', 'Portugal').
nacionalidad('Michael', 'Reino Unido').
nacionalidad('Yekaterina', 'Ucrania').

% Continentes
continente(norafrica, 'Argelia').
continente(caucaso, 'Armenia').
continente(oceania, 'Australia').
continente(europaoriental, 'Bielorrusia').
continente(sudamerica, 'Brasil').
continente(norteamerica, 'Canada').
continente(esteasia, 'China').
continente(esteasia, 'Corea del Sur').
continente(europaoccidental, 'España').
continente(norteamerica, 'Estados Unidos').
continente(europaoccidental, 'Francia').
continente(caucaso, 'Georgia').
continente(europaoriental, 'Grecia').
continente(europaoccidental, 'Irlanda').
continente(europaoccidental, 'Italia').
continente(esteasia, 'Japón').
continente(europaoccidental, 'Polonia').
continente(europaoccidental, 'Portugal').
continente(europaoccidental, 'Reino Unido').
continente(europaoriental, 'Ucrania').

% Países insulares
isla('Japón').
isla('Irlanda').
isla('Australia').
isla('Reino Unido').

% Influencias
influye('la Antigua Roma y culturas nativas', oceania).
influye('Persia', caucaso).
influye('la Antigua China', esteasia).
influye('la Antigua Roma', europaoccidental).
influye('Bizancio', europaoriental).
influye('la Antigua Roma y Arabia', norafrica).
influye('la Antigua Roma y culturas nativas', norteamerica).
influye('la Antigua Roma y culturas nativas', sudamerica).

% Alfabetos
alfabeto('Argelia', arabe).
alfabeto('Armenia', armenio).
alfabeto('Australia', latino).
alfabeto('Bielorrusia', cirilico).
alfabeto('Brasil', latino).
alfabeto('Canada', latino).
alfabeto('China', chino).
alfabeto('Corea del Sur', coreano).
alfabeto('España', latino).
alfabeto('Estados Unidos', latino).
alfabeto('Francia', latino).
alfabeto('Georgia', georgiano).
alfabeto('Grecia', griego).
alfabeto('Irlanda', latino).
alfabeto('Italia', latino).
alfabeto('Japón', japones).
alfabeto('Polonia', latino).
alfabeto('Portugal', latino).
alfabeto('Reino Unido', latino).
alfabeto('Ucrania', cirilico).

% Sentido de la escritura
sentido_escritura(arabe, horizontal, izquierda).
sentido_escritura(armenio, horizontal, derecha).
sentido_escritura(chino, vertical, izquierda).
sentido_escritura(cirilico, horizontal, derecha).
sentido_escritura(coreano, horizontal, derecha).
sentido_escritura(georgiano, horizontal, derecha).
sentido_escritura(griego, horizontal, derecha).
sentido_escritura(japones, vertical, izquierda).
sentido_escritura(latino, horizontal, derecha).

% Países con tradición caligráfica
caligrafia('Argelia').
caligrafia('China').
caligrafia('Japón').

% Preferencias de los países respecto a la libertad y el deber
prefiere('Argelia', deber, libertad).
prefiere('Armenia', deber, libertad).
prefiere('Australia', libertad, deber).
prefiere('Bielorrusia', deber, libertad).
prefiere('Brasil', libertad, deber).
prefiere('Canada', libertad, deber).
prefiere('China', deber, libertad).
prefiere('Corea del Sur', deber, libertad).
prefiere('España', libertad, deber).
prefiere('Estados Unidos', libertad, deber).
prefiere('Francia', libertad, deber).
prefiere('Georgia', libertad, deber).
prefiere('Grecia', libertad, deber).
prefiere('Irlanda', libertad, deber).
prefiere('Italia', libertad, deber).
prefiere('Japón', deber, libertad).
prefiere('Polonia', deber, libertad).
prefiere('Polonia', libertad, deber).
prefiere('Reino Unido', libertad, deber).
prefiere('Ucrania', libertad, deber).

% Países con tradición cinematográfica
cine('Corea del Sur').
cine('España').
cine('Estados Unidos').
cine('Francia').
cine('Italia').
cine('Japón').
cine('Portugal').
cine('Reino Unido').
cine('Ucrania').

% Países con gran tradición en marionetas
marionetas('Francia').
marionetas('Japón').

% Países reconocidos por sus tallas tradicionales
tallas('Australia').
tallas('Canada').
tallas('Estados Unidos').
tallas('Japón').
tallas('Polonia').

% Países reconocidos por su teatro
teatro('China').
teatro('España').
teatro('Francia').
teatro('Georgia').
teatro('Grecia').
teatro('Italia').
teatro('Japón').
teatro('Reino Unido').
teatro('Ucrania').

% Países reconocidos por su pintura figurativa
pintura('España').
pintura('Francia').
pintura('Italia').
pintura('Japón').
pintura('Reino Unido').
pintura('Ucrania').

% Países según su arquitectura
arquitectura('Argelia', piedra).
arquitectura('Armenia', piedra).
arquitectura('Australia', piedra).
arquitectura('Bielorrusia', piedra).
arquitectura('Brasil', piedra).
arquitectura('Canada', madera).
arquitectura('China', madera).
arquitectura('Corea del Sur', madera).
arquitectura('España', piedra).
arquitectura('Estados Unidos', madera).
arquitectura('Francia', piedra).
arquitectura('Georgia', piedra).
arquitectura('Grecia', piedra).
arquitectura('Irlanda', piedra).
arquitectura('Italia', piedra).
arquitectura('Japón', madera).
arquitectura('Polonia', piedra).
arquitectura('Portugal', piedra).
arquitectura('Reino Unido', piedra).
arquitectura('Ucrania', piedra).

% Países famosos por sus procesiones
procesiones('China').
procesiones('España').
procesiones('Georgia').
procesiones('Italia').
procesiones('Japón').
procesiones('Portugal').

% Año de aparición de la primera novela
primera_novela('Argelia', 1971).
primera_novela('Armenia', 1883).
primera_novela('Australia', 1831).
primera_novela('Bielorrusia', 1907).
primera_novela('Brasil', 1843).
primera_novela('Canada', 1769).
primera_novela('China', 1350).
primera_novela('Corea del Sur', 1670).
primera_novela('España', 1480).
primera_novela('Estados Unidos', 1789).
primera_novela('Francia', 1532).
primera_novela('Georgia', 1882).
primera_novela('Grecia', 100).
primera_novela('Irlanda', 1800).
primera_novela('Italia', 50).
primera_novela('Japón', 1000).
primera_novela('Polonia', 1776).
primera_novela('Portugal', 1875).
primera_novela('Reino Unido', 1719).
primera_novela('Ucrania', 1840).

% Países reconocidos por su cómic
comic('España').
comic('Estados Unidos').
comic('Francia').
comic('Italia').
comic('Japón').
comic('Reino Unido').

% Países reconocidos por sus óperas
opera('China').
opera('Francia').
opera('Italia').

% Función de ayuda. Explica qué se puede hacer con el programa
ayuda:-write('Debate sobre el arte en diversos países\n'),
write('Tenemos a los siguientes participantes:'),
write('\n\nFarid    Anush     Noah     Sviatlana Luisa'),
write('\nJohn     Pei-ling  Ji-young Julio     Judy'),
write('\nPhilippe Eva       Akakios  Peter     Giorgio'),
write('\nSachiko  Mariuszka Estevao  Michael   Yekaterina'),
write('\n\nSi les haces las siguientes preguntas, responderán.'),
write('\n\nDónde viven'),
write('\ndondevive(P).'),
write('\n\nQué influencias recibió su país de origen'),
write('\norigen_cultural(P).'),
write('\n\nEn qué alfabeto escriben'),
write('\nescribe_en(P).'),
write('\n\nCómo escriben'),
write('\nescribir(P).'),
write('\n\nSi valoran la caligrafía'),
write('\ncaligrafos(P).'),
write('\n\nSi en su país se valora más la libertad o la tradición'),
write('\nqueprefiere(P).'),
write('\n\nLas preferencias de los artistas de su país'),
write('\nefecto_arte(P).'),
write('\n\nSi en su país hay tallas tradicionales'),
write('\nhay_tallas(P).'),
write('\n\nSi en su país ha habido grandes pintores'),
write('\nhay_pintores(P).'),
write('\n\nSi en su país se reconoce el cómic'),
write('\nhay_comic(P).'),
write('\n\nSi en su país hay gran tradición teatral'),
write('\nhay_teatro(P).'),
write('\n\nSi en su país tienen ópera'),
write('\nhay_opera(P).'),
write('\n\nSi en su país hay grandes procesiones religiosas'),
write('\nhay_procesiones(P).'),
write('\n\nCuándo apareció la primera novela'),
write('\ntiempo_novelas(P).'),
write('\n\nSi hay buenas películas'),
write('\nhay_cine(P).'),
write('\n\nCómo se construían los edificios'),
write('\nmaterial_arq(P).').

% Auxiliar para cuando uno de los participantes habla de su país
hablando_de_mi_pais(P, N):-nacionalidad(P, N),
write(P),
write(' dice que en '),
write(N),
write(' ').

% Auxiliar para no tener que repetir las negaciones en cada regla
negar(A):-A,
write('').
negar(A):-write('no ').

% Regla para determinar las influencias culturales
origen_cultural(P):-hablando_de_mi_pais(P, N),
continente(C, N),
influye(I, C),
write('tienen influencias de '),
write(I).

% Regla para determinar en qué alfabeto escriben
escribe_en(P):-write(P),
write(' escribe en '),
nacionalidad(P, N),
alfabeto(N, A),
write(A).

% Regla para determinar cómo escriben
escribir(P):-hablando_de_mi_pais(P, N),
write('se escribe en '),
alfabeto(N, A),
write(A),
sentido_escritura(A, M, S),
write(' de modo '),
write(M),
write(' hacia la '),
write(S).

% Regla para que un participante diga si vive en una isla
dondevive(P):-write(P),
nacionalidad(P,N),
write(' vive en '),
write(N),
write(', que '),
negar(isla(N)),
write('es una isla.').

% Regla para que un participante diga cómo se ven las marionetas en su país
gustan_marionetas(P):-hablando_de_mi_pais(P, N),
negar(marionetas(N)),
write('se valoran las marionetas.').

% Regla para que un participante diga cuál es su preferencia entre tradición y libertad
queprefiere(P):-nacionalidad(P, N),
prefiere(N, X, Y),
write(P),
write(' prefiere '),
write(X),
write(' a '),
write(Y).

% Regla para que un participante diga cuál es el efecto de la anterior preferencia en los artistas de su país
efecto_arte(P):-nacionalidad(P, N),
prefiere(N, deber, libertad),
write(P),
write(' dice que en su país el artista está muy marcado por el peso de la tradicion').
efecto_arte(P):-nacionalidad(P, N),
prefiere(N, libertad, deber),
write(P),
write(' dice que en su país el artista no valora tanto las tradiciones').

% Regla para que un participante diga si hay tradición en tallas
hay_tallas(P):-hablando_de_mi_pais(P, N),
negar(tallas(N)),
write('se reconocen las tallas tradicionales.').

% Regla para que un participante diga si hay grandes pintores en su país
hay_pintores(P):-hablando_de_mi_pais(P, N),
negar(pintura(N)),
write('hay grandes pintores.').

% Regla para que un participante diga cuál es la posición del cómic en la cultura del país
hay_comic(P):-hablando_de_mi_pais(P, N),
negar(comic(N)),
write('se reconoce el cómic').

% Regla para que un participante hable de las tradiciones teatrales de su país
hay_teatro(P):-hablando_de_mi_pais(P, N),
negar(teatro(N)),
write('existe una gran tradicion teatral.').

% Regla para que un participante diga si hay grandes óperas en su país
hay_opera(P):-hablando_de_mi_pais(P, N),
negar(opera(N)),
write('existe pasión por la ópera.').

% Regla para que un participante diga si las procesiones son corrientes en su país
hay_procesiones(P):-hablando_de_mi_pais(P, N),
negar(procesiones(N)),
write('hay procesiones').

% Regla para que un participante diga cómo está el cine en su país
hay_cine(P):-hablando_de_mi_pais(P, N),
negar(cine(N)),
write('hay grandes películas').

% Regla para que un participante diga cuándo apareció la primera novela en su país
tiempo_novelas(P):-hablando_de_mi_pais(P, N),
write('las primeras novelas aparecieron '),
primera_novela(N,T),
(T > 1800,write('en la Era Actual');
T > 1500,write('en la Edad Moderna');
T > 500,write('en la Edad Media');
write('en la Edad Clásica')),
write(', en el año '),
write(T).

% Regla para que un participante diga con qué se edificaba tradicionalmente en su país
material_arq(P):-hablando_de_mi_pais(P, N),
write('los edificios se han construido tradicionalmente con '),
arquitectura(N, M),
write(M).

% Regla para que un participante diga si la caligrafía es un arte
caligrafos(P):-hablando_de_mi_pais(P, N),
negar(caligrafia(N)),
write('se ama la caligrafía').
