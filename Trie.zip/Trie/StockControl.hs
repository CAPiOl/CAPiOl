module StockControl where

data Stock = ROOTNODE [Stock] | INNERNODE Char [Stock] | INFONODE Int
  deriving (Show,Read,Eq)

-------------------------
-- FUNCIÓN CREATESTOCK --
-------------------------

-- FUNCIÓN QUE DEVUELVE UN STOCK VACÍO --
createStock :: Stock
createStock = ROOTNODE []

---------------------------
-- FUNCIÓN RETRIEVESTOCK --
---------------------------

-- FUNCIÓN QUE DEVUELVE EL NÚMERO DE UNIDADES DE UN PRODUCTO EN EL STOCK --
-- SI NO ESTÁ, DEBERÁ DEVOLVER -1                                        --

retrieveStock :: Stock         -> String -> Int
retrieveStock (ROOTNODE     l)                     s  = retrieveStock (INNERNODE ' ' l) s
retrieveStock (INNERNODE c  [])                    s  = -1
retrieveStock (INNERNODE c  ((INFONODE n):is))     "" = n
retrieveStock (INNERNODE c  ((INFONODE n):is))     s  = retrieveStock (INNERNODE c (is)) s
retrieveStock (INNERNODE c  l)                     "" = -1
retrieveStock (INNERNODE c1 ((INNERNODE c2 l):is)) s
  | c2 <  (head s)                                    = retrieveStock (INNERNODE c1 (is)) s
  | c2 == (head s)                                    = retrieveStock (INNERNODE c2 l) (tail s)
  | c2 >  (head s)                                    = -1

-------------------------
-- FUNCIÓN UPDATESTOCK --
-------------------------

-- FUNCIÓN QUE MODIFICA EL VALOR ASOCIADO A UN PRODUCTO EN EL STOCK --
-- SÓLO PUEDE ALMACENAR NÚMEROS MAYORES O IGUALES A 0               --

updateStock :: Stock         -> String -> Int -> Stock
updateStock goods s num = case(goods, s, num) of
 (ROOTNODE    list, "", num) -> ROOTNODE    list
 (ROOTNODE    list, s , num) -> ROOTNODE    (changeS list s num)
 (INNERNODE c list, s , num) -> INNERNODE c (changeS list s num)
 where changeS :: [Stock] -> String -> Int -> [Stock]
       changeS ((INFONODE n)   :is) "" num = ((INFONODE num):is)
       changeS (is)                 "" num = ((INFONODE num):is)
       changeS []                   s  num = [INNERNODE (head s) (changeS [] (tail s) num)]
       changeS ((INFONODE n)   :is) s  num = ((INFONODE n):(changeS (is) s num))
       changeS ((INNERNODE c l):is) s  num
        | c <  (head s)                    = ((INNERNODE c l):(changeS (is) s num))
        | c == (head s)                    = (updateStock (INNERNODE c l) (tail s) num:is)
        | c >  (head s)                    = ((INNERNODE (head s) (changeS [] (tail s) num)):(INNERNODE c l):is)

-----------------------
-- FUNCIÓN LISTSTOCK --
-----------------------

-- FUNCIÓN QUE DEVUELVE UNA LISTA PARES PRODUCTO-EXISTENCIA --
-- DEL CATÁLOGO QUE COMIENZAN POR LA CADENA PREFIJO p       --

listStock :: Stock -> String -> [(String,Int)]
listStock (ROOTNODE    list) t = map retrieveTuple (bt esSol giveN ("",(-1),list))
 where esSol :: (String,Int,[Stock]) -> Bool
       esSol (s,i,l) = hasStr t s && i > -1
       giveN :: (String,Int,[Stock]) -> [(String,Int,[Stock])]
       giveN (s,i,[])                                 = []
       giveN (s,i,((INFONODE n):ins))                 = [(s,n,[])]         ++ (giveN (s,i,(ins)))
       giveN (s,i,((INNERNODE c l):ins))
         | hasStr (s ++ [c]) t || hasStr t (s ++ [c]) = [((s ++ [c]),i,l)] ++ (giveN (s,i,(ins)))
         | otherwise                                  =                        giveN (s,i,(ins))
       hasStr :: String -> String -> Bool
       hasStr t1 t2 = t1 == take (length t1) t2
       retrieveTuple :: (String,Int,[Stock]) -> (String,Int)
       retrieveTuple (s,i,(ins)) = (s,i)


-- FUNCIÓN GENÉRICA DE BACKTRACKING --
bt :: (a -> Bool) -> (a -> [a]) -> a -> [a]
bt    eS             c             n
  | eS n      = [n]
  | otherwise = concat (map (bt eS c) (c n))
